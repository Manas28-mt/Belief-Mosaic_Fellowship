import { authenticateRequest } from '../server/lib/auth.js';
import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { promptTime, hardDates, frequency, tz } = req.body || {};

  if (isUsingMockDb) {
    const mockStore = getMockStore();
    const storedUser = mockStore.users.get(user.id);
    if (!storedUser) return res.status(404).json({ error: 'User not found' });

    if (promptTime !== undefined) storedUser.prompt_time = promptTime;
    if (hardDates !== undefined) storedUser.hard_dates = hardDates;
    if (frequency !== undefined) storedUser.frequency = frequency;
    if (tz !== undefined) storedUser.tz = tz;

    return res.status(200).json({ success: true });
  }

  const sql = getDb();
  if (!sql) return res.status(500).json({ error: 'Database unavailable' });

  try {
    const updates = {};
    if (promptTime !== undefined) updates.prompt_time = promptTime;
    if (hardDates !== undefined) updates.hard_dates = hardDates;
    if (frequency !== undefined) updates.frequency = frequency;
    if (tz !== undefined) updates.tz = tz;

    await sql`
      UPDATE users
      SET ${sql(updates)}
      WHERE id = ${user.id}
    `;
    return res.status(200).json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update settings' });
  }
}
