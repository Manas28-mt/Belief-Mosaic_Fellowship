import fs from 'fs';
import path from 'path';
import { checkCrisis } from '../server/lib/crisis.js';
import { completeJSON } from '../server/lib/llm.js';
import { checkBaluReply } from '../server/lib/baluCheck.js';
import { NUMBERS } from '../server/config/numbers.js';
import { checkRateLimit } from '../server/lib/rateLimit.js';

let baluPromptTemplate = '';
try {
  const promptPath = path.resolve(process.cwd(), 'server/prompts/balu.txt');
  if (fs.existsSync(promptPath)) {
    baluPromptTemplate = fs.readFileSync(promptPath, 'utf8');
  }
} catch {
  // Fallback
}

// Global counts per RULES.md: "Log only counts: sessions, crisis stops, rejections. Never content."
let sessionCount = 0;
let crisisStopCount = 0;
let rejectionCount = 0;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Rate-limit: 30 requests per hour per IP
  if (!checkRateLimit(req, res)) {
    return;
  }

  const { pastQuote, pastDate, todayEntry, messages, turn } = req.body || {};
  const currentTurn = Number(turn) || 1;

  sessionCount++;

  // Find latest user message
  const userMessages = (messages || []).filter(m => m.role === 'user');
  const latestUserMessage = userMessages.length > 0 ? userMessages[userMessages.length - 1].content : '';

  // a) Run checkCrisis on the latest user message. If true, return { crisis: true } and do NOT call LLM
  if (latestUserMessage) {
    const isCrisis = checkCrisis(latestUserMessage);
    if (isCrisis) {
      crisisStopCount++;
      console.log(`[BALU_METRICS] Sessions: ${sessionCount}, Crisis Stops: ${crisisStopCount}, Rejections: ${rejectionCount}`);
      return res.status(200).json({ crisis: true });
    }
  }

  // If already at or past MAX_BALU_TURNS
  if (currentTurn >= NUMBERS.MAX_BALU_TURNS) {
    return res.status(200).json({ reply: 'Noted, in your words.', end: true });
  }

  // b) Call completeJSON with balu.txt and only PAST_QUOTE, PAST_DATE, TODAY_ENTRY and this session's messages
  const systemPrompt = `${baluPromptTemplate}\n\nContext for this session:\nPAST_QUOTE: "${pastQuote || ''}"\nPAST_DATE: "${pastDate || ''}"\nTODAY_ENTRY: "${todayEntry || ''}"`;

  const context = { pastQuote, messages };

  async function getCandidate() {
    return completeJSON(systemPrompt, messages || []);
  }

  let result = await getCandidate();
  let candidateReply = result?.reply;

  // c) Validate reply
  let isValid = checkBaluReply(candidateReply, context);

  // d) If rejected, retry once
  if (!isValid) {
    rejectionCount++;
    result = await getCandidate();
    candidateReply = result?.reply;
    isValid = checkBaluReply(candidateReply, context);
  }

  // e) Fallback if still rejected or failed
  if (!isValid || !candidateReply) {
    if (currentTurn >= NUMBERS.MAX_BALU_TURNS) {
      candidateReply = 'Noted, in your words.';
    } else {
      candidateReply = 'Tell me a bit more about that.';
    }
  }

  const shouldEnd = currentTurn >= NUMBERS.MAX_BALU_TURNS || (result?.end === true);

  console.log(`[BALU_METRICS] Sessions: ${sessionCount}, Crisis Stops: ${crisisStopCount}, Rejections: ${rejectionCount}`);

  return res.status(200).json({
    reply: candidateReply,
    end: shouldEnd,
    crisis: false,
  });
}
