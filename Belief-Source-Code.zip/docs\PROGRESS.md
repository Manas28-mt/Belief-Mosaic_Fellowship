# Progress & Status

## Protected Screens Restoration (Logged per Autonomous Mode Rule)
- **Status**: Restored original opening flow (`Splash.jsx` -> `AuthScreen.jsx` -> `VisualStory.jsx` -> `TimelineSetup.jsx` -> `RealHome.jsx`).
- **Files Protected / Verified**:
  - `src/components/opening/Splash.jsx` (Logo on start screen + zoom animation)
  - `src/components/auth/AuthScreen.jsx` (Login screen with Google/Email + floating logo)
  - `src/components/mascot/VisualStory.jsx` (Balu showing Meera's story)
  - `src/components/mascot/WalkthroughBear.jsx` (Conversational walkthrough with Balu)
- **Files Merged by Hand**:
  - `src/App.jsx`: Restored user's exact opening flow while keeping all phase routes (`?open=...`, `/crisis`, Balu follow-up, `DevPanel`) active underneath.
- **Rules Enforced**:
  - `docs/RULES.md`: Added PROTECTED SCREENS section and updated login rule.
## User Refinements (Opening Flow, Text Alignment & IIT Bombay)
- **Text Alignment Fixed**:
  - Fixed header text collision: `.feature-number` now uses flex layout with gap and `.sample-badge` has distinct pill badge padding, completely eliminating the merged `SAMPLEWHAT IT IS NOT` header glitch.
  - Fixed bullet alignment: `.what-not-card` and `.what-not-line` now explicitly enforce `text-align: left`, flex start alignment, and dedicated serif text styling, removing center-aligned line breaks and uneven indentations.
- **Scene 0 Redesigned**:
  - Replaced the school topper/overachiever focused text ("You were top of your class...") with a universally relatable reflection for anyone struggling despite trying their best:
    *"You show up. You put in the hours. You do everything you can to get better. And yet, you still feel like you're falling behind everyone else. When you're trying this hard every day, you forget to notice the small things you're actually getting right."*
  - Replaced the floating text & 5-second fade delay with an elegant, structured diary reflection card (`.struggle-card`) featuring clean step dots and an immediate, clear `Meet Balu →` button.
- **Meera Updated to IIT Bombay BTech CSE**:
  - Updated college from Hansraj College to IIT Bombay and course to BTech CSE across `VisualStory.jsx`, `sampleStudent.js`, and `WalkthroughBear.jsx`.
  - Updated background achievements to JEE Advanced top ranker and story context to feeling overwhelmed among top coders and Olympiad medalists.

## Final Report

### What Works
1. **PWA Architecture (Phase 1)**: Service worker (`src/sw.js`) handling neutral push notifications and deep linking (`/?open=record`, `playback`, `checkin`, `balu`). Web manifest with 192px/512px icons.
2. **Backend & Database (Phase 2)**: PostgreSQL schema (`server/db/schema.sql`) for anonymous users and push subscriptions. No transcripts or audio stored on server. API endpoints for register, subscribe, heartbeat, settings, and cron.
3. **Permission Flow (Phase 3)**: Soft explainer screen only after saving first entry; 14-day dismissal backoff; iOS 3-step home screen installation guide; settings row for prompt time (21:00 default) and notifications toggle.
4. **Entry Pipeline (Phase 4)**: MediaRecorder recording screen with no countdown, "30 seconds is enough" in Stone, soft stop at 90s, typing and one-tap fallbacks; Fraunces text area on Beige card; `/api/analyze` scoring with exact-substring evidence checking; instant `/crisis` redirection on level 3.
5. **Scheduler & Pattern Ladder (Phase 5)**: Pure decision engine `decide(user, nowLocal)` implementing hard dates, silence check-ins, Balu invites, heavy day playback, and nightly prompts. 12/12 unit tests passing.
6. **Balu Follow-up (Phase 6)**: Strict 3-turn limit; crisis check executed before LLM call; `checkBaluReply()` filter ensuring max 35 words, max 1 question mark, no banned phrases, no exclamation marks/emoji, and exact quoted substrings.
7. **Crisis Screen & Reach Someone (Phase 7)**: 100% static crisis screen with Tele-MANAS (14416 / 1-800-891-4416) and College Counselling Cell; optional WhatsApp trusted contact shortcut.
8. **Safety Evaluation Harness (Phase 8)**: 45 test cases across 9 categories. 100% explicit crisis detection verified. `npm run eval` passing.
9. **Demo Layer & Dev Tools (Phase 9)**: Judge path takes under 2 minutes with zero sign-ups or permission prompts; mock phone lock screen with 2 notifications; 3 lines on "What it is not"; dev panel for 14-day pattern simulation and local test push delivery.

### What Is Mocked
- **Sarvam Speech-to-Text**: Mock fallback returns typed input when `SARVAM_API_KEY` is not provided.
- **LLM Provider (Gemini / OpenAI)**: Mock classifier and scripted Balu dialogue operate when `LLM_API_KEY` is not provided. Keyword crisis check is strictly live and active at all times.
- **Postgres Database**: In-memory mock store operates when `DATABASE_URL` is not set for local offline development.
- **Web Push**: Mock fallback simulates push dispatch when VAPID keys are absent.

### Open Issues (Ranked by Severity)
- **Low**: Live push notifications require deployed HTTPS environment with valid VAPID keys for external testing on physical iOS/Android devices.
- **Low**: Balu artwork is currently an outlined circular placeholder awaiting finalized vector/SVG assets.

### Exact "Needs a Human" Checklist
- [ ] **Crisis Keywords Review**: Founder and a certified counsellor must review and expand `server/config/crisis_keywords.json`.
- [ ] **College Counselling Cell Contacts**: Founder must verify DU Counselling Cell phone numbers in `src/config/help_contacts.js` before launch.
- [ ] **Extended Safety Evals**: Expand `evals/cases.jsonl` from 45 starter cases to ~200 real-world edge cases.
- [ ] **Physical Device Testing**: Conduct push notification acceptance testing on real iPhone (Safari PWA) and Android (Chrome PWA) devices.
- [ ] **Balu Mascot Artwork**: Finalize illustrated Balu artwork to replace the circular placeholder.

### Commands to Run the App Locally
```bash
# Install dependencies
npm install

# Run Vite development server
npm run dev

# Run scheduler unit tests
npm run test

# Run safety evaluation harness
npm run eval

# Build production bundle
npm run build
```

---

## Phase Status Summary
- **Phase 1: PWA** — COMPLETED
- **Phase 2: Backend and database** — COMPLETED
- **Phase 3: Permission flow** — COMPLETED
- **Phase 4: Entry pipeline (transcribe, score, crisis check)** — COMPLETED
- **Phase 5: Scheduler and pattern ladder** — COMPLETED
- **Phase 6: Balu follow-up** — COMPLETED
- **Phase 7: Crisis screen and the human step** — COMPLETED
- **Phase 8: Safety evaluation harness** — COMPLETED
- **Phase 9: Demo layer, dev tools, testing** — COMPLETED

---

## Phase 9 Review
- **Files Changed:**
  - `src/components/mascot/VisualStory.jsx`: Implemented "How it knows" scene with mock phone lock screen (2 notifications), "One heavy day changes tomorrow. Several heavy days lead to a person.", scripted Balu dialogue, and "What it is not" 3 lines ("Not therapy.", "Balu asks. It doesn't advise.", "Your words, not praise.").
  - `src/components/dev/DevPanel.jsx`: Floating developer panel (DEV only) simulating 14-day patterns (all ordinary, one heavy yesterday, 3 heavy in 5 days, heavy then 2 days silent, hard date today) showing `decide()` results and "Send test push to me".
  - `docs/TESTING.md`: Complete QA checklist covering multi-platform testing, deep link notification routing, offline behavior, crisis safety, and sub-2-minute judge path.
  - `src/App.jsx`: Mounted `DevPanel` and wired demo mode state.
- **Review Results:** All items verified. Production build (`npm run build`), unit tests (`npm run test`), and safety evaluations (`npm run eval`) pass with zero errors.
- **Open Issues:** None.
- **Needs a Human:** Physical device testing and artwork finalization listed in Final Report.

---
- **Files Changed:**
  - `evals/cases.jsonl`: 45 test cases across 9 categories in English, Hindi, and Hinglish.
  - `evals/run.js`: Safety evaluation runner checking 100% explicit crisis detection, substring evidence verification, Balu banned word / tone filters, and reporting indirect crisis misses for review.
  - `package.json`: Added `"npm run eval"`.
  - `docs/BACKEND.md`: Documented mandatory evaluation run before any changes to prompts, keywords, model, or production launch.
- **Review Results:** All 45 cases evaluated. 100% explicit crisis caught (5/5). 15/15 Balu replies passed safety checks. 9/9 evidence substrings verified.
- **Open Issues:** None.
- **Needs a Human:** Review of the 5 indirect crisis cases flagged by the harness.

---

## Phase 7 Review
- **Files Changed:**
  - `src/config/help_contacts.js`: Tele-MANAS primary/secondary numbers and College Counselling Cell with required founder verification note.
  - `src/components/crisis/CrisisScreen.jsx`: Completely static crisis screen, Ink on Cream, zero motion, Tele-MANAS 14416 Marigold button, counselling cell, and back link.
  - `src/components/trust/ReachSomeone.jsx`: Component facilitating private WhatsApp/share message to trusted contact with prefilled "Free to talk later?", or direct counsellor routing.
  - `src/components/auth/TimelineSetup.jsx`: Added optional, skippable card "Who's one person you'd call on a bad day?", saving contact strictly to client IndexedDB.
- **Review Results:** All items verified. Clean build (`npm run build`).
- **Open Issues:** None.
- **Needs a Human:** Founder must verify College Counselling Cell contact details before launch.

---

## Phase 6 Review
- **Files Changed:**
  - `server/prompts/balu.txt`: Balu system prompt with exact specification.
  - `server/config/balu_banned.json`: Seeded banned phrases.
  - `server/lib/baluCheck.js`: `checkBaluReply` enforcing max 35 words, max 1 '?', no '!' or emoji, no banned phrases, exact quote substrings.
  - `api/balu.js`: Balu endpoint running crisis check BEFORE any LLM call, single retry, 3-turn max, count logging only.
  - `src/services/api.js`: Added `interactWithBalu` client helper with mock fallback.
  - `src/components/mascot/BaluScreen.jsx`: Full 3-turn follow-up screen on Peach, plain circle placeholder, local quote picker, mic and typing inputs, disclaimer, saves user lines to diary, 1 session per day limit.
  - `src/components/badday/BadDayMode.jsx`: Added "Want to add something about today?" trigger button.
  - `src/App.jsx`: Wired `open=balu` invite state, `fromInvite` pass-through, and `onOpenCrisis`.
- **Review Results:** All items verified. `npm run test` and `npm run build` pass.
- **Open Issues:** Real Balu artwork comes later per prompt.
- **Needs a Human:** None.

---

## Phase 5 Review
- **Files Changed:**
  - `server/config/prompts.js`: Nightly prompts rotated by day-of-year.
  - `server/lib/scheduler.js`: Pure `decide(user, nowLocal)` implementing hard dates, silence check-in, Balu invite, heavy day playback, and nightly prompts.
  - `api/cron.js`: Integrated `decide` and `sendPush`, logs only user/send counts and error codes.
  - `tests/decide.test.js`: 12 unit tests covering all scheduler branches, cooldowns, and the one-per-day limit.
  - `package.json`: Added `"test": "node --test tests/*.test.js"`.
- **Review Results:** All 12 unit tests passed. Production build passes cleanly.
- **Open Issues:** None.
- **Needs a Human:** None.

---

## Phase 4 Review
- **Files Changed:**
  - `server/config/crisis_keywords.json`: English, Hindi, and Hinglish keyword seeds.
  - `server/prompts/analyze.txt`: Scoring prompt returning JSON with level (0-3), evidence substring, and small_things.
  - `server/lib/crisis.js`: `checkCrisis(text)` matching whole keyword phrases or classifier level 3.
  - `server/lib/llm.js`: `completeJSON` LLM adapter supporting Gemini/OpenAI/Groq with mock fallback.
  - `api/transcribe.js`: Sarvam STT forwarding with mock fallback.
  - `api/analyze.js`: Endpoint executing keyword check, classifier, substring verification on evidence, `level = max(...)`.
  - `src/utils/quotes.js`: `verifyQuoteSubstring` exact substring validator enforcing RULES.md.
  - `src/hooks/useAudioRecorder.js`: Added `onStop` callback support and automatic soft stop near 90 seconds.
  - `src/components/home/RealHome.jsx`: MediaRecorder recording screen with "30 seconds is enough" in Stone, no countdown, 96px Marigold button, Fraunces text area on Beige card, optional mood tap, one Marigold save button, IndexedDB save + `/api/analyze` + `/api/heartbeat`, direct navigation to `/crisis` on crisis level 3.
  - `src/components/crisis/CrisisScreen.jsx`: Static crisis screen with Tele-MANAS (14416 / 1-800-891-4416) and College Counselling Cell.
  - `src/config/help_contacts.js`: Help contacts configuration.
  - `src/App.jsx`: Added `/crisis` route and `onOpenCrisis` handlers.
- **Review Results:** All items verified. Build passes cleanly (`npm run build`). No transcripts or audio stored on server.
- **Open Issues:** None.
- **Needs a Human:** Crisis keywords list requires review by founder and counsellor (`server/config/crisis_keywords.json`).

