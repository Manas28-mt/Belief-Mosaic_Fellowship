import React, { useState } from 'react';
import Balu from '../balu/Balu.jsx';

/**
 * WalkthroughBear Component — now with Balu vector mascot.
 * Conversational walkthrough overlay. Free of emojis.
 */
export default function WalkthroughBear({ onComplete }) {
  const [step, setStep] = useState(0);

  const steps = [
    {
      pose: 'wave',
      entrance: 'pop',
      text: "Hey! I'm Balu — your belief companion. I'm here to help you remember who you are, especially on the days you forget.",
      button: "Nice to meet you, Balu"
    },
    {
      pose: 'listen',
      entrance: 'none',
      text: "I won't give you advice or praise. I'll just listen, tag the small things you do, and play them back when you need to hear them.",
      button: "How does that work?"
    },
    {
      pose: 'think',
      entrance: 'none',
      text: "Let me show you how I helped someone. Meera came to me feeling completely lost — she was in BTech CSE at IIT Bombay and felt like she was falling behind everyone.",
      button: "What happened?"
    },
    {
      pose: 'talk',
      entrance: 'none',
      text: "I noticed she hadn't talked to me in 3 days and her last recording sounded really heavy. So I stepped in — not with a motivational quote, but with her own words.",
      button: "What did you say?"
    },
    {
      pose: 'point',
      entrance: 'none',
      text: "I said: \"Hey Meera, remember back in May when you spent three weeks on sticky wages? You answered a question in class before anyone else. That was YOU.\" — Her own proof of progress.",
      button: "That's beautiful."
    },
    {
      pose: 'wave',
      entrance: 'pop',
      text: "Now it's your turn. Answer one question a day — voice, text, or just a tap. I'll build your timeline and be here when you need me.",
      button: "Let's start"
    }
  ];

  const currentStep = steps[step];

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  return (
    <div className="walkthrough-overlay animate-fade-in">
      <div className="walkthrough-progress">
        {steps.map((_, i) => (
          <div key={i} className={`wp-dot ${i <= step ? 'wp-dot--active' : ''}`} />
        ))}
      </div>

      <div className="walkthrough-content">
        {/* Chat Bubble */}
        <div className="wt-bubble animate-slide-up" key={step}>
          <p className="text-body" style={{ fontWeight: 500, lineHeight: 1.5, margin: 0 }}>
            {currentStep.text}
          </p>
        </div>

        {/* Balu */}
        <div className="wt-mascot animate-slide-up" style={{ animationDelay: '100ms' }}>
          <Balu pose={currentStep.pose} entrance={currentStep.entrance} size={110} />
        </div>

        {/* Actions */}
        <div className="wt-actions animate-slide-up" style={{ animationDelay: '200ms' }}>
          <button className="btn btn--primary btn--full" onClick={handleNext}>
            {currentStep.button}
          </button>
          <button className="btn btn--ghost w-full" onClick={onComplete} style={{ opacity: 0.5, marginTop: '8px' }}>
            Skip walkthrough
          </button>
        </div>
      </div>

      <style>{`
        .walkthrough-overlay {
          position: absolute;
          inset: 0;
          background: rgba(251, 245, 230, 0.98);
          z-index: 100;
          display: flex;
          flex-direction: column;
          padding: 24px;
        }
        .walkthrough-progress {
          display: flex;
          gap: 6px;
          margin-bottom: 24px;
        }
        .wp-dot {
          flex: 1;
          height: 4px;
          border-radius: 2px;
          background: var(--color-sand);
          transition: background 0.3s;
        }
        .wp-dot--active {
          background: var(--color-marigold);
        }
        .walkthrough-content {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          max-width: 340px;
          margin: 0 auto;
          width: 100%;
        }
        .wt-bubble {
          background: var(--color-bubble);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px;
          margin-bottom: 24px;
          width: 100%;
          text-align: center;
        }
        .wt-mascot {
          margin-bottom: 32px;
        }
        .wt-actions {
          width: 100%;
        }
      `}</style>
    </div>
  );
}
