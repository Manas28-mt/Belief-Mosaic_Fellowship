import React, { useState, useEffect } from 'react';
import { ArrowLeft, Edit3, Check } from 'lucide-react';
import Balu from '../balu/Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';
import { TIMELINE_QUESTIONS } from '../../data/timelineQuestions.js';
import { getTimelineAnswers, saveTimelineAnswer } from '../../services/db.js';

/**
 * TimelineView — shows the person's timeline right away.
 * Every answer can be edited here.
 */
export default function TimelineView({ onBack, onEditQuestion }) {
  const [answersMap, setAnswersMap] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');

  const loadData = async () => {
    try {
      const stored = await getTimelineAnswers();
      const map = {};
      stored.forEach((item) => {
        map[item.id] = item;
      });
      setAnswersMap(map);
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStartEdit = (qId, currentVal) => {
    setEditingId(qId);
    setEditText(currentVal || '');
  };

  const handleSaveEdit = async (q) => {
    const record = {
      id: q.id,
      questionId: q.id,
      questionText: q.question,
      title: q.title,
      year: q.year,
      text: editText.trim(),
      answer: editText.trim(),
      skipped: !editText.trim(),
      updatedAt: new Date().toISOString(),
    };

    setAnswersMap((prev) => ({ ...prev, [q.id]: record }));
    setEditingId(null);
    try {
      await saveTimelineAnswer(record);
    } catch {
      // Ignore
    }
  };

  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Home</span>
    </button>
  );

  const footerContent = (
    <button
      type="button"
      className="btn btn--primary btn--full"
      onClick={onBack}
    >
      Done
    </button>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      className="timeline-view-layout"
    >
      <div className="timeline-view-content">
        <div className="timeline-mascot-row mb-3">
          <Balu pose="wave" entrance="pop" size={80} />
        </div>

        <h1 className="text-headline text-center mb-1" style={{ fontSize: '26px' }}>
          Your timeline
        </h1>
        <p className="text-small text-center mb-4" style={{ color: 'var(--color-stone)' }}>
          Facts you proved about yourself in your own words.
        </p>

        {/* Milestones Stem */}
        <div className="timeline-stem-list">
          {TIMELINE_QUESTIONS.map((q, idx) => {
            const record = answersMap[q.id];
            const hasAnswer = Boolean(record?.text && record.text.trim());
            const isEditing = editingId === q.id;

            return (
              <div key={q.id} className="timeline-milestone-node">
                <div className="milestone-line-marker">
                  <div className={`milestone-dot ${hasAnswer ? 'milestone-dot--filled' : ''}`} />
                  {idx < TIMELINE_QUESTIONS.length - 1 && <div className="milestone-stem-line" />}
                </div>

                <div className="milestone-card mb-4">
                  <div className="milestone-card-top">
                    <span className="milestone-tag">{q.title}</span>
                    {!isEditing && (
                      <button
                        type="button"
                        className="milestone-edit-btn"
                        onClick={() => handleStartEdit(q.id, record?.text)}
                        aria-label={`Edit ${q.title}`}
                      >
                        <Edit3 size={14} />
                        <span>Edit</span>
                      </button>
                    )}
                  </div>

                  <p className="milestone-prompt mb-2">
                    {q.question}
                  </p>

                  {isEditing ? (
                    <div className="milestone-edit-box mt-2">
                      <textarea
                        className="milestone-edit-textarea mb-2"
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        placeholder="Your answer..."
                        rows={3}
                      />
                      <div className="milestone-edit-actions">
                        <button
                          type="button"
                          className="btn btn--secondary btn--small"
                          onClick={() => setEditingId(null)}
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          className="btn btn--primary btn--small"
                          onClick={() => handleSaveEdit(q)}
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : hasAnswer ? (
                    <p className="milestone-quote mt-2">
                      "{record.text}"
                    </p>
                  ) : (
                    <div className="milestone-skipped mt-2">
                      <span className="text-caption" style={{ color: 'var(--color-stone)' }}>
                        Skipped
                      </span>
                      <button
                        type="button"
                        className="btn btn--ghost btn--small ml-2"
                        onClick={() => handleStartEdit(q.id, '')}
                      >
                        Add answer
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <style>{`
        .timeline-view-content {
          display: flex;
          flex-direction: column;
          width: 100%;
          max-width: 360px;
          margin: 0 auto;
        }
        .timeline-mascot-row {
          display: flex;
          justify-content: center;
        }
        .timeline-stem-list {
          display: flex;
          flex-direction: column;
          position: relative;
        }
        .timeline-milestone-node {
          display: flex;
          gap: 12px;
          position: relative;
        }
        .milestone-line-marker {
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 20px;
          flex-shrink: 0;
        }
        .milestone-dot {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          border: 2px solid var(--color-sand);
          background: var(--color-cream);
          margin-top: 6px;
        }
        .milestone-dot--filled {
          background: var(--color-marigold);
          border-color: var(--color-marigold);
        }
        .milestone-stem-line {
          width: 2px;
          flex: 1;
          background: var(--color-sand);
          margin-top: 4px;
        }
        .milestone-card {
          flex: 1;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px;
          display: flex;
          flex-direction: column;
        }
        .milestone-card-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 6px;
        }
        .milestone-tag {
          font-size: var(--text-caption);
          color: var(--color-stone);
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .milestone-edit-btn {
          display: flex;
          align-items: center;
          gap: 4px;
          background: transparent;
          border: none;
          color: var(--color-stone);
          font-family: var(--font-sans);
          font-size: var(--text-caption);
          cursor: pointer;
          padding: 2px 4px;
        }
        .milestone-edit-btn:hover {
          color: var(--color-ink);
        }
        .milestone-prompt {
          font-family: var(--font-sans);
          font-size: var(--text-small);
          color: var(--color-stone);
          margin: 0;
          line-height: 1.4;
        }
        .milestone-quote {
          font-family: var(--font-serif);
          font-size: 17px;
          line-height: 1.5;
          color: var(--color-ink);
          margin: 0;
        }
        .milestone-skipped {
          display: flex;
          align-items: center;
        }
        .milestone-edit-textarea {
          width: 100%;
          padding: 10px;
          border-radius: var(--radius-card);
          border: 1px solid var(--color-sand);
          background: var(--color-cream);
          font-family: var(--font-serif);
          font-size: 16px;
          line-height: 1.4;
          color: var(--color-ink);
          box-sizing: border-box;
          outline: none;
          resize: none;
        }
        .milestone-edit-actions {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
        }
        .btn--small {
          padding: 6px 12px;
          font-size: var(--text-caption);
        }
        .ml-2 {
          margin-left: 8px;
        }
      `}</style>
    </ScreenLayout>
  );
}
