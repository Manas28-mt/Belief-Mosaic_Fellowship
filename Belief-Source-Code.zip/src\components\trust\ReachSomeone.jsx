import React, { useState, useEffect } from 'react';
import { getTrustedContact } from '../../services/db.js';

/**
 * <ReachSomeone /> component (Phase 7).
 * Shows option to message saved trusted person or talk to a counsellor.
 * The person sends the message themselves; app never contacts anyone.
 */
export default function ReachSomeone({ onOpenCrisis }) {
  const [contact, setContact] = useState(null);

  useEffect(() => {
    async function load() {
      const c = await getTrustedContact();
      if (c) setContact(c);
    }
    load();
  }, []);

  const handleMessage = () => {
    if (!contact) return;
    const cleanNum = (contact.phone || contact.number || '').replace(/[^0-9]/g, '');
    const textParam = encodeURIComponent('Free to talk later?');

    if (cleanNum) {
      const url = `https://wa.me/${cleanNum}?text=${textParam}`;
      window.open(url, '_blank', 'noopener,noreferrer');
    } else if (navigator.share) {
      navigator.share({
        title: 'Checking in',
        text: 'Free to talk later?',
      }).catch(() => {});
    } else {
      window.open(`sms:?body=${textParam}`, '_blank');
    }
  };

  return (
    <div className="reach-someone-card">
      <div className="text-caption mb-2" style={{ color: 'var(--color-stone)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
        Reach someone
      </div>

      {contact && contact.name ? (
        <button className="btn btn--secondary btn--full mb-2" onClick={handleMessage}>
          Message {contact.name}
        </button>
      ) : (
        <button
          className="btn btn--secondary btn--full mb-2"
          onClick={() => {
            if (navigator.share) {
              navigator.share({ text: 'Free to talk later?' }).catch(() => {});
            } else {
              window.open(`sms:?body=${encodeURIComponent('Free to talk later?')}`, '_blank');
            }
          }}
        >
          Message someone you trust
        </button>
      )}

      {onOpenCrisis && (
        <button className="btn btn--ghost btn--full" onClick={onOpenCrisis} style={{ color: 'var(--color-stone)' }}>
          Talk to a counsellor
        </button>
      )}

      <style>{`
        .reach-someone-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: var(--space-3);
          margin-top: var(--space-3);
        }
      `}</style>
    </div>
  );
}
