import React from 'react';
import Balu from '../balu/Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * WalkthroughEnd — shown immediately when the walkthrough ends.
 * Shows one screen with Balu (pose: point) and two buttons:
 * - "Build your timeline" (primary)
 * - "Later" (outlined)
 */
export default function WalkthroughEnd({ onStartTimeline, onLater }) {
  const footerContent = (
    <div className="walkthrough-end-actions">
      <button
        type="button"
        className="btn btn--primary btn--full"
        onClick={onStartTimeline}
      >
        Build your timeline
      </button>
      <button
        type="button"
        className="btn btn--secondary btn--full mt-2"
        onClick={onLater}
      >
        Later
      </button>
    </div>
  );

  return (
    <ScreenLayout
      footer={footerContent}
      bg="cream"
      className="walkthrough-end-layout"
    >
      <div className="walkthrough-end-content">
        <div className="walkthrough-end-mascot mb-4">
          <Balu pose="point" entrance="pop" size={110} />
        </div>

        <h1 className="text-headline text-center mb-3" style={{ fontSize: '26px' }}>
          Build your timeline
        </h1>

        <p className="text-body text-center" style={{ color: 'var(--color-stone)', maxWidth: '320px', lineHeight: 1.5 }}>
          Record a few moments from your past in your own words. When things get difficult, Balu plays back your own proof.
        </p>
      </div>

      <style>{`
        .walkthrough-end-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          min-height: 380px;
          margin: auto 0;
          padding: 16px 0;
        }
        .walkthrough-end-mascot {
          display: flex;
          justify-content: center;
        }
        .walkthrough-end-actions {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
