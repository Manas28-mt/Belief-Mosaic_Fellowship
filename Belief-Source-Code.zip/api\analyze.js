import fs from 'fs';
import path from 'path';
import { authenticateRequest } from '../server/lib/auth.js';
import { checkCrisisKeywords } from '../server/lib/crisis.js';
import { completeJSON } from '../server/lib/llm.js';
import { checkRateLimit } from '../server/lib/rateLimit.js';

let analyzePrompt = null;
function getAnalyzePrompt() {
  if (analyzePrompt) return analyzePrompt;
  try {
    const filePath = path.resolve(process.cwd(), 'server/prompts/analyze.txt');
    if (fs.existsSync(filePath)) {
      analyzePrompt = fs.readFileSync(filePath, 'utf8');
      return analyzePrompt;
    }
  } catch {}
  analyzePrompt = 'Analyze the student transcript for distress levels.';
  return analyzePrompt;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Rate-limit: 30 requests per hour per IP
  if (!checkRateLimit(req, res)) {
    return;
  }

  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { transcript, moodTap } = req.body || {};
  if (!transcript || typeof transcript !== 'string') {
    return res.status(400).json({ error: 'Transcript required' });
  }

  // 1. Keyword check
  const keywordHit = checkCrisisKeywords(transcript);

  // 2. Classifier LLM check
  const systemPrompt = getAnalyzePrompt();
  const classifierResult = await completeJSON(systemPrompt, [
    { role: 'user', content: transcript },
  ]);

  const classifierLevel = typeof classifierResult?.level === 'number' ? classifierResult.level : 0;

  // 3. Level computation: max(classifier, keyword hit ? 3 : 0, moodTap === "low" ? 1 : 0)
  const level = Math.max(
    classifierLevel,
    keywordHit ? 3 : 0,
    moodTap === 'low' ? 1 : 0
  );

  // 4. Drop evidence that isn't an exact substring
  const rawEvidence = Array.isArray(classifierResult?.evidence) ? classifierResult.evidence : [];
  const validEvidence = rawEvidence.filter((span) => typeof span === 'string' && span.length > 0 && transcript.includes(span));

  // If keyword hit caused level 3 and no valid evidence, find the matching keyword
  if (keywordHit && validEvidence.length === 0) {
    const lower = transcript.toLowerCase();
    const configPath = path.resolve(process.cwd(), 'server/config/crisis_keywords.json');
    try {
      const data = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      const allKws = [...(data.en || []), ...(data.hi || []), ...(data.hinglish || [])];
      for (const kw of allKws) {
        const idx = lower.indexOf(kw.toLowerCase());
        if (idx !== -1) {
          validEvidence.push(transcript.substring(idx, idx + kw.length));
          break;
        }
      }
    } catch {}
  }

  const smallThings = (Array.isArray(classifierResult?.small_things) ? classifierResult.small_things : []).slice(0, 3);

  // Rule: Store nothing. Return { level, evidence, smallThings, crisis: level === 3 }
  return res.status(200).json({
    level,
    evidence: validEvidence,
    smallThings,
    crisis: level === 3,
  });
}
