import React, { useState, useEffect, useRef } from 'react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Opening Screens
 * Converted to unified ScreenLayout:
 * - Line reveals 1.2s apart.
 * - Reset and cleanup on unmount.
 * - Pinned footer slot for tap hint/button.
 * - Double-fire guard.
 */

const lines = [
  'You were top of your class, the team captain, the one who always had it figured out.',
  'Then you stepped into a room where everyone else was too.',
  "Your ability didn't change.\nYour baseline did.",
];

export default function OpeningScreens({ onDone }) {
  const [currentLine, setCurrentLine] = useState(0);
  const doneCalledRef = useRef(false);

  useEffect(() => {
    const timer1 = setTimeout(() => setCurrentLine(1), 1200);
    const timer2 = setTimeout(() => setCurrentLine(2), 2400);
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, []);

  const handleTap = () => {
    if (doneCalledRef.current) return;
    doneCalledRef.current = true;
    onDone();
  };

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowRight') {
        e.preventDefault();
        handleTap();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  const footerContent = (
    <div className="opening-footer-hint text-center">
      <button
        type="button"
        className="btn btn--ghost"
        onClick={handleTap}
        style={{ color: 'var(--color-stone)' }}
      >
        Tap to continue
      </button>
    </div>
  );

  return (
    <ScreenLayout
      footer={footerContent}
      bg="cream"
      className="opening-screen-layout"
    >
      <div
        className="opening-screen-content"
        onClick={handleTap}
        role="button"
        tabIndex={0}
        aria-label="Tap to continue"
      >
        <div className="opening-lines-stack">
          {lines.map((line, idx) => {
            const isVisible = currentLine >= idx;
            const isLast = idx === lines.length - 1;

            return (
              <div
                key={idx}
                className={`opening-line-item ${isVisible ? 'is-visible' : 'is-hidden'}`}
              >
                {isLast ? (
                  <p className="opening-text opening-text--accent">
                    Your ability didn't change.<br />
                    <span className="marigold-highlight">Your baseline did.</span>
                  </p>
                ) : (
                  <p className="opening-text">
                    {line}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <style>{`
        .opening-screen-content {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          cursor: pointer;
          user-select: none;
          min-height: 320px;
          width: 100%;
          max-width: 340px;
          margin: 0 auto;
        }

        .opening-lines-stack {
          display: flex;
          flex-direction: column;
          gap: 24px;
          width: 100%;
        }

        .opening-line-item {
          transition: opacity 0.6s ease, transform 0.6s ease;
        }
        .opening-line-item.is-visible {
          opacity: 1;
          transform: translateY(0);
        }
        .opening-line-item.is-hidden {
          opacity: 0;
          transform: translateY(12px);
          pointer-events: none;
        }

        .opening-text {
          font-family: var(--font-serif);
          font-size: var(--text-headline);
          line-height: var(--lh-heading);
          color: var(--color-ink);
          margin: 0;
          font-weight: 400;
        }

        .opening-text--accent {
          font-size: var(--text-display);
          font-weight: 500;
          margin-top: 8px;
        }

        .marigold-highlight {
          position: relative;
          display: inline-block;
          color: var(--color-ink);
          z-index: 1;
          white-space: nowrap;
        }
        .marigold-highlight::after {
          content: '';
          position: absolute;
          left: -4px;
          right: -4px;
          bottom: 12%;
          height: 40%;
          background-color: var(--color-marigold);
          z-index: -1;
          border-radius: 2px;
        }

        .opening-footer-hint {
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
