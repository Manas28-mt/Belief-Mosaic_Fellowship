import React, { useState } from 'react';

/**
 * How It Knows — explains the 4 signals and demos the silence check-in.
 */
export default function HowItKnows({ isTour, onRoughPatch }) {
  const [replied, setReplied] = useState(false);

  const handleReply = (type) => {
    if (type === 'rough') {
      onRoughPatch();
    } else {
      setReplied(type);
    }
  };

  return (
    <div className="how-it-knows animate-fade-in-slow">
      <div className="signals-grid mb-6">
        <div className="card card--signal mb-2 delay-1 animate-slide-up">
          <div className="text-small" style={{ fontWeight: 600 }}>1. You tell it</div>
          <div className="text-caption">A "rough day" tap, or mood check</div>
        </div>
        
        <div className="card card--signal mb-2 delay-2 animate-slide-up">
          <div className="text-small" style={{ fontWeight: 600 }}>2. Silence</div>
          <div className="text-caption">You go quiet for 3 days</div>
        </div>
        
        <div className="card card--signal mb-2 delay-3 animate-slide-up">
          <div className="text-small" style={{ fontWeight: 600 }}>3. Predictable days</div>
          <div className="text-caption">Results, placements — it knows dates</div>
        </div>
        
        <div className="card card--signal mb-4 delay-4 animate-slide-up">
          <div className="text-small" style={{ fontWeight: 600 }}>4. What you said</div>
          <div className="text-caption">"Wasted the day" in a recording</div>
        </div>
      </div>
      
      <div className="silence-demo pt-4 border-top delay-5 animate-slide-up">
        <div className="text-caption mb-3 text-center" style={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
          ── The silence check-in ──
        </div>
        
        <div className="card--quote mb-4" style={{ backgroundColor: 'var(--color-peach)' }}>
          <p className="text-caption mb-1">You said (Aug 15):</p>
          <p className="text-voice">"I finally understand how Keynes got it right."</p>
        </div>
        
        {!replied ? (
          <div className="mood-options" style={{ justifyContent: 'center' }}>
            <button className="mood-option" onClick={() => handleReply('busy')}>
              busy
            </button>
            <button className="mood-option" onClick={() => handleReply('rough')} style={{ borderColor: 'var(--color-ink)' }}>
              rough patch
            </button>
            <button className="mood-option" onClick={() => handleReply('bored')}>
              bored of this
            </button>
          </div>
        ) : (
          <div className="text-center text-small mt-4 animate-fade-in">
            {replied === 'busy' ? "Got it. See you when you have time." : "Got it. We'll ask less often."}
          </div>
        )}
      </div>

      <style>{`
        .border-top {
          border-top: 1px solid var(--color-sand);
        }
      `}</style>
    </div>
  );
}
