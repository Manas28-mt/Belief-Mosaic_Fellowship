import React, { useState, useEffect, useRef } from 'react';
import { Check, ArrowRight } from 'lucide-react';
import Balu from '../balu/Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * VisualStory — Cinematic walkthrough of Belief with Balu the Bee & Meera.
 * 
 * Uses unified ScreenLayout:
 * - Body is the ONLY scroll area, resets to top on every scene change.
 * - Continue/Next button lives strictly in the pinned footer slot OUTSIDE scroll area.
 * - Double-fire prevention during scene transitions.
 * - Line reveals reset properly on mount/unmount and scene change.
 * - Fixed image sizes, no horizontal scroll at 360px.
 */
export default function VisualStory({ onComplete }) {
  const [scene, setScene] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const totalScenes = 9;

  // Scene 0: Progressive line reveal (1.2s apart)
  const [revealedLine, setRevealedLine] = useState(0);
  const timer1Ref = useRef(null);
  const timer2Ref = useRef(null);
  const transitionTimerRef = useRef(null);

  // Scene 1: Balu Intro (flyIn as fly -> pop to wave) -> Meera story (peekRight as peek -> point at card)
  const [scene1Phase, setScene1Phase] = useState('intro');
  const [introPose, setIntroPose] = useState('fly');
  const [storyPose, setStoryPose] = useState('peek');
  const scene1FlyTimerRef = useRef(null);
  const scene1AdvanceTimerRef = useRef(null);
  const scene1StoryPointTimerRef = useRef(null);

  // Clear timers on unmount
  useEffect(() => {
    return () => {
      if (timer1Ref.current) clearTimeout(timer1Ref.current);
      if (timer2Ref.current) clearTimeout(timer2Ref.current);
      if (transitionTimerRef.current) clearTimeout(transitionTimerRef.current);
      if (scene1FlyTimerRef.current) clearTimeout(scene1FlyTimerRef.current);
      if (scene1AdvanceTimerRef.current) clearTimeout(scene1AdvanceTimerRef.current);
      if (scene1StoryPointTimerRef.current) clearTimeout(scene1StoryPointTimerRef.current);
    };
  }, []);

  // Reset and run line reveals whenever entering scene 0
  useEffect(() => {
    if (scene === 0) {
      setRevealedLine(0);
      timer1Ref.current = setTimeout(() => {
        setRevealedLine(1);
      }, 1200);
      timer2Ref.current = setTimeout(() => {
        setRevealedLine(2);
      }, 2400);

      return () => {
        if (timer1Ref.current) clearTimeout(timer1Ref.current);
        if (timer2Ref.current) clearTimeout(timer2Ref.current);
      };
    } else {
      setRevealedLine(0);
    }
  }, [scene]);

  // Handle Scene 1 transitions: fly -> wave -> (story) peek -> point
  useEffect(() => {
    if (scene === 1) {
      if (scene1Phase === 'intro') {
        setIntroPose('fly');
        scene1FlyTimerRef.current = setTimeout(() => {
          setIntroPose('wave');
        }, 700);
        scene1AdvanceTimerRef.current = setTimeout(() => {
          setScene1Phase('story');
        }, 2600);
      } else if (scene1Phase === 'story') {
        setStoryPose('peek');
        scene1StoryPointTimerRef.current = setTimeout(() => {
          setStoryPose('point');
        }, 700);
      }

      return () => {
        if (scene1FlyTimerRef.current) clearTimeout(scene1FlyTimerRef.current);
        if (scene1AdvanceTimerRef.current) clearTimeout(scene1AdvanceTimerRef.current);
        if (scene1StoryPointTimerRef.current) clearTimeout(scene1StoryPointTimerRef.current);
      };
    } else {
      setScene1Phase('intro');
      setIntroPose('fly');
      setStoryPose('peek');
    }
  }, [scene, scene1Phase]);

  const handleNext = () => {
    if (isTransitioning) return; // double-fire prevention
    setIsTransitioning(true);

    if (scene < totalScenes - 1) {
      setScene((prev) => prev + 1);
      transitionTimerRef.current = setTimeout(() => {
        setIsTransitioning(false);
      }, 250);
    } else {
      onComplete();
    }
  };

  const renderSceneContent = () => {
    switch (scene) {
      /* ── SCENE 0: Opening Lines Screen ── */
      case 0:
        return (
          <div
            className="story-scene scene-opening-lines"
            onClick={handleNext}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleNext();
              }
            }}
            aria-label="Tap to continue"
          >
            <div className="opening-lines-wrap">
              {/* Line 1 */}
              <p className={`opening-line ${revealedLine >= 0 ? 'line-visible' : 'line-hidden'}`}>
                You were top of your class, the team captain, the one who always had it figured out.
              </p>

              {/* Line 2 */}
              <p className={`opening-line ${revealedLine >= 1 ? 'line-visible' : 'line-hidden'}`}>
                Then you stepped into a room where everyone else was too.
              </p>

              {/* Line 3: Emphasised with Marigold highlight band behind Ink text */}
              <div className={`opening-line opening-line--accent ${revealedLine >= 2 ? 'line-visible' : 'line-hidden'}`}>
                <span className="baseline-text">
                  Your ability didn't change.{' '}
                  <span className="marigold-highlight-band">Your baseline did.</span>
                </span>
              </div>
            </div>

            <div className="opening-tap-hint">
              <span className="text-caption" style={{ color: 'var(--color-stone)' }}>
                Tap anywhere to continue
              </span>
            </div>
          </div>
        );

      /* ── SCENE 1: Balu Intro + Meera Story ── */
      case 1:
        return (
          <div className="story-scene scene-meera">
            {scene1Phase === 'intro' ? (
              /* Intro view: flyIn as fly, then pop to wave */
              <div
                className="balu-intro-row"
                onClick={() => setScene1Phase('story')}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setScene1Phase('story');
                  }
                }}
                style={{ cursor: 'pointer', width: '100%' }}
                aria-label="Tap to view Meera story"
              >
                <Balu
                  pose={introPose}
                  entrance={introPose === 'fly' ? 'flyIn' : 'pop'}
                  size={96}
                />
                <div className="balu-speech-bubble balu-speech-bubble--left-tail">
                  <p className="bubble-text" style={{ margin: 0, fontWeight: 600 }}>
                    Hey! I'm Balu.
                  </p>
                  <p className="bubble-subtext" style={{ margin: '4px 0 0', color: 'var(--color-stone)' }}>
                    Let me tell you about Meera — she was a lot like you.
                  </p>
                  <span className="text-caption mt-2" style={{ display: 'block', color: 'var(--color-leaf)', fontSize: '12px' }}>
                    Tap to see her story →
                  </span>
                </div>
              </div>
            ) : (
              /* Meera Story Card view: peekRight as peek, then point at card */
              <div className="meera-story-container">
                {/* Single Balu on screen, pointing at story card */}
                <div className="balu-peek-side">
                  <Balu
                    pose={storyPose}
                    entrance={storyPose === 'peek' ? 'peekRight' : 'none'}
                    size={80}
                  />
                </div>

                <div className="meera-card">
                  <div className="meera-card-header">
                    {/* Peach circle with thin Ink ring, 'M' in Fraunces */}
                    <div className="meera-avatar-badge" aria-label="Meera avatar">
                      <span className="meera-initial">M</span>
                    </div>
                    <div className="meera-meta">
                      <div className="meera-name-row">
                        <span className="meera-name">Meera</span>
                        <span className="sample-badge">Sample</span>
                      </div>
                      <div className="meera-label">BTech CSE, IIT Bombay</div>
                    </div>
                  </div>

                  {/* Previous achievements list */}
                  <div className="meera-achievements-box">
                    <div className="achievements-heading">Previous achievements</div>
                    
                    <div className="achievement-row">
                      <Check size={16} strokeWidth={2} className="achievement-check" aria-hidden="true" />
                      <span>Class 12 School Topper (97.4%)</span>
                    </div>
                    <div className="sand-divider" />

                    <div className="achievement-row">
                      <Check size={16} strokeWidth={2} className="achievement-check" aria-hidden="true" />
                      <span>JEE Advanced — Top 0.5% Across India</span>
                    </div>
                    <div className="sand-divider" />

                    <div className="achievement-row">
                      <Check size={16} strokeWidth={2} className="achievement-check" aria-hidden="true" />
                      <span>State Olympiad Gold Medalist</span>
                    </div>
                  </div>

                  {/* What happened at IIT Bombay */}
                  <div className="meera-story-box mt-3">
                    <div className="story-box-title">What happened at IIT Bombay</div>
                    <p className="story-box-body">
                      Suddenly surrounded by the country's top coders and rank holders. Despite giving it everything every day, she started feeling lost, overwhelmed, and convinced that everyone else was miles ahead.
                    </p>
                  </div>

                  {/* Insight box */}
                  <div className="meera-insight-box mt-3">
                    <p className="insight-text">
                      <strong>Sound familiar?</strong> She was working harder than ever, but she started undermining her own achievements.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      /* ── SCENE 2: Meera records a bad day ── */
      case 2:
        return (
          <div className="story-scene scene-record">
            <div className="scene-label mb-2">
              <span className="scene-tag">Meera's Bad Day</span>
            </div>

            <div className="voice-recording-card">
              <div className="recording-header">
                <div className="rec-dot" />
                <span className="text-caption">VOICE NOTE, AUG 5</span>
              </div>
              <p className="text-voice" style={{ fontSize: '18px', margin: '12px 0' }}>
                "I thought I'd never get through macro. The mid-sem is in two weeks and I still mix up IS-LM every single time..."
              </p>
              <div className="waveform-visual">
                {Array.from({ length: 24 }).map((_, i) => (
                  <div
                    key={i}
                    className="wave-bar"
                    style={{
                      height: `${8 + Math.sin(i * 0.8) * 16 + 6}px`,
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Bad-day context: soft, 72px, no motion */}
            <div className="balu-reaction-row mt-4">
              <Balu pose="soft" size={72} noMotion={true} entrance="none" />
              <div className="balu-speech-bubble balu-speech-bubble--left-tail">
                <p className="bubble-text" style={{ fontSize: '16px', margin: 0 }}>
                  I could hear it in her voice. She was comparing herself to everyone. But I stayed quiet — I just tagged what she did: <em>"Studied for four hours"</em> and <em>"Preparing despite feeling behind"</em>.
                </p>
              </div>
            </div>

            <div className="scene-tags-demo mt-3">
              <span className="auto-tag">Studied 4 hours</span>
              <span className="auto-tag">Pushed through doubt</span>
            </div>
          </div>
        );

      /* ── SCENE 3: Weeks later, good days ── */
      case 3:
        return (
          <div className="story-scene scene-progress">
            <div className="scene-label mb-2">
              <span className="scene-tag">Weeks Later</span>
            </div>

            <div className="progress-montage">
              <div className="montage-entry">
                <div className="montage-date">May 28</div>
                <p className="text-voice" style={{ fontSize: '16px', margin: '4px 0 8px' }}>
                  "I finally understand how Keynes got it right about sticky wages."
                </p>
                <span className="auto-tag-small">Figured something out on her own</span>
              </div>
              <div className="montage-entry mt-3">
                <div className="montage-date">Jun 10</div>
                <p className="text-voice" style={{ fontSize: '16px', margin: '4px 0 8px' }}>
                  "I even explained it to Arjun after class because he missed it."
                </p>
                <span className="auto-tag-small">Helped a friend</span>
              </div>
              <div className="montage-entry mt-3">
                <div className="montage-date">Jul 20</div>
                <p className="text-voice" style={{ fontSize: '16px', margin: '4px 0 8px' }}>
                  "I think I'm actually good at explaining things."
                </p>
                <span className="auto-tag-small">Recognised a strength</span>
              </div>
            </div>

            <div className="balu-aside mt-4">
              <Balu pose="wave" entrance="pop" size={64} />
              <p className="text-small" style={{ fontStyle: 'italic', color: 'var(--color-stone)', margin: 0 }}>
                She couldn't see her own pattern. But I could. I was saving all of this.
              </p>
            </div>
          </div>
        );

      /* ── SCENE 4: The Empathetic Intervention ── */
      case 4:
        return (
          <div className="story-scene scene-intervention">
            <div className="intervention-header">
              <Balu pose="listen" entrance="flyIn" size={96} />
            </div>

            <div className="intervention-conversation mt-3">
              <div className="balu-speech-bubble balu-speech-bubble--left-tail mb-3">
                <p className="bubble-text" style={{ margin: 0 }}>
                  Hi Meera. I noticed you haven't checked in for 3 days, and your last few recordings sounded really heavy.
                </p>
              </div>

              <div className="balu-speech-bubble balu-speech-bubble--left-tail mb-3">
                <p className="bubble-text" style={{ margin: 0 }}>
                  I know today feels like you're not getting anywhere. But do you remember what you told me back in May?
                </p>
              </div>

              <div className="balu-speech-bubble balu-speech-bubble--left-tail mb-3">
                <p className="bubble-text" style={{ margin: 0 }}>
                  You said you spent <strong>three weeks</strong> trying to understand sticky wages. And then one day in the tutorial, you <strong>answered a question before anyone else</strong>.
                </p>
              </div>

              <div className="intervention-quote mb-3">
                <div className="quote-attribution">Your words, May 28th:</div>
                <p className="text-voice" style={{ margin: 0 }}>
                  "I finally understand how Keynes got it right about sticky wages. It took me three weeks and four YouTube videos but today in the tutorial I actually answered a question before anyone else."
                </p>
              </div>

              <div className="balu-speech-bubble balu-speech-bubble--left-tail">
                <p className="bubble-text" style={{ margin: 0, color: 'var(--color-leaf)' }}>
                  That was you, Meera. That didn't come from nowhere. Today is hard — but you've been here before, and you got through it.
                </p>
              </div>
            </div>
          </div>
        );

      /* ── SCENE 5: The Result ── */
      case 5:
        return (
          <div className="story-scene scene-result">
            <div className="result-stat-grid">
              <div className="result-stat">
                <div className="stat-number">5</div>
                <div className="stat-label">months of entries</div>
              </div>
              <div className="result-stat">
                <div className="stat-number">4</div>
                <div className="stat-label">setbacks faced</div>
              </div>
              <div className="result-stat">
                <div className="stat-number">4</div>
                <div className="stat-label">times she bounced back</div>
              </div>
            </div>

            <div className="result-message mt-4">
              <Balu pose="wave" entrance="pop" size={96} />
              <h2 className="text-headline mt-3">
                She didn't need praise.<br />She needed her own proof.
              </h2>
              <p className="text-body mt-2" style={{ color: 'var(--color-stone)' }}>
                Meera's belief wasn't rebuilt by an app telling her she's great. It was rebuilt by hearing her own voice, remembering her own words.
              </p>
            </div>
          </div>
        );

      /* ── SCENE 6: Feature 1 — Daily Voice Capture ── */
      case 6:
        return (
          <div className="story-scene scene-feature">
            <div className="feature-number">1 of 3</div>
            <h2 className="text-headline mt-2 mb-2 text-center">Daily Voice Capture</h2>
            <div className="feature-explain">
              <p className="text-body text-center mb-4">
                Every day, Balu gives you a simple question. You answer in 30 seconds — voice, text, or a single tap.
              </p>
              <div className="feature-demo-card">
                <p className="text-small" style={{ fontWeight: 600, marginBottom: '8px' }}>Today's question:</p>
                <p className="text-voice" style={{ fontSize: '18px' }}>"What did you do today that was hard?"</p>
                <div className="feature-demo-actions">
                  <div className="demo-action-btn">Speak</div>
                  <div className="demo-action-btn">Type</div>
                  <div className="demo-action-btn">Tap</div>
                </div>
              </div>
            </div>
            <div className="balu-feature-aside mt-4">
              <Balu pose="point" entrance="none" size={64} />
              <p className="text-small" style={{ color: 'var(--color-stone)', margin: 0 }}>
                This builds your timeline. The more you record, the more I can help on tough days.
              </p>
            </div>
          </div>
        );

      /* ── SCENE 7: Feature 2 — How It Knows ── */
      case 7:
        return (
          <div className="story-scene scene-feature">
            <div className="feature-number">
              <span className="sample-badge">Sample</span>
              <span>How it knows</span>
            </div>

            <h2 className="text-headline mt-3 mb-2 text-center">How it knows</h2>

            {/* Lockscreen preview */}
            <div className="mock-lockscreen mb-4">
              <div className="lockscreen-clock">21:00</div>
              <div className="lockscreen-date">Monday, October 12</div>

              <div className="lockscreen-notification">
                <div className="notif-header">
                  <img src="/logo.jpg" alt="" width="14" height="14" className="notif-icon" />
                  <span className="notif-app">Belief</span>
                  <span className="notif-time">now</span>
                </div>
                <div className="notif-body">Something from your diary is waiting.</div>
              </div>

              <div className="lockscreen-notification">
                <div className="notif-header">
                  <img src="/logo.jpg" alt="" width="14" height="14" className="notif-icon" />
                  <span className="notif-app">Belief</span>
                  <span className="notif-time">yesterday</span>
                </div>
                <div className="notif-body">Something from your diary is waiting.</div>
              </div>
            </div>

            <p className="text-body text-center mb-4" style={{ fontWeight: 500 }}>
              One heavy day changes tomorrow. Several heavy days lead to a person.
            </p>

            <div className="scripted-balu-box mb-3">
              <div className="balu-msg-bubble mb-2">
                <p className="text-body" style={{ margin: 0 }}>
                  On August 22 you said: "I stayed up rewriting the assignment because I knew it wasn't my best work." What happened today?
                </p>
              </div>
              <div className="user-msg-card mb-2">
                <p className="text-voice" style={{ margin: 0 }}>
                  "kuch nahi, bas lagta hai sab aage nikal gaye"
                </p>
              </div>
              <div className="balu-msg-bubble mb-2">
                <p className="text-body" style={{ margin: 0 }}>
                  Sab aage nikal gaye. Kis cheez mein, sabse zyada?
                </p>
              </div>
              <div className="user-msg-card mb-2">
                <p className="text-voice" style={{ margin: 0 }}>
                  "internships, sabke paas hai"
                </p>
              </div>
              <div className="balu-msg-bubble">
                <p className="text-body" style={{ margin: 0 }}>
                  Noted, in your words.
                </p>
              </div>
              <div className="text-caption text-center mt-2" style={{ color: 'var(--color-stone)' }}>
                Balu is part of the app, not a person.
              </div>
            </div>
          </div>
        );

      /* ── SCENE 8: Feature 3 — What It Is Not ── */
      case 8:
        return (
          <div className="story-scene scene-feature scene-final">
            <div className="feature-number">
              <span className="sample-badge">Sample</span>
              <span>What it is not</span>
            </div>

            <div className="what-not-card mt-4 mb-4">
              <div className="what-not-line">
                <span className="what-not-bullet" />
                <span className="what-not-text">Not therapy.</span>
              </div>
              <div className="what-not-line mt-3">
                <span className="what-not-bullet" />
                <span className="what-not-text">Balu asks. It doesn't advise.</span>
              </div>
              <div className="what-not-line mt-3">
                <span className="what-not-bullet" />
                <span className="what-not-text">Your words, not praise.</span>
              </div>
            </div>

            <div className="final-cta">
              <Balu pose="listen" entrance="none" size={80} />
              <p className="text-body text-center mt-3 mb-2" style={{ color: 'var(--color-stone)' }}>
                See how Meera's words are played back to her on a difficult morning.
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  // Top progress bar header
  const headerContent = (
    <div className="story-progress-header">
      <div className="story-progress-track">
        <div
          className="story-progress-fill"
          style={{ width: `${((scene + 1) / totalScenes) * 100}%` }}
        />
      </div>
    </div>
  );

  // Pinned footer slot for Continue buttons
  const footerContent = scene === 0 ? (
    <button
      type="button"
      className="btn btn--primary btn--full"
      onClick={handleNext}
      disabled={isTransitioning}
      aria-label="Continue"
    >
      <span>Continue</span>
      <ArrowRight size={18} strokeWidth={2} style={{ marginLeft: '8px' }} />
    </button>
  ) : scene === totalScenes - 1 ? (
    <button
      type="button"
      className="btn btn--primary btn--full"
      onClick={handleNext}
      disabled={isTransitioning}
    >
      <span>See sample playback</span>
      <ArrowRight size={18} strokeWidth={2} style={{ marginLeft: '8px' }} />
    </button>
  ) : (
    <button
      type="button"
      className="btn btn--primary btn--full"
      onClick={handleNext}
      disabled={isTransitioning}
    >
      <span>Continue</span>
      <ArrowRight size={18} strokeWidth={2} style={{ marginLeft: '8px' }} />
    </button>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      scrollKey={scene}
      className="story-screen-layout"
    >
      {renderSceneContent()}

      <style>{`
        .story-progress-header {
          width: 100%;
          padding-top: 4px;
        }

        .story-progress-track {
          width: 100%;
          height: 3px;
          background: var(--color-sand);
          border-radius: 2px;
          overflow: hidden;
        }

        .story-progress-fill {
          height: 100%;
          background: var(--color-marigold);
          transition: width 0.3s ease;
        }

        .story-scene {
          display: flex;
          flex-direction: column;
          width: 100%;
          box-sizing: border-box;
          word-break: break-word;
          overflow-wrap: break-word;
        }

        /* ── SCENE 0: Opening Lines ── */
        .scene-opening-lines {
          justify-content: center;
          align-items: center;
          text-align: center;
          cursor: pointer;
          user-select: none;
          min-height: 320px;
          padding: 24px 0;
        }
        .opening-lines-wrap {
          display: flex;
          flex-direction: column;
          gap: 28px;
          max-width: 340px;
          width: 100%;
        }
        .opening-line {
          font-family: var(--font-serif);
          font-size: var(--text-headline);
          line-height: var(--lh-heading);
          color: var(--color-ink);
          margin: 0;
          font-weight: 400;
          transition: opacity 0.6s ease, transform 0.6s ease;
        }
        .line-visible {
          opacity: 1;
          transform: translateY(0);
        }
        .line-hidden {
          opacity: 0;
          transform: translateY(12px);
          pointer-events: none;
        }
        .opening-line--accent {
          margin-top: 8px;
        }
        .baseline-text {
          font-size: var(--text-display);
          line-height: var(--lh-heading);
          font-weight: 500;
          color: var(--color-ink);
        }

        /* Marigold highlight band behind Ink text: 40% line height */
        .marigold-highlight-band {
          position: relative;
          display: inline-block;
          color: var(--color-ink);
          z-index: 1;
          white-space: nowrap;
        }
        .marigold-highlight-band::after {
          content: '';
          position: absolute;
          left: -4px;
          right: -4px;
          bottom: 12%;
          height: 40%;
          background-color: var(--color-marigold);
          z-index: -1;
          border-radius: 2px;
        }

        .opening-tap-hint {
          margin-top: 36px;
          text-align: center;
          opacity: 0.8;
        }

        /* ── Balu Speech Bubble Component ── */
        .balu-speech-bubble {
          background: var(--color-bubble);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px 20px;
          font-family: var(--font-sans);
          font-size: var(--text-body);
          line-height: var(--lh-body);
          color: var(--color-ink);
          position: relative;
          z-index: var(--z-bubble, 5);
        }
        .balu-speech-bubble--left-tail::before {
          content: '';
          position: absolute;
          left: -8px;
          top: 24px;
          width: 0;
          height: 0;
          border-top: 6px solid transparent;
          border-bottom: 6px solid transparent;
          border-right: 8px solid var(--color-bubble);
          z-index: 2;
        }
        .balu-speech-bubble--left-tail::after {
          content: '';
          position: absolute;
          left: -9px;
          top: 24px;
          width: 0;
          height: 0;
          border-top: 6px solid transparent;
          border-bottom: 6px solid transparent;
          border-right: 9px solid var(--color-sand);
          z-index: 1;
        }

        .balu-intro-row {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        /* ── Meera Story Section ── */
        .meera-story-container {
          display: flex;
          flex-direction: column;
          position: relative;
          padding-top: 52px;
          margin-top: 6px;
        }
        .meera-name-row {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .meera-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px 24px;
          z-index: var(--z-card, 2);
          position: relative;
        }
        .meera-card-header {
          display: flex;
          align-items: center;
          gap: 14px;
          position: relative;
        }
        .meera-avatar-badge {
          width: 52px;
          height: 52px;
          border-radius: 50%;
          background-color: var(--color-peach);
          border: 1px solid var(--color-ink);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .meera-initial {
          font-family: var(--font-serif);
          font-size: 26px;
          font-weight: 500;
          color: var(--color-ink);
          line-height: 1;
        }
        .meera-meta {
          flex: 1;
        }
        .meera-name {
          font-family: var(--font-sans);
          font-size: var(--text-body);
          font-weight: 600;
          color: var(--color-ink);
        }
        .meera-label {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          margin-top: 2px;
        }
        .meera-sample-tag {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          position: absolute;
          top: 0;
          right: 0;
        }

        .meera-achievements-box {
          margin-top: 18px;
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: 12px;
          padding: 14px 16px;
        }
        .achievements-heading {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 600;
          color: var(--color-stone);
          margin-bottom: 10px;
          text-transform: uppercase;
          letter-spacing: 0.03em;
        }
        .achievement-row {
          display: flex;
          align-items: center;
          gap: 10px;
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-ink);
          padding: 6px 0;
        }
        .achievement-check {
          color: var(--color-leaf);
          flex-shrink: 0;
        }
        .sand-divider {
          height: 1px;
          background: var(--color-sand);
          margin: 2px 0;
        }

        .meera-story-box {
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: 12px;
          padding: 14px 16px;
        }
        .story-box-title {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 600;
          color: var(--color-stone);
          margin-bottom: 6px;
          text-transform: uppercase;
          letter-spacing: 0.03em;
        }
        .story-box-body {
          font-family: var(--font-sans);
          font-size: 14px;
          line-height: var(--lh-body);
          color: var(--color-stone);
          margin: 0;
        }

        .meera-insight-box {
          border-top: 1px solid var(--color-sand);
          padding-top: 12px;
        }
        .insight-text {
          font-family: var(--font-sans);
          font-size: 14px;
          line-height: var(--lh-body);
          color: var(--color-ink);
          margin: 0;
        }

        .balu-peek-side {
          position: absolute;
          right: 14px;
          top: 0px;
          pointer-events: none;
          z-index: var(--z-mascot, 10);
        }

        /* ── Scene 2 & 3: Cards & Montage ── */
        .voice-recording-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px 24px;
          z-index: var(--z-card, 2);
        }
        .recording-header {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .rec-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #EA4335;
        }
        .waveform-visual {
          display: flex;
          align-items: center;
          gap: 3px;
          height: 36px;
        }
        .wave-bar {
          flex: 1;
          background: var(--color-stone);
          opacity: 0.45;
          border-radius: 2px;
        }

        .balu-reaction-row {
          display: flex;
          align-items: flex-start;
          gap: 12px;
        }
        .scene-tags-demo {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }
        .auto-tag {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-leaf);
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          padding: 6px 14px;
          border-radius: var(--radius-pill);
        }

        .progress-montage {
          display: flex;
          flex-direction: column;
        }
        .montage-entry {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px 20px;
          z-index: var(--z-card, 2);
        }
        .montage-date {
          font-family: var(--font-sans);
          font-size: 14px;
          font-weight: 600;
          color: var(--color-stone);
        }
        .auto-tag-small {
          display: inline-block;
          font-family: var(--font-sans);
          font-size: 12px;
          color: var(--color-leaf);
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          padding: 4px 10px;
          border-radius: var(--radius-pill);
        }
        .balu-aside {
          display: flex;
          align-items: center;
          gap: 12px;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 14px 18px;
        }

        /* ── Scene 4: Intervention ── */
        .intervention-header {
          display: flex;
          justify-content: center;
        }
        .intervention-quote {
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: 14px;
          padding: 16px 20px;
          z-index: var(--z-card, 2);
        }
        .quote-attribution {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          font-weight: 600;
          margin-bottom: 6px;
        }

        /* ── Scene 5: Result ── */
        .result-stat-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }
        .result-stat {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: 16px;
          padding: 16px 8px;
          text-align: center;
        }
        .stat-number {
          font-family: var(--font-serif);
          font-size: 26px;
          font-weight: 600;
          color: var(--color-ink);
        }
        .stat-label {
          font-family: var(--font-sans);
          font-size: 12px;
          color: var(--color-stone);
          margin-top: 4px;
        }
        .result-message {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        /* ── Scene 6: Feature ── */
        .feature-number {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .sample-badge {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          padding: 2px 8px;
          border-radius: var(--radius-pill);
        }
        .feature-demo-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px;
        }
        .feature-demo-actions {
          display: flex;
          gap: 10px;
          margin-top: 14px;
        }
        .demo-action-btn {
          flex: 1;
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-pill);
          padding: 10px;
          text-align: center;
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-ink);
        }
        .balu-feature-aside {
          display: flex;
          align-items: center;
          gap: 12px;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 14px 18px;
        }

        /* ── Scene 7: Lockscreen & Scripted ── */
        .mock-lockscreen {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .lockscreen-clock {
          font-family: var(--font-sans);
          font-size: 32px;
          font-weight: 300;
          color: var(--color-ink);
        }
        .lockscreen-date {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          margin-bottom: 14px;
        }
        .lockscreen-notification {
          width: 100%;
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: 12px;
          padding: 12px 14px;
          margin-bottom: 8px;
        }
        .notif-header {
          display: flex;
          align-items: center;
          gap: 6px;
        }
        .notif-icon {
          width: 14px;
          height: 14px;
          border-radius: 3px;
          display: block;
        }
        .notif-app {
          font-family: var(--font-sans);
          font-size: 12px;
          font-weight: 600;
          color: var(--color-stone);
        }
        .notif-time {
          font-family: var(--font-sans);
          font-size: 12px;
          color: var(--color-stone);
          margin-left: auto;
        }
        .notif-body {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-ink);
          margin-top: 4px;
        }

        .scripted-balu-box {
          display: flex;
          flex-direction: column;
        }
        .balu-msg-bubble {
          background: var(--color-bubble);
          border: 1px solid var(--color-sand);
          border-radius: 14px;
          padding: 12px 16px;
          align-self: flex-start;
          max-width: 90%;
        }
        .user-msg-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: 14px;
          padding: 12px 16px;
          align-self: flex-end;
          max-width: 90%;
        }

        /* ── Scene 8: What Not ── */
        .what-not-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 20px 24px;
        }
        .what-not-line {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .what-not-bullet {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: var(--color-ink);
          flex-shrink: 0;
        }
        .what-not-text {
          font-family: var(--font-sans);
          font-size: var(--text-body);
          color: var(--color-ink);
        }
        .final-cta {
          display: flex;
          flex-direction: column;
          align-items: center;
        }
      `}</style>
    </ScreenLayout>
  );
}
