import React from 'react';
import { ArrowRight } from 'lucide-react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Objective Screen — states the purpose and offers two paths.
 * Converted to unified ScreenLayout with pinned actions in footer slot.
 */
export default function ObjectiveScreen({ onStartTour, onStartOwn, onWhyExists }) {
  const footerContent = (
    <div className="objective-actions w-full">
      <button 
        type="button"
        className="btn btn--primary btn--full mb-2" 
        onClick={onStartTour}
      >
        See it with a sample student
      </button>
      
      <button 
        type="button"
        className="btn btn--secondary btn--full mb-4" 
        onClick={onStartOwn}
      >
        Start my own
      </button>
      
      <button 
        type="button"
        className="btn btn--ghost" 
        onClick={onWhyExists}
        style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}
      >
        <span>Why this exists</span>
        <ArrowRight size={16} strokeWidth={2} />
      </button>
    </div>
  );

  return (
    <ScreenLayout
      footer={footerContent}
      bg="cream"
      className="objective-screen-layout"
    >
      <div className="objective-center-content">
        <p className="text-display mb-6">
          This app keeps your<br />
          belief in yourself<br />
          intact.
        </p>
      </div>

      <style>{`
        .objective-center-content {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          width: 100%;
          max-width: 320px;
          margin: 0 auto;
        }
        .objective-center-content .text-display {
          font-family: var(--font-sans);
          font-size: var(--text-headline);
          font-weight: 500;
          letter-spacing: -0.01em;
          text-align: left;
        }
        .objective-actions {
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
