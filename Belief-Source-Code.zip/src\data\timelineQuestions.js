/**
 * Timeline questions restored from conversation history.
 * Unaltered exact wording:
 * Q1: "To understand where you're going, I need to know where you started. Tell me about a time you felt completely confident in yourself."
 * Q2: "What was the hardest thing you had to overcome to get where you are today?"
 */

export const TIMELINE_QUESTIONS = [
  {
    id: 'timeline_q1',
    number: 1,
    title: "Where you started",
    question: "To understand where you're going, I need to know where you started. Tell me about a time you felt completely confident in yourself.",
    year: "Beginning",
    placeholder: "Tell your story in your own words..."
  },
  {
    id: 'timeline_q2',
    number: 2,
    title: "What you overcame",
    question: "What was the hardest thing you had to overcome to get where you are today?",
    year: "Milestone",
    placeholder: "Describe what happened and how you got through it..."
  }
];
