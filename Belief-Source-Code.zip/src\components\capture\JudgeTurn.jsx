import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useAudioRecorder } from '../../hooks/useAudioRecorder';
import { useTranscription } from '../../hooks/useTranscription';
import { getTodaysPrompt } from '../../data/sampleStudent';

/**
 * Judge Turn — allows the judge to test the voice capture live.
 */
export default function JudgeTurn({ isTour }) {
  const [mode, setMode] = useState('capture'); // 'capture', 'typing', 'transcript', 'saved'
  const todaysPrompt = getTodaysPrompt();
  
  const { 
    isRecording, 
    duration, 
    error: recorderError, 
    startRecording, 
    stopRecording 
  } = useAudioRecorder();
  
  const { 
    transcript, 
    isSupported, 
    startListening, 
    stopListening, 
    updateTranscript 
  } = useTranscription();

  const handleStartRecord = async () => {
    if (!isRecording) {
      await startRecording();
      if (isSupported) {
        startListening();
      }
    } else {
      stopRecording();
      if (isSupported) {
        stopListening();
      }
      setMode('transcript');
    }
  };

  const handleTypeInstead = () => {
    setMode('typing');
    updateTranscript('');
  };

  const handleOneTap = () => {
    updateTranscript('I showed up today.');
    setMode('transcript');
  };

  const handleSave = () => {
    setMode('saved');
  };

  if (mode === 'saved') {
    return (
      <div className="judge-turn page-content--centered animate-fade-in">
        <div className="spacer" />
        <div className="text-headline mb-4">Saved.</div>
        <div className="text-body mb-6">
          In the real app, this entry becomes part of your timeline.
        </div>
        <div className="spacer" />
      </div>
    );
  }

  if (mode === 'transcript' || mode === 'typing') {
    return (
      <div className="judge-turn animate-fade-in">
        <div className="mb-4">
          <button className="btn btn--ghost" onClick={() => setMode('capture')} style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}>
            <ArrowLeft size={16} strokeWidth={2} />
            <span>Cancel</span>
          </button>
        </div>
        
        <h2 className="text-body mb-4" style={{ opacity: 0.7 }}>{todaysPrompt}</h2>
        
        <div className="mb-4">
          <textarea
            className={mode === 'typing' ? 'text-input' : 'transcript-editor'}
            value={transcript}
            onChange={(e) => updateTranscript(e.target.value)}
            placeholder={mode === 'typing' ? 'Type your answer here...' : 'Listening...'}
            autoFocus={mode === 'typing'}
          />
        </div>
        
        <button 
          className="btn btn--primary btn--full" 
          onClick={handleSave}
          disabled={!transcript.trim()}
        >
          Save entry
        </button>
      </div>
    );
  }

  return (
    <div className="judge-turn flex-col animate-fade-in" style={{ height: '100%' }}>
      <div className="text-small mb-4" style={{ color: 'var(--color-leaf)', fontWeight: 500, textAlign: 'center' }}>
        Your turn.
      </div>
      
      <div className="home-header" style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
        <h1 className="text-headline mb-6">{todaysPrompt}</h1>
        
        <div className="capture-area mb-4">
          <button 
            className={`record-btn mb-2 ${isRecording ? 'record-btn--recording record-btn--stop' : ''}`} 
            onClick={handleStartRecord}
          >
            <div className="record-btn__icon">
              {isRecording ? (
                <div style={{ width: '24px', height: '24px', backgroundColor: 'var(--color-ink)', borderRadius: '4px' }}></div>
              ) : (
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
                </svg>
              )}
            </div>
          </button>
          
          <div className="text-small mt-2" style={{ height: '20px' }}>
            {isRecording ? `Recording... 0:${duration.toString().padStart(2, '0')}` : '30 seconds is enough'}
          </div>
          
          {recorderError && (
            <div className="text-caption mt-2" style={{ color: '#D32F2F' }}>
              {recorderError === 'microphone-denied' 
                ? 'Microphone access denied.' 
                : recorderError}
            </div>
          )}
        </div>
      </div>
      
      {!isRecording && (
        <div className="alternative-actions mt-auto pb-4">
          <div className="card mb-3" style={{ padding: 'var(--space-2)' }}>
            <div className="text-caption mb-1" style={{ opacity: 0.7 }}>or type</div>
            <button className="btn btn--secondary btn--full btn--small" onClick={handleTypeInstead}>
              Type instead
            </button>
          </div>
          
          <div className="card" style={{ padding: 'var(--space-2)' }}>
            <div className="text-caption mb-1" style={{ opacity: 0.7 }}>or just tap</div>
            <button className="btn btn--secondary btn--full btn--small" onClick={handleOneTap} style={{ justifyContent: 'flex-start', textAlign: 'left', fontWeight: 400 }}>
              I showed up today.
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
