import { getStoredAuth, setStoredAuth } from './db.js';

async function getAuthHeaders() {
  const auth = await getStoredAuth();
  if (!auth || !auth.token || !auth.userId) return {};
  return {
    Authorization: `Bearer ${auth.token}`,
    'X-User-Id': auth.userId,
  };
}

function isJudgeDemo() {
  if (typeof window !== 'undefined') {
    try {
      return window.sessionStorage?.getItem('belief_is_demo') === '1';
    } catch {
      return false;
    }
  }
  return false;
}

export async function registerUser() {
  if (isJudgeDemo()) {
    const demoCreds = {
      userId: 'demo-judge-' + Math.random().toString(36).substring(2, 9),
      token: 'demo-token-' + Math.random().toString(36).substring(2, 9),
    };
    await setStoredAuth(demoCreds);
    return demoCreds;
  }

  try {
    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });
    if (!res.ok) throw new Error('Registration failed');
    const data = await res.json();
    await setStoredAuth({ userId: data.userId, token: data.token });
    return data;
  } catch (err) {
    // Return mock offline fallback credentials if server is not reachable
    const mockCreds = {
      userId: 'local-user-' + Math.random().toString(36).substring(2, 9),
      token: 'local-token-' + Math.random().toString(36).substring(2, 9),
    };
    await setStoredAuth(mockCreds);
    return mockCreds;
  }
}

export async function subscribePush(subscription) {
  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ subscription }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function unsubscribePush(endpoint) {
  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/subscribe', {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ endpoint }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function sendHeartbeat(date, score) {
  if (isJudgeDemo()) return true;
  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/heartbeat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ date, score }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function updateServerSettings(settings) {
  if (isJudgeDemo()) return true;
  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(settings),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function transcribeAudio(audioBlob) {
  // Never return fake or pre-fit text
  if (isJudgeDemo()) {
    return '';
  }

  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/transcribe', {
      method: 'POST',
      headers: {
        'Content-Type': audioBlob.type || 'audio/webm',
        ...headers,
      },
      body: audioBlob,
    });
    if (!res.ok) throw new Error('Transcription failed');
    const data = await res.json();
    return data.text || '';
  } catch (err) {
    return '';
  }
}

export async function analyzeEntry(transcript, moodTap = null) {
  // Demo account: nothing typed/recorded is sent to or saved on server
  if (isJudgeDemo()) {
    const keywordHit = /kill myself|suicide|end my life|want to die|take my own life/i.test(transcript);
    const level = keywordHit ? 3 : (moodTap === 'low' ? 1 : 0);
    return {
      level,
      evidence: [],
      smallThings: ['showed up today'],
      crisis: level === 3,
    };
  }

  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ transcript, moodTap }),
    });
    if (!res.ok) throw new Error('Analyze failed');
    return await res.json();
  } catch (err) {
    // Local offline fallback
    const keywordHit = /kill myself|suicide|end my life|want to die|take my own life/i.test(transcript);
    const level = keywordHit ? 3 : (moodTap === 'low' ? 1 : 0);
    return {
      level,
      evidence: [],
      smallThings: ['showed up today'],
      crisis: level === 3,
    };
  }
}

export async function sendCheckinReply(reply) {
  if (isJudgeDemo()) return true;
  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/checkin-reply', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify({ reply }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function interactWithBalu(payload) {
  if (isJudgeDemo()) {
    const turn = payload.turn || 1;
    const isCrisis = /kill myself|suicide|end my life|want to die/i.test(
      (payload.messages || []).slice(-1)[0]?.content || ''
    );
    if (isCrisis) {
      return { crisis: true };
    }
    if (turn >= 3) {
      return { reply: 'Noted, in your words.', end: true, crisis: false };
    }
    return {
      reply: 'Tell me a bit more about that.',
      end: false,
      crisis: false,
    };
  }

  const headers = await getAuthHeaders();
  try {
    const res = await fetch('/api/balu', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error('Balu API call failed');
    return await res.json();
  } catch (err) {
    // Offline / Mock fallback
    const turn = payload.turn || 1;
    const isCrisis = /kill myself|suicide|end my life|want to die/i.test(
      (payload.messages || []).slice(-1)[0]?.content || ''
    );
    if (isCrisis) {
      return { crisis: true };
    }
    if (turn >= 3) {
      return { reply: 'Noted, in your words.', end: true, crisis: false };
    }
    return {
      reply: 'Tell me a bit more about that.',
      end: false,
      crisis: false,
    };
  }
}
