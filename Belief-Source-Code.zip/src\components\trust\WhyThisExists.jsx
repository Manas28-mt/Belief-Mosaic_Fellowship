import React from 'react';
import { ArrowLeft } from 'lucide-react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Why This Exists — the research page explaining the big-fish-little-pond effect.
 * Converted to unified ScreenLayout with pinned footer.
 */
export default function WhyThisExists({ onBack }) {
  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  );

  const footerContent = (
    <button type="button" className="btn btn--secondary btn--full" onClick={onBack}>
      Close
    </button>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      className="why-this-exists-layout"
    >
      <div className="why-this-exists-content animate-fade-in">
        <h1 className="text-headline mb-4">Why this exists</h1>
        
        <div className="text-body flex-col gap-4">
          <p>
            Students who were top of their school often lose belief in themselves at top universities, because everyone around them was also top of their school.
          </p>
          
          <p>
            Psychologists call this the <strong>big-fish-little-pond effect</strong>. Self-image drops when the comparison group changes, even though ability has not.
          </p>
          
          <p>
            This app was built after speaking with thousands of students at Delhi University's North Campus. We found a common thread: students believe they are doing nothing now, compared with what they did at school.
          </p>
          
          <p>
            They do not acknowledge what they do every day. They do not see the value of where they stand.
          </p>
          
          <p>
            But a belief in yourself built over 20 years cannot be defined by one bad month.
          </p>
          
          <p>
            This app is designed to remind you of your own journey: where you were, and how far you have come at your own pace. Not with praise from an app, but with your own exact words.
          </p>
        </div>
      </div>

      <style>{`
        .why-this-exists-content {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
