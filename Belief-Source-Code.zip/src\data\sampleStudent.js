/**
 * Sample Student: Meera
 * 
 * An invented North Campus student with months of entries,
 * a filled timeline, saved notes from friends, and at least
 * one setback followed by a recovery.
 * 
 * RULES (from the Bible):
 * - Every quote is an exact substring of its entry transcript
 * - The fact line is arithmetically true of this data
 * - No praise, no advice, no cheer
 * - Tags: effort, showing up, helping someone, failed attempts
 */

export const sampleStudent = {
  name: 'Meera',
  college: 'IIT Bombay',
  course: 'BTech CSE',
  year: 'Second Year',
  hometown: 'Jaipur',
};

export const sampleTimeline = [
  { id: 1, year: 2006, label: 'Born in Jaipur', isMilestone: true },
  { id: 2, year: 2011, label: 'Started school', isMilestone: false },
  { id: 3, year: 2015, label: 'Won the district science fair', isMilestone: true },
  { id: 4, year: 2017, label: 'Started tutoring younger students', isMilestone: false },
  { id: 5, year: 2019, label: 'School science fair — first place', isMilestone: true },
  { id: 6, year: 2020, label: 'COVID year — studied alone, topped online exams', isMilestone: false },
  { id: 7, year: 2021, label: 'Elected head girl', isMilestone: true },
  { id: 8, year: 2022, label: 'Led the school debate team to nationals', isMilestone: true },
  { id: 9, year: 2023, label: 'Class 12 boards — 96.4%', isMilestone: true },
  { id: 10, year: 2024, label: 'JEE Advanced — Top 0.5 percentile', isMilestone: true },
  { id: 11, year: 2024, label: 'Joined IIT Bombay, BTech CSE', isMilestone: true },
  { id: 12, year: 2024, label: 'First mid-sem — felt like failing', isMilestone: false },
  { id: 13, year: 2025, label: 'Figured out how to study again', isMilestone: false },
  { id: 14, year: 2025, label: 'Helped 4 classmates prep for retests', isMilestone: true },
  { id: 15, year: 2025, label: 'Started reading papers on her own', isMilestone: false },
  { id: 16, year: 2026, label: 'Placement anxiety — still 2 years away', isMilestone: false },
  { id: 17, year: 2026, label: 'Internship application — got rejected, applied again', isMilestone: false },
  { id: 18, year: 2026, label: 'Semester results — did better than expected', isMilestone: true },
  { id: 19, year: 2026, label: 'This month', isMilestone: false, isCurrent: true },
];

export const sampleEntries = [
  {
    id: 1,
    date: '2026-05-14',
    prompt: 'What did you do today that was hard?',
    transcript: "I sat through the entire macro lecture even though I understood maybe half of it. Everyone else was nodding like it made sense. I went back to the library after and re-read the chapter twice. It still didn't fully click but I wrote down every part I didn't get so I could ask Riya tomorrow.",
    tags: ['Showed up to a hard class', 'Re-read the chapter twice', 'Made a list of doubts'],
    mood: 'rough',
    isSample: true,
  },
  {
    id: 2,
    date: '2026-05-28',
    prompt: 'What did you figure out today?',
    transcript: "I finally understand how Keynes got it right about sticky wages. It took me three weeks and four YouTube videos but today in the tutorial I actually answered a question before anyone else. I don't think anyone noticed but I did.",
    tags: ['Figured something out on her own', 'Spoke up in a tutorial', 'Three weeks of effort paid off'],
    mood: 'okay',
    isSample: true,
  },
  {
    id: 3,
    date: '2026-06-10',
    prompt: 'What did you almost skip today but do anyway?',
    transcript: "Almost didn't go to the 8am tutorial because I slept at 3 finishing the assignment. But I went. Half the class didn't show up. The professor covered Nash equilibrium and I actually followed most of it. I even explained it to Arjun after class because he missed it.",
    tags: ['Showed up despite no sleep', 'Followed a complex topic', 'Helped a friend'],
    mood: 'okay',
    isSample: true,
  },
  {
    id: 4,
    date: '2026-07-02',
    prompt: 'What would Class 12 you have found scary about today?',
    transcript: "I submitted a paper that I'm not sure is good enough. In school I would have panicked and rewritten it five times. Today I just submitted it and moved on. I think that's growth but it also feels like giving up. I don't know which one.",
    tags: ['Submitted work despite doubt', 'Noticed her own growth', 'Honest about uncertainty'],
    mood: 'rough',
    isSample: true,
  },
  {
    id: 5,
    date: '2026-07-20',
    prompt: 'What did you do today that nobody saw?',
    transcript: "I spent two hours helping Priya understand regression analysis before her retest. She was panicking and I remembered exactly what that felt like in first year. I didn't tell anyone because it sounds like showing off. But I think I'm actually good at explaining things.",
    tags: ['Helped a friend for two hours', 'Used her own difficult experience', 'Recognised a strength'],
    mood: 'okay',
    isSample: true,
  },
  {
    id: 6,
    date: '2026-08-05',
    prompt: 'What did you do today that was hard?',
    transcript: "I thought I'd never get through macro. The mid-sem is in two weeks and I still mix up IS-LM every single time. I studied for four hours today and it still feels like I know nothing. Everyone in my batch seems so much further ahead.",
    tags: ['Studied for four hours', 'Preparing despite feeling behind'],
    mood: 'rough',
    isSample: true,
  },
  {
    id: 7,
    date: '2026-08-22',
    prompt: 'What did you figure out today?',
    transcript: "I stayed up rewriting the entire assignment because I knew it wasn't my best work. Riya helped me debug the last part. I don't know if the professor will even notice the difference but I know it's better now. That should count for something.",
    tags: ['Redid work to a higher standard', 'Asked for help', 'Finished it'],
    mood: 'okay',
    isSample: true,
  },
  {
    id: 8,
    date: '2026-09-10',
    prompt: 'What did you almost skip today but do anyway?',
    transcript: "Applied for the summer internship at ICRIER even though I'm sure I won't get it. Everyone applying has published papers or has connections. I just have my coursework. But I wrote the application properly and sent it. If they reject me at least it's not because I didn't try.",
    tags: ['Applied despite feeling unqualified', 'Wrote a proper application', 'Tried anyway'],
    mood: 'rough',
    isSample: true,
  },
  {
    id: 9,
    date: '2026-09-29',
    prompt: 'What did you do today that was hard?',
    transcript: "Macro paper went better than I expected. I actually knew most of the answers. Three months ago I couldn't even get through the textbook chapter. I don't want to say I did well because every time I think that something goes wrong. But it went okay. It went okay.",
    tags: ['Did better than expected', 'Saw her own progress', 'Three months of work'],
    mood: 'okay',
    isSample: true,
  },
  {
    id: 10,
    date: '2026-10-07',
    prompt: 'What did you do today that nobody saw?',
    transcript: "Re-read my own notes from May. I didn't understand half the stuff I was writing about back then but now it makes sense. It's weird how that happens. I feel like I'm not moving but then I look back and I clearly am. Maybe everyone else feels the same way.",
    tags: ['Reflected on her own progress', 'Noticed growth', 'Showed self-awareness'],
    mood: 'okay',
    isSample: true,
  },
];

/**
 * Quotes for bad-day mode.
 * Each is an exact substring of an entry transcript above.
 * The pair: a low moment followed by a recovery.
 */
export const sampleQuotePairs = [
  {
    low: {
      entryId: 6,
      date: '2026-08-05',
      quote: "I thought I'd never get through macro.",
    },
    recovery: {
      entryId: 9,
      date: '2026-09-29',
      quote: "Macro paper went better than I expected. I actually knew most of the answers.",
    },
  },
  {
    low: {
      entryId: 1,
      date: '2026-05-14',
      quote: "I sat through the entire macro lecture even though I understood maybe half of it.",
    },
    recovery: {
      entryId: 2,
      date: '2026-05-28',
      quote: "I finally understand how Keynes got it right about sticky wages.",
    },
  },
  {
    low: {
      entryId: 8,
      date: '2026-09-10',
      quote: "I'm sure I won't get it. Everyone applying has published papers or has connections.",
    },
    recovery: {
      entryId: 8,
      date: '2026-09-10',
      quote: "I wrote the application properly and sent it. If they reject me at least it's not because I didn't try.",
    },
  },
];

/**
 * Fact line — arithmetically true of the sample data.
 * 
 * Entries span May 14 to Oct 7 = ~5 months
 * Rough moods: entries 1, 4, 6, 8 = 4 setbacks
 * She got through all of them (subsequent entries show recovery)
 */
export const sampleFactLine = '5 months. 4 setbacks. You got through all 4.';

/** Friend notes — exact quotes */
export const sampleFriendNotes = [
  {
    id: 1,
    from: 'Riya',
    text: 'You explained Nash equilibrium to me in 5 minutes flat.',
    date: '2026-09-20',
  },
  {
    id: 2,
    from: 'Arjun',
    text: 'You showed up to the 8am tutorial every single day last month. I noticed.',
    date: '2026-09-28',
  },
];

/** Prompt library — small set for the demo */
export const prompts = [
  'What did you do today that was hard?',
  'What did you almost skip today but do anyway?',
  'What did you figure out today?',
  'What did you do today that nobody saw?',
  'What would Class 12 you have found scary about today?',
];

/**
 * Returns today's prompt (rotates by day of year)
 */
export function getTodaysPrompt() {
  const now = new Date();
  const dayOfYear = Math.floor(
    (now - new Date(now.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24)
  );
  return prompts[dayOfYear % prompts.length];
}

/** Crisis contacts — to be verified before submission */
export const helpContacts = [
  {
    name: 'iCall',
    number: '9152987821',
    description: 'Psychosocial helpline by TISS',
  },
  {
    name: 'Vandrevala Foundation',
    number: '1860-2662-345',
    description: '24/7 mental health support',
  },
];
