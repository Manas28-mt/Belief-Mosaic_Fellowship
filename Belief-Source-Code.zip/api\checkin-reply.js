import { authenticateRequest } from '../server/lib/auth.js';
import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { reply } = req.body || {};
  if (!reply || !['busy', 'rough', 'bored'].includes(reply)) {
    return res.status(400).json({ error: 'Valid reply required: busy, rough, bored' });
  }

  if (reply === 'bored') {
    if (isUsingMockDb) {
      const mockStore = getMockStore();
      const storedUser = mockStore.users.get(user.id);
      if (storedUser) {
        storedUser.frequency = 'reduced';
      }
      return res.status(200).json({ success: true, frequency: 'reduced' });
    }

    const sql = getDb();
    if (!sql) return res.status(500).json({ error: 'Database unavailable' });

    try {
      await sql`
        UPDATE users
        SET frequency = 'reduced'
        WHERE id = ${user.id}
      `;
      return res.status(200).json({ success: true, frequency: 'reduced' });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to update frequency' });
    }
  }

  return res.status(200).json({ success: true });
}
