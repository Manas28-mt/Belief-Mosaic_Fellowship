import React, { useEffect, useRef } from 'react';

/**
 * ScreenLayout — The single unified layout for every screen in Belief.
 * 
 * Rules:
 * - Flex column filling the phone frame's height (100dvh at frame level, never 100vh).
 * - Body is the ONLY scroll area: flex 1, overflow-y auto, min-height 0.
 * - Continue/Next live only in a footer slot OUTSIDE the scroll area, pinned to the bottom of the frame,
 *   with padding-bottom max(24px, env(safe-area-inset-bottom)) and a soft cream fade above.
 * - Removes every fixed, sticky, absolute or margin hack used for buttons.
 * - Every screen opens scrolled to the top.
 */
export default function ScreenLayout({
  header = null,
  children,
  footer = null,
  bg = 'cream', // 'cream' | 'peach'
  className = '',
  bodyClassName = '',
  footerClassName = '',
  scrollRef = null,
  onScroll = null,
  scrollKey = null,
  'data-testid': testId = 'screen-layout',
}) {
  const internalScrollRef = useRef(null);
  const activeScrollRef = scrollRef || internalScrollRef;

  // Rule: Every screen opens scrolled to the top (and resets on scrollKey change)
  useEffect(() => {
    if (activeScrollRef.current) {
      activeScrollRef.current.scrollTop = 0;
    }
  }, [activeScrollRef, scrollKey]);

  const bgClass =
    bg === 'peach'
      ? 'screen-layout--peach'
      : bg === 'yellow' || bg === 'marigold'
      ? 'screen-layout--yellow'
      : 'screen-layout--cream';

  return (
    <div className={`screen-layout ${bgClass} ${className}`} data-testid={testId}>
      {/* Optional Top Header Slot */}
      {header && (
        <header className="screen-layout__header" data-testid="screen-layout-header">
          {header}
        </header>
      )}

      {/* The ONLY scroll area on the screen */}
      <main
        ref={activeScrollRef}
        className={`screen-layout__body ${bodyClassName}`}
        onScroll={onScroll}
        data-testid="screen-layout-body"
        tabIndex={-1}
      >
        {children}
      </main>

      {/* Footer Slot: OUTSIDE the scroll area, pinned to bottom of the frame */}
      {footer && (
        <footer className={`screen-layout__footer-slot ${footerClassName}`} data-testid="screen-layout-footer">
          <div className="screen-layout__footer-fade" aria-hidden="true" />
          <div className="screen-layout__footer-inner">
            {footer}
          </div>
        </footer>
      )}

      <style>{`
        .screen-layout {
          width: 100%;
          height: 100%;
          flex: 1;
          display: flex;
          flex-direction: column;
          min-height: 0;
          position: relative;
          overflow: hidden;
          box-sizing: border-box;
          word-break: break-word;
          overflow-wrap: break-word;
        }

        .screen-layout--cream {
          background-color: var(--color-cream);
        }

        .screen-layout--peach {
          background-color: var(--color-peach);
        }

        .screen-layout--yellow {
          background-color: var(--color-marigold);
        }

        .screen-layout__header {
          flex-shrink: 0;
          z-index: var(--z-header, 40);
          padding: 16px 24px 8px;
          display: flex;
          align-items: center;
          width: 100%;
          box-sizing: border-box;
        }

        /* The ONLY scroll area */
        .screen-layout__body {
          flex: 1;
          display: flex;
          flex-direction: column;
          overflow-y: auto;
          overflow-x: hidden;
          min-height: 0;
          padding: 16px 24px 24px;
          box-sizing: border-box;
          scrollbar-width: none;
          -webkit-overflow-scrolling: touch;
          word-break: break-word;
          overflow-wrap: break-word;
        }

        .screen-layout__body::-webkit-scrollbar {
          display: none;
        }

        /* Footer slot pinned at bottom */
        .screen-layout__footer-slot {
          flex-shrink: 0;
          z-index: var(--z-footer, 30);
          display: flex;
          flex-direction: column;
          width: 100%;
          position: relative;
          pointer-events: none;
        }

        .screen-layout__footer-fade {
          height: 24px;
          width: 100%;
          flex-shrink: 0;
          pointer-events: none;
        }

        .screen-layout--cream .screen-layout__footer-fade {
          background: linear-gradient(to bottom, rgba(251, 245, 230, 0), rgba(251, 245, 230, 0.95));
        }

        .screen-layout--peach .screen-layout__footer-fade {
          background: linear-gradient(to bottom, rgba(248, 220, 200, 0), rgba(248, 220, 200, 0.95));
        }

        .screen-layout__footer-inner {
          pointer-events: auto;
          display: flex;
          flex-direction: column;
          width: 100%;
          padding: 0 24px max(24px, env(safe-area-inset-bottom));
          box-sizing: border-box;
        }

        .screen-layout--cream .screen-layout__footer-inner {
          background-color: var(--color-cream);
        }

        .screen-layout--peach .screen-layout__footer-inner {
          background-color: var(--color-peach);
        }
      `}</style>
    </div>
  );
}
