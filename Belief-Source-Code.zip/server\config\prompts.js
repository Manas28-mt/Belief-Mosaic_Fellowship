export const PROMPTS = [
  "What did you almost skip today but do anyway?",
  "What did you do today that nobody saw?",
  "What did you figure out today?",
  "What would Class 12 you have found scary about today?",
];

/**
 * Returns prompt rotated by day of year.
 * @param {Date} date
 */
export function getPromptForDate(date) {
  const d = date || new Date();
  const start = new Date(d.getFullYear(), 0, 0);
  const diff = d - start;
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  return PROMPTS[dayOfYear % PROMPTS.length];
}
