import React from 'react';
import Balu from '../balu/Balu.jsx';

/**
 * BearMascot — Compatibility bridge mapping old mood props to Balu vector mascot.
 * Eliminates 3D images and emojis.
 */
export default function BearMascot({ mood = 'neutral', size = 120, className = '' }) {
  const poseMap = {
    neutral: 'listen',
    happy: 'wave',
    sad: 'soft',
    empathetic: 'listen',
    wave: 'wave',
    point: 'point',
    thinking: 'think',
    surprised: 'surprised',
  };

  return (
    <Balu
      pose={poseMap[mood] || 'listen'}
      size={size}
      className={className}
    />
  );
}
