import React, { useState, useEffect, useRef } from 'react';
import Balu from './Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';

const POSES = [
  { id: 'wave', name: 'Wave', desc: 'waving, happy' },
  { id: 'peek', name: 'Peek', desc: 'leaning in from the right, curious' },
  { id: 'point', name: 'Point', desc: 'pointing to his left, encouraging' },
  { id: 'listen', name: 'Listen', desc: 'hands together, head tilted, attentive' },
  { id: 'think', name: 'Think', desc: 'hand on chin, looking up' },
  { id: 'talk', name: 'Talk', desc: 'mid-sentence, friendly open mouth' },
  { id: 'soft', name: 'Soft', desc: 'calm, gentle small smile, caring' },
  { id: 'nod', name: 'Nod', desc: 'eyes closed, content' },
  { id: 'fly', name: 'Fly', desc: 'wings spread, tilted forward, joyful' },
  { id: 'surprised', name: 'Surprised', desc: 'brows up, small o mouth' },
];

const ENTRANCES = [
  { id: 'pop', name: 'Pop (Spring)' },
  { id: 'peekLeft', name: 'Peek Left' },
  { id: 'peekRight', name: 'Peek Right' },
  { id: 'flyIn', name: 'Fly In' },
  { id: 'hop', name: 'Hop (8px)' },
  { id: 'none', name: 'None' },
];

export default function BaluPlayground({ onBack }) {
  const [selectedPose, setSelectedPose] = useState('wave');
  const [selectedEntrance, setSelectedEntrance] = useState('pop');
  const [selectedSize, setSelectedSize] = useState(130);
  const [isTalking, setIsTalking] = useState(false);
  const [isHopping, setIsHopping] = useState(false);
  const [noMotion, setNoMotion] = useState(false);
  const [replayKey, setReplayKey] = useState(0);
  const hopTimerRef = useRef(null);

  useEffect(() => {
    return () => {
      if (hopTimerRef.current) clearTimeout(hopTimerRef.current);
    };
  }, []);

  const triggerHop = () => {
    setIsHopping(true);
    if (hopTimerRef.current) clearTimeout(hopTimerRef.current);
    hopTimerRef.current = setTimeout(() => setIsHopping(false), 500);
  };

  const triggerEntrance = (ent) => {
    setSelectedEntrance(ent);
    setReplayKey((k) => k + 1);
  };

  const currentPoseInfo = POSES.find((p) => p.id === selectedPose) || POSES[0];

  const headerContent = (
    <div className="balu-playground-header">
      {onBack && (
        <button type="button" className="btn btn--ghost" onClick={onBack} style={{ paddingLeft: 0 }}>
          Back
        </button>
      )}
      <h1 className="text-title" style={{ fontFamily: 'var(--font-sans)', margin: 0 }}>
        Balu Playground
      </h1>
      <span className="text-caption" style={{ color: 'var(--color-stone)' }}>
        /dev/balu
      </span>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      bg="cream"
      className="balu-playground-layout"
    >
      <div className="playground-content">
        {/* Mascot Preview Stage */}
        <div className="playground-stage">
          <div className="stage-card" key={replayKey}>
            <Balu
              pose={selectedPose}
              entrance={selectedEntrance}
              size={selectedSize}
              talking={isTalking}
              hop={isHopping}
              noMotion={noMotion}
            />
          </div>
          <div className="stage-meta">
            <span className="text-body" style={{ fontWeight: 600, color: 'var(--color-ink)' }}>
              {currentPoseInfo.name}
            </span>
            <span className="text-caption" style={{ color: 'var(--color-stone)', marginTop: '2px' }}>
              {currentPoseInfo.desc}
            </span>
            <span className="text-caption" style={{ color: 'var(--color-stone)', marginTop: '4px', fontSize: '11px' }}>
              Entrance: {selectedEntrance} • Size: {selectedSize}px
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="playground-controls">
          {/* Poses Section */}
          <div className="control-group">
            <div className="control-label">All 10 3D Poses</div>
            <div className="pills-grid">
              {POSES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  className={`control-pill ${selectedPose === p.id ? 'pill-active' : ''}`}
                  onClick={() => setSelectedPose(p.id)}
                >
                  {p.name}
                </button>
              ))}
            </div>
          </div>

          {/* Entrances Section */}
          <div className="control-group">
            <div className="control-label">Entrances (Tap to play)</div>
            <div className="pills-grid">
              {ENTRANCES.map((ent) => (
                <button
                  key={ent.id}
                  type="button"
                  className={`control-pill ${selectedEntrance === ent.id ? 'pill-active' : ''}`}
                  onClick={() => triggerEntrance(ent.id)}
                >
                  {ent.name}
                </button>
              ))}
            </div>
          </div>

          {/* Sizes & Interactive Toggles */}
          <div className="control-group">
            <div className="control-label">Sizes &amp; Interactions</div>
            <div className="pills-grid">
              {[64, 72, 96, 120, 150].map((s) => (
                <button
                  key={s}
                  type="button"
                  className={`control-pill ${selectedSize === s ? 'pill-active' : ''}`}
                  onClick={() => setSelectedSize(s)}
                >
                  {s}px
                </button>
              ))}
              <button
                type="button"
                className={`control-pill ${isTalking ? 'pill-active' : ''}`}
                onClick={() => setIsTalking(!isTalking)}
              >
                Talking {isTalking ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                className={`control-pill ${isHopping ? 'pill-active' : ''}`}
                onClick={triggerHop}
              >
                Hop Jump
              </button>
              <button
                type="button"
                className={`control-pill ${noMotion ? 'pill-active' : ''}`}
                onClick={() => setNoMotion(!noMotion)}
              >
                Reduced Motion {noMotion ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {/* Complete 10 Poses Gallery */}
          <div className="control-group">
            <div className="control-label">All 10 Poses Gallery</div>
            <div className="all-poses-gallery">
              {POSES.map((p) => (
                <div
                  key={p.id}
                  className={`gallery-cell ${selectedPose === p.id ? 'gallery-cell--active' : ''}`}
                  onClick={() => setSelectedPose(p.id)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      setSelectedPose(p.id);
                    }
                  }}
                >
                  <Balu pose={p.id} size={76} entrance="none" />
                  <span className="gallery-pose-title">{p.name}</span>
                  <span className="gallery-pose-desc">{p.desc}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .balu-playground-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          border-bottom: 1px solid var(--color-sand);
          padding-bottom: 12px;
        }
        .playground-content {
          display: flex;
          flex-direction: column;
          gap: 18px;
          width: 100%;
          padding-bottom: 32px;
        }
        .playground-stage {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 24px;
          min-height: 240px;
          position: relative;
          overflow: hidden;
        }
        .stage-card {
          display: flex;
          align-items: center;
          justify-content: center;
          min-height: 140px;
        }
        .stage-meta {
          margin-top: 14px;
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }
        .playground-controls {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .control-group {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }
        .control-label {
          font-family: var(--font-sans);
          font-size: 13px;
          font-weight: 600;
          color: var(--color-stone);
          text-transform: uppercase;
          letter-spacing: 0.04em;
        }
        .pills-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }
        .control-pill {
          background: var(--color-bubble);
          border: 1px solid var(--color-sand);
          color: var(--color-ink);
          font-family: var(--font-sans);
          font-size: 13px;
          padding: 6px 14px;
          border-radius: 999px;
          cursor: pointer;
          transition: all 0.15s ease;
        }
        .control-pill:hover {
          border-color: var(--color-ink);
        }
        .control-pill.pill-active {
          background: var(--color-marigold);
          color: var(--color-ink);
          font-weight: 600;
          border-color: var(--color-marigold);
        }
        .all-poses-gallery {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }
        .gallery-cell {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 14px 10px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .gallery-cell:hover {
          border-color: var(--color-ink);
        }
        .gallery-cell--active {
          border-color: var(--color-marigold);
          background: #fff8e6;
          box-shadow: 0 2px 8px rgba(246, 185, 43, 0.15);
        }
        .gallery-pose-title {
          font-family: var(--font-sans);
          font-size: 13px;
          font-weight: 600;
          color: var(--color-ink);
          margin-top: 8px;
        }
        .gallery-pose-desc {
          font-family: var(--font-sans);
          font-size: 11px;
          color: var(--color-stone);
          margin-top: 2px;
          line-height: 1.3;
        }
      `}</style>
    </ScreenLayout>
  );
}
