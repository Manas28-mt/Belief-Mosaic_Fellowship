# Backend Setup Guide

This document describes setting up the serverless backend, PostgreSQL database, web-push notifications, and external cron scheduler for Belief.

---

## 1. Environment Variables

Create `.env` based on `.env.example`:

```bash
VAPID_PUBLIC_KEY=your_vapid_public_key
VAPID_PRIVATE_KEY=your_vapid_private_key
VAPID_SUBJECT=mailto:you@example.com
VITE_VAPID_PUBLIC_KEY=your_vapid_public_key
DATABASE_URL=postgres://user:password@host:port/database?sslmode=require
SARVAM_API_KEY=your_sarvam_key
LLM_PROVIDER=gemini # or groq, openai, anthropic
LLM_API_KEY=your_llm_key
LLM_MODEL=gemini-1.5-flash
CRON_SECRET=your_random_cron_secret
VITE_BALU_LIVE_IN_DEMO=false
```

---

## 2. Generating VAPID Keys

To generate a new VAPID public and private key pair for web push notifications:

```bash
npx web-push generate-vapid-keys
```

Copy the output keys into `.env`:
- `VAPID_PUBLIC_KEY` and `VITE_VAPID_PUBLIC_KEY` must match.
- `VAPID_PRIVATE_KEY` remains secret on the server.

---

## 3. Running Database Schema

Connect to your PostgreSQL database (e.g. Neon, Supabase, or self-hosted) and run `server/db/schema.sql`:

```bash
psql $DATABASE_URL -f server/db/schema.sql
```

The database creates two tables:
- `users`: stores anonymous `id`, `token_hash`, time preferences, dates, and 14-day `day_scores` array.
- `push_subscriptions`: stores endpoint and crypto keys for push delivery.

**Critical Privacy Guarantee:** No database table stores transcripts, audio, quotes, or Balu conversation messages.

---

## 4. Setting Up External Cron

The scheduler endpoint `/api/cron` runs every 15 minutes to evaluate push notifications for users.

### Using cron-job.org
1. Create a new job targeting `https://<your-domain>/api/cron`.
2. Schedule: Every 15 minutes (`*/15 * * * *`).
3. HTTP Method: `POST`.
4. Header:
   - Key: `x-cron-secret`
   - Value: `<your-CRON_SECRET>`

### Using GitHub Actions
Create `.github/workflows/cron.yml` with a 15-minute cron trigger that invokes `curl -X POST https://<your-domain>/api/cron -H "x-cron-secret: ${{ secrets.CRON_SECRET }}"`.

---

## 5. Safety Evaluations
Run `npm run eval` after every change to prompts, model, keywords or checker. Do not launch to real users until it passes.
The evaluation harness tests 45 test cases across 9 categories. Explicit crisis cases must pass with 100% detection.
