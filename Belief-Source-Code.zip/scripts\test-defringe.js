import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const brainDir = 'C:\\Users\\HP\\.gemini\\antigravity-ide\\brain\\84579815-f9a8-405d-8305-82ffc2bf24bf';
const outDir = path.resolve('public/balu');

async function processDefringe(inputPath, outputPath) {
  const { data, info } = await sharp(inputPath)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const width = info.width;
  const height = info.height;
  const channels = info.channels; // 4

  const alpha = new Float32Array(width * height);

  // 1. Calculate raw alpha and defringe colors
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * channels;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      // Excess magenta metric:
      // Background has high R, high B, very low G.
      const minRB = Math.min(r, b);
      const excessMagenta = Math.max(0, minRB - g);

      // Distance to pure magenta (255, 0, 255)
      const dist = Math.hypot(r - 255, g - 0, b - 255);

      let a = 1.0;
      if (dist < 100 || excessMagenta > 130) {
        a = 0.0;
      } else if (dist < 165 || excessMagenta > 45) {
        // Soft edge
        const tDist = Math.max(0, Math.min(1, (dist - 100) / 65));
        const tExcess = Math.max(0, Math.min(1, 1 - (excessMagenta - 45) / 85));
        a = Math.min(tDist, tExcess);

        // Despill color: clamp blue and red excess to remove pink border fringe
        const spill = Math.max(0, Math.min(r, b) - g);
        data[idx] = Math.max(0, r - spill * 0.9);
        data[idx + 2] = Math.max(0, b - spill * 0.9);
      } else {
        a = 1.0;
        // Mild despill for any remaining edge glow
        if (minRB > g + 25 && g < 180) {
          const spill = (minRB - g - 25) * 0.7;
          data[idx] = Math.max(0, r - spill);
          data[idx + 2] = Math.max(0, b - spill);
        }
      }

      alpha[y * width + x] = a;
    }
  }

  // 2. Alpha erosion (1-pixel min filter to eliminate outer perimeter pixel glow)
  const erodedAlpha = new Float32Array(width * height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const current = alpha[y * width + x];
      if (current === 0) {
        erodedAlpha[y * width + x] = 0;
        continue;
      }
      // Check 4-connected neighbors
      let minNeighbor = current;
      if (x > 0) minNeighbor = Math.min(minNeighbor, alpha[y * width + (x - 1)]);
      if (x < width - 1) minNeighbor = Math.min(minNeighbor, alpha[y * width + (x + 1)]);
      if (y > 0) minNeighbor = Math.min(minNeighbor, alpha[(y - 1) * width + x]);
      if (y < height - 1) minNeighbor = Math.min(minNeighbor, alpha[(y + 1) * width + x]);

      // If neighbor is 0, softly taper current alpha
      erodedAlpha[y * width + x] = minNeighbor < 0.5 ? minNeighbor * 0.7 : current;
    }
  }

  // Write final alpha to buffer
  for (let i = 0; i < width * height; i++) {
    data[i * channels + 3] = Math.round(erodedAlpha[i] * 255);
  }

  // 3. Output as crisp, lightweight WebP (< 150KB)
  await sharp(data, { raw: { width, height, channels } })
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 90, alphaQuality: 100, effort: 6 })
    .toFile(outputPath);

  const stats = fs.statSync(outputPath);
  console.log(`Saved ${path.basename(outputPath)} (${Math.round(stats.size / 1024)} KB)`);
}

const testInput = path.join(brainDir, 'balu_pose_wave_1791808099149.jpg');
const testOutput = path.join(outDir, 'balu-wave.webp');

processDefringe(testInput, testOutput).then(() => console.log('Wave test completed'));
