import React, { useState } from 'react';
import { X, Smartphone } from 'lucide-react';
import Balu from '../balu/Balu.jsx';

/**
 * WidgetPrompt Component
 * Prompts users to add the app/widget to their home screen with live mockup.
 */
export default function WidgetPrompt({ todaysPrompt = "What did you almost skip today but do anyway?" }) {
  const [isVisible, setIsVisible] = useState(() => {
    try {
      return sessionStorage.getItem('belief_widget_prompt_dismissed') !== '1';
    } catch {
      return true;
    }
  });
  const [showModal, setShowModal] = useState(false);

  const handleDismiss = () => {
    setIsVisible(false);
    try {
      sessionStorage.setItem('belief_widget_prompt_dismissed', '1');
    } catch {}
  };

  if (!isVisible) return null;

  return (
    <>
      <div className="widget-prompt card mb-4 animate-fade-in">
        {/* Decorative Top Accent */}
        <div className="widget-prompt-banner" />
        
        <div className="widget-prompt-content">
          <button 
            type="button"
            className="widget-close" 
            onClick={handleDismiss}
            aria-label="Dismiss widget card"
          >
            <X size={16} strokeWidth={2} />
          </button>
          
          <div className="flex-row items-center gap-3 mb-2">
            <div className="widget-icon">
              <Smartphone size={20} strokeWidth={2} />
            </div>
            <div>
              <h3 className="text-body" style={{ fontWeight: 600, margin: 0 }}>Keep me close</h3>
              <span className="text-caption" style={{ color: 'var(--color-stone)' }}>Add widget to Home Screen</span>
            </div>
          </div>
          
          <p className="text-small" style={{ color: 'var(--color-ink)', opacity: 0.85, margin: '6px 0 12px' }}>
            Add this app to your Home Screen so I can check in on you and build your timeline faster.
          </p>
          
          <div className="flex-row items-center gap-2">
            <button 
              type="button"
              className="btn btn--secondary btn--small" 
              style={{ width: 'auto' }}
              onClick={() => setShowModal(true)}
            >
              Add widget
            </button>
          </div>
        </div>
      </div>

      {showModal && (
        <div className="widget-modal-overlay" onClick={() => setShowModal(false)}>
          <div className="widget-modal card" onClick={(e) => e.stopPropagation()}>
            <div className="widget-modal-header">
              <h3 className="text-headline" style={{ margin: 0, fontSize: '1.15rem' }}>Add Belief Widget</h3>
              <button 
                type="button" 
                className="widget-modal-close"
                onClick={() => setShowModal(false)}
                aria-label="Close"
              >
                <X size={18} strokeWidth={2} />
              </button>
            </div>

            {/* Widget Preview Mockup */}
            <div className="widget-mockup-wrapper">
              <div className="widget-mockup-card">
                <div className="widget-mockup-header">
                  <span className="widget-mockup-tag">TODAY'S QUESTION</span>
                  <Balu pose="wave" size={28} noMotion={true} entrance="none" />
                </div>
                <p className="widget-mockup-text">{todaysPrompt}</p>
                <div className="widget-mockup-footer">
                  <span className="widget-mockup-btn">Tap to answer</span>
                </div>
              </div>
            </div>

            <div className="widget-instructions">
              <div className="instruction-step">
                <span className="step-badge">1</span>
                <p className="text-small" style={{ margin: 0 }}>
                  Tap the <strong>Share</strong> button in Safari (or <strong>⋮</strong> menu in Chrome).
                </p>
              </div>
              <div className="instruction-step">
                <span className="step-badge">2</span>
                <p className="text-small" style={{ margin: 0 }}>
                  Select <strong>Add to Home Screen</strong>.
                </p>
              </div>
              <div className="instruction-step">
                <span className="step-badge">3</span>
                <p className="text-small" style={{ margin: 0 }}>
                  Touch and hold your home screen anytime to add the <strong>Belief Widget</strong>.
                </p>
              </div>
            </div>

            <button 
              type="button" 
              className="btn btn--primary btn--full mt-4"
              onClick={() => setShowModal(false)}
            >
              Got it
            </button>
          </div>
        </div>
      )}

      <style>{`
        .widget-prompt {
          position: relative;
          overflow: hidden;
          padding: 0;
          background: var(--color-peach);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
        }
        .widget-prompt-banner {
          height: 4px;
          width: 100%;
          background-color: var(--color-marigold);
        }
        .widget-prompt-content {
          padding: var(--space-3);
          position: relative;
        }
        .widget-close {
          position: absolute;
          top: 10px;
          right: 10px;
          background: none;
          border: none;
          color: var(--color-stone);
          cursor: pointer;
          padding: 4px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
        }
        .widget-close:hover {
          color: var(--color-ink);
        }
        .widget-icon {
          width: 36px;
          height: 36px;
          border-radius: 10px;
          background-color: var(--color-cream);
          border: 1px solid var(--color-sand);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--color-ink);
          flex-shrink: 0;
        }
        .widget-modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(42, 37, 32, 0.45);
          backdrop-filter: blur(2px);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: var(--space-4);
          z-index: 200;
        }
        .widget-modal {
          background: var(--color-cream);
          width: 100%;
          max-width: 360px;
          padding: var(--space-4);
          border-radius: var(--radius-card);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        .widget-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: var(--space-3);
        }
        .widget-modal-close {
          background: none;
          border: none;
          cursor: pointer;
          color: var(--color-stone);
          padding: 4px;
        }
        .widget-mockup-wrapper {
          display: flex;
          justify-content: center;
          margin: var(--space-3) 0 var(--space-4);
        }
        .widget-mockup-card {
          width: 100%;
          background: var(--color-beige);
          border: 2px solid var(--color-sand);
          border-radius: 18px;
          padding: 14px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.06);
        }
        .widget-mockup-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
        }
        .widget-mockup-tag {
          font-family: var(--font-sans);
          font-size: 10px;
          letter-spacing: 0.06em;
          font-weight: 700;
          color: var(--color-stone);
        }
        .widget-mockup-text {
          font-family: var(--font-serif);
          font-size: 15px;
          line-height: 1.35;
          color: var(--color-ink);
          margin: 0 0 10px;
        }
        .widget-mockup-footer {
          display: flex;
          justify-content: flex-end;
        }
        .widget-mockup-btn {
          font-size: 11px;
          font-weight: 600;
          color: var(--color-ink);
          background: var(--color-marigold);
          padding: 4px 10px;
          border-radius: 12px;
        }
        .widget-instructions {
          display: flex;
          flex-direction: column;
          gap: 10px;
          margin-bottom: var(--space-3);
        }
        .instruction-step {
          display: flex;
          align-items: flex-start;
          gap: 10px;
        }
        .step-badge {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: var(--color-sand);
          color: var(--color-ink);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 700;
          flex-shrink: 0;
        }
      `}</style>
    </>
  );
}
