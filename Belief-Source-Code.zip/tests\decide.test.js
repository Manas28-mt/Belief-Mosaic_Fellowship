import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { decide } from '../server/lib/scheduler.js';

describe('decide() scheduler function tests', () => {
  const baseDate = new Date('2026-10-12T21:30:00'); // Day 285, 21:30 local time

  it('skips user if already notified today (one-per-day limit)', () => {
    const user = {
      id: 'u1',
      last_notification_date: '2026-10-12',
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.equal(decision, null);
  });

  it('triggers HARD DATE when today is in hard_dates, hour >= 19, and cooldown is clear', () => {
    const user = {
      id: 'u2',
      hard_dates: ['2026-10-12'],
      last_playback_sent_at: '2026-10-01T12:00:00Z', // 11 days ago (> 7 cooldown)
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'playback',
      text: 'Something from your diary is waiting.',
    });
  });

  it('does NOT trigger HARD DATE if hour is before 19:00', () => {
    const afternoonDate = new Date('2026-10-12T15:00:00');
    const user = {
      id: 'u3',
      hard_dates: ['2026-10-12'],
      last_playback_sent_at: '2026-10-01T12:00:00Z',
      prompt_time: '21:00',
    };
    const decision = decide(user, afternoonDate);
    // Before 19:00 and before prompt_time: returns null
    assert.equal(decision, null);
  });

  it('does NOT trigger HARD DATE if playback cooldown is active (< 7 days)', () => {
    const user = {
      id: 'u4',
      hard_dates: ['2026-10-12'],
      last_playback_sent_at: '2026-10-09T12:00:00Z', // 3 days ago
      prompt_time: '21:00',
    };
    // Should fall through to nightly prompt instead of hard date playback
    const decision = decide(user, baseDate);
    assert.equal(decision?.type, 'record');
  });

  it('triggers SILENCE CHECK-IN for regular user after 3 silent days (ordinary)', () => {
    // 3 days of silence: last entry was on Oct 9
    const user = {
      id: 'u5',
      last_entry_at: '2026-10-09T10:00:00Z',
      day_scores: {
        '2026-10-09': 0,
        '2026-10-08': 0,
        '2026-10-07': 0,
        '2026-10-06': 0,
      },
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'checkin',
      text: 'Something from your diary is waiting.',
    });
  });

  it('triggers SILENCE CHECK-IN after 2 days if recent entry was heavy (score >= 1)', () => {
    // 2 days of silence: last entry was on Oct 10 with score 1
    const user = {
      id: 'u6',
      last_entry_at: '2026-10-10T10:00:00Z',
      day_scores: {
        '2026-10-10': 1,
        '2026-10-08': 0,
        '2026-10-07': 0,
        '2026-10-06': 0,
      },
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'checkin',
      text: 'Something from your diary is waiting.',
    });
  });

  it('does NOT trigger SILENCE CHECK-IN if check-in was already sent since last entry', () => {
    const user = {
      id: 'u7',
      last_entry_at: '2026-10-08T10:00:00Z',
      last_checkin_sent_at: '2026-10-11T12:00:00Z', // check-in sent after last_entry_at
      day_scores: {
        '2026-10-08': 0,
        '2026-10-07': 0,
        '2026-10-06': 0,
        '2026-10-05': 0,
      },
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.equal(decision?.type, 'record');
  });

  it('triggers BALU INVITE when ladder window has 3 heavy days and cooldown is clear', () => {
    const user = {
      id: 'u8',
      day_scores: {
        '2026-10-12': 1,
        '2026-10-11': 1,
        '2026-10-10': 1,
      },
      last_balu_invite_at: '2026-10-05T12:00:00Z', // 7 days ago (> 3 cooldown)
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'balu',
      text: 'Something from your diary is waiting.',
    });
  });

  it('triggers BALU INVITE when ladder window has 2 concerning days (score >= 2)', () => {
    const user = {
      id: 'u9',
      day_scores: {
        '2026-10-12': 2,
        '2026-10-10': 2,
      },
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'balu',
      text: 'Something from your diary is waiting.',
    });
  });

  it('triggers PLAYBACK AFTER A HEAVY DAY when yesterday was heavy and cooldown is clear', () => {
    const user = {
      id: 'u10',
      day_scores: {
        '2026-10-11': 1, // Yesterday was heavy
      },
      last_playback_sent_at: '2026-10-01T12:00:00Z', // > 7 days ago
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.deepEqual(decision, {
      type: 'playback',
      text: 'Something from your diary is waiting.',
    });
  });

  it('triggers NIGHTLY PROMPT at or after prompt time as fallback', () => {
    const user = {
      id: 'u11',
      prompt_time: '21:00',
    };
    const decision = decide(user, baseDate);
    assert.equal(decision?.type, 'record');
    assert.ok(decision?.text && typeof decision.text === 'string');
  });

  it('respects reduced frequency (only on even day-of-year)', () => {
    // 2026-10-12 is Day 285 (odd)
    const userOdd = {
      id: 'u12',
      prompt_time: '21:00',
      frequency: 'reduced',
    };
    const decisionOdd = decide(userOdd, baseDate);
    assert.equal(decisionOdd, null);

    // Day 286 (even) -> 2026-10-13
    const nextDay = new Date('2026-10-13T21:30:00');
    const decisionEven = decide(userOdd, nextDay);
    assert.equal(decisionEven?.type, 'record');
  });
});
