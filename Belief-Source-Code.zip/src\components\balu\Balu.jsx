import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';

const VALID_POSES = [
  'wave',
  'peek',
  'point',
  'listen',
  'think',
  'talk',
  'soft',
  'nod',
  'fly',
  'surprised',
];

const LEGACY_MAP = {
  hover: 'wave',
  perch: 'listen',
  happy: 'wave',
  curious: 'peek',
  listening: 'listen',
  thinking: 'think',
  neutral: 'listen',
  sleepy: 'nod',
  soft: 'soft',
  surprised: 'surprised',
};

/**
 * Balu — 3D mascot component with Duolingo-style spring motion and poses.
 * 
 * Props:
 * - pose: 'wave' | 'peek' | 'point' | 'listen' | 'think' | 'talk' | 'soft' | 'nod' | 'fly' | 'surprised'
 * - entrance: 'pop' | 'peekLeft' | 'peekRight' | 'flyIn' | 'hop' | 'none'
 * - size: number (e.g. 64, 72, 96, 120, 180)
 * - talking: boolean (talk pose with a small bounce, settles to listen when false)
 * - hop: boolean (triggers an 8px jump)
 * - noMotion: boolean (disables entrances, bob, and sway e.g. on bad-day screen)
 */
export default function Balu({
  pose = 'wave',
  expression,
  entrance = 'none',
  size = 120,
  talking = false,
  hop = false,
  noMotion = false,
  className = '',
  style = {},
  onClick,
}) {
  const shouldReduceMotion = useReducedMotion() || noMotion;

  // Resolve active pose
  let resolvedPose = pose;
  if (!VALID_POSES.includes(resolvedPose)) {
    if (expression && LEGACY_MAP[expression]) {
      resolvedPose = LEGACY_MAP[expression];
    } else if (LEGACY_MAP[resolvedPose]) {
      resolvedPose = LEGACY_MAP[resolvedPose];
    } else {
      resolvedPose = 'wave';
    }
  }

  // Talking override: when talking is true, use 'talk' pose
  const activePose = talking ? 'talk' : resolvedPose;

  // Track image load failure for fallback to reference.png
  const [imgSrc, setImgSrc] = useState(`/balu/balu-${activePose}.webp`);

  useEffect(() => {
    setImgSrc(`/balu/balu-${activePose}.webp`);
  }, [activePose]);

  // Entrance variants
  const getEntranceInitial = () => {
    if (shouldReduceMotion || entrance === 'none') {
      return { opacity: 1, x: 0, y: 0, scale: 1, rotate: 0 };
    }
    switch (entrance) {
      case 'pop':
        return { opacity: 0, scale: 0, scaleX: 0.8, scaleY: 1.2 };
      case 'peekLeft':
        return { opacity: 0, x: -size * 0.45, scale: 0.95 };
      case 'peekRight':
        return { opacity: 0, x: size * 0.45, scale: 0.95 };
      case 'flyIn':
      case 'flyInFromTop':
        return { opacity: 0, y: -65, x: -20, rotate: -6 };
      case 'riseFromBottom':
        return { opacity: 0, y: 45, scale: 0.9 };
      case 'hop':
        return { opacity: 1, y: 0 };
      default:
        return { opacity: 1 };
    }
  };

  const getEntranceAnimate = () => {
    if (shouldReduceMotion || entrance === 'none') {
      return { opacity: 1, x: 0, y: 0, scale: 1, rotate: 0 };
    }
    switch (entrance) {
      case 'pop':
        return {
          opacity: 1,
          scale: [0, 1.08, 0.97, 1.02, 1],
          scaleX: [0.8, 1.12, 0.96, 1],
          scaleY: [1.2, 0.92, 1.04, 1],
        };
      case 'peekLeft':
      case 'peekRight':
        return {
          opacity: 1,
          x: 0,
          scale: 1,
        };
      case 'flyIn':
      case 'flyInFromTop':
        return {
          opacity: 1,
          y: 0,
          x: 0,
          rotate: 0,
        };
      case 'riseFromBottom':
        return {
          opacity: 1,
          y: 0,
          scale: 1,
        };
      case 'hop':
        return {
          y: [0, -8, 0],
          scaleY: [0.95, 1.05, 0.97, 1],
        };
      default:
        return { opacity: 1 };
    }
  };

  const getEntranceTransition = () => {
    if (shouldReduceMotion || entrance === 'none') {
      return { duration: 0.2 };
    }
    switch (entrance) {
      case 'pop':
        return {
          duration: 0.48,
          ease: [0.34, 1.56, 0.64, 1],
        };
      case 'peekLeft':
      case 'peekRight':
        return {
          type: 'spring',
          stiffness: 260,
          damping: 22,
          mass: 0.8,
        };
      case 'flyIn':
      case 'flyInFromTop':
        return {
          type: 'spring',
          stiffness: 220,
          damping: 18,
          mass: 0.9,
        };
      case 'hop':
        return {
          duration: 0.38,
          ease: 'easeOut',
        };
      default:
        return {
          type: 'spring',
          stiffness: 240,
          damping: 20,
        };
    }
  };

  // Idle motion: 4px bob over 2.4s plus 2-degree sway
  const canIdle = !shouldReduceMotion && !noMotion && entrance !== 'hop';

  // Hop trigger motion (e.g. for Saved: nod plus one hop)
  const hopAnimation = hop && !shouldReduceMotion
    ? {
        y: [0, -8, 0],
        scaleY: [0.93, 1.06, 0.96, 1],
        scaleX: [1.06, 0.94, 1.03, 1],
        transition: { duration: 0.36, ease: 'easeOut' },
      }
    : {};

  // Talking bounce animation
  const talkingBounce = talking && !shouldReduceMotion
    ? {
        y: [0, -3.5, 0],
        scaleY: [1, 1.04, 1],
        scaleX: [1, 0.97, 1],
        transition: { duration: 0.3, repeat: Infinity, ease: 'easeInOut' },
      }
    : {};

  return (
    <motion.div
      className={`balu-container ${className}`}
      initial={getEntranceInitial()}
      animate={getEntranceAnimate()}
      transition={getEntranceTransition()}
      onClick={onClick}
      style={{
        display: 'inline-flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        width: size,
        height: size,
        overflow: 'visible',
        userSelect: 'none',
        pointerEvents: onClick ? 'auto' : 'none',
        ...style,
      }}
      role="img"
      aria-label="Balu"
    >
      {/* Mascot character with spring idle/talking/hop */}
      <motion.div
        className="balu-mascot-wrapper"
        animate={
          hop
            ? hopAnimation
            : talking
            ? talkingBounce
            : canIdle
            ? {
                y: [0, -4, 0],
                rotate: [-2, 2, -2],
                transition: {
                  duration: 2.4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                },
              }
            : { y: 0, rotate: 0 }
        }
        style={{
          width: size,
          height: size,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative',
          overflow: 'visible',
          zIndex: 2,
        }}
      >
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.img
            key={activePose}
            src={imgSrc}
            alt="Balu"
            onError={() => setImgSrc('/balu/reference.png')}
            initial={
              shouldReduceMotion
                ? { opacity: 0 }
                : { opacity: 0, scale: 0.94 }
            }
            animate={
              shouldReduceMotion
                ? { opacity: 1 }
                : {
                    opacity: 1,
                    scale: [0.94, 1.04, 1],
                    transition: { duration: 0.18, ease: 'easeOut' },
                  }
            }
            exit={
              shouldReduceMotion
                ? { opacity: 0 }
                : {
                    opacity: 0,
                    scale: 0.96,
                    transition: { duration: 0.14, ease: 'easeIn' },
                  }
            }
            style={{
              width: size,
              height: size,
              objectFit: 'contain',
              display: 'block',
              filter: 'drop-shadow(0 2px 4px rgba(42, 37, 32, 0.04))',
            }}
          />
        </AnimatePresence>
      </motion.div>

      {/* Very soft shadow under Balu */}
      <motion.div
        className="balu-shadow"
        animate={
          canIdle
            ? {
                scaleX: [1, 0.88, 1],
                scaleY: [1, 0.85, 1],
                opacity: [0.65, 0.45, 0.65],
                transition: {
                  duration: 2.4,
                  repeat: Infinity,
                  ease: 'easeInOut',
                },
              }
            : { scaleX: 1, scaleY: 1, opacity: 0.6 }
        }
        style={{
          width: Math.round(size * 0.52),
          height: Math.max(6, Math.round(size * 0.12)),
          borderRadius: '50%',
          background:
            'radial-gradient(ellipse at center, rgba(42, 37, 32, 0.22) 0%, rgba(42, 37, 32, 0) 72%)',
          marginTop: -Math.round(size * 0.08),
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />
    </motion.div>
  );
}
