// Tunable numbers for the client. Every value is a first guess. Never hardcode elsewhere.

export const NUMBERS = {
  // Recording
  RECORD_SUGGESTED_SECONDS: 30, // "30 seconds is enough"
  RECORD_SOFT_STOP_SECONDS: 90, // Soft stop near 90 seconds
  MAX_AUDIO_SECONDS: 120, // Hard ceiling for audio transcription

  // Balu interaction
  MAX_BALU_TURNS: 3, // At most 3 turns per session
  BALU_MAX_WORDS: 35, // Balu replies max words

  // Permissions & re-ask
  REASK_EXPLAINER_DAYS: 14, // If refused or "Not now", wait 14 days before showing again

  // Playback & ladder window
  PLAYBACK_WINDOW_DAYS: 14, // Match level 0 entries within 14 days after a heavy entry
  SILENCE_DAYS: 3, // Default silence threshold
  SILENCE_DAYS_AFTER_HEAVY: 2, // Silence threshold after heavy day
  LADDER_WINDOW_DAYS: 5,
};
