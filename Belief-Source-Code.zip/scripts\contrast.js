/**
 * scripts/contrast.js
 * Computes WCAG 2.1 relative luminance and contrast ratios
 * for all text/background pairs used on Belief screens.
 */

function srgbToLinear(val) {
  const c = val / 255;
  return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
}

function hexToRgb(hex) {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16);
  const g = parseInt(clean.substring(2, 4), 16);
  const b = parseInt(clean.substring(4, 6), 16);
  return [r, g, b];
}

function getLuminance(hex) {
  const [r, g, b] = hexToRgb(hex);
  const rLin = srgbToLinear(r);
  const gLin = srgbToLinear(g);
  const bLin = srgbToLinear(b);
  return 0.2126 * rLin + 0.7152 * gLin + 0.0722 * bLin;
}

function getContrastRatio(hex1, hex2) {
  const l1 = getLuminance(hex1);
  const l2 = getLuminance(hex2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

const tokens = {
  cream: '#FBF5E6',
  beige: '#F1E6CF',
  marigold: '#F6B92B',
  ink: '#2A2520',
  stone: '#6B6257',
  leaf: '#2F6B4F',
  peach: '#F8DCC8',
  sand: '#E4D6BA',
  bubble: '#FFFDF7',
};

// All text/background combinations across the authorized screens
const pairs = [
  { text: 'ink', bg: 'cream', fontSize: 18, desc: 'Ink text on Cream page background' },
  { text: 'ink', bg: 'beige', fontSize: 18, desc: 'Ink text on Beige card fill' },
  { text: 'ink', bg: 'peach', fontSize: 18, desc: 'Ink text on Peach screen/circle' },
  { text: 'ink', bg: 'marigold', fontSize: 18, desc: 'Ink button label on Marigold pill' },
  { text: 'ink', bg: 'bubble', fontSize: 18, desc: 'Ink text in speech bubble' },
  { text: 'stone', bg: 'cream', fontSize: 14, desc: 'Stone label/hint on Cream background' },
  { text: 'stone', bg: 'beige', fontSize: 14, desc: 'Stone secondary text on Beige card' },
  { text: 'stone', bg: 'bubble', fontSize: 14, desc: 'Stone timestamp/caption in bubble' },
  { text: 'leaf', bg: 'beige', fontSize: 16, desc: 'Leaf highlight text on Beige card' },
  { text: 'leaf', bg: 'cream', fontSize: 16, desc: 'Leaf saved confirmation on Cream' },
  { text: 'ink', bg: 'cream', fontSize: 32, desc: 'Opening big lines (Fraunces 32px) on Cream' },
];

console.log('====================================================');
console.log(' WCAG 2.1 Contrast Ratio Verification');
console.log(' Required: 4.5:1 for body (<28px), 3.0:1 for large (>=28px)');
console.log('====================================================\n');

let allPassed = true;

pairs.forEach(({ text, bg, fontSize, desc }) => {
  const textHex = tokens[text];
  const bgHex = tokens[bg];
  const ratio = getContrastRatio(textHex, bgHex);
  const required = fontSize >= 28 ? 3.0 : 4.5;
  const passed = ratio >= required;
  if (!passed) allPassed = false;

  const status = passed ? 'PASS' : 'FAIL';
  console.log(`[${status}] ${ratio.toFixed(2)}:1 (req ${required.toFixed(1)}:1) | Text: ${text} (${textHex}) on Bg: ${bg} (${bgHex}) | ${desc} [${fontSize}px]`);
});

console.log('\n----------------------------------------------------');
if (allPassed) {
  console.log('RESULT: ALL TEXT/BG PAIRS PASS WCAG CONTRAST REQUIREMENTS.');
  process.exit(0);
} else {
  console.error('RESULT: SOME CONTRAST PAIRS FAILED.');
  process.exit(1);
}
