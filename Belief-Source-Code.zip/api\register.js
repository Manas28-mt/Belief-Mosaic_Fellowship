import { generateToken, generateUserId, hashToken } from '../server/lib/auth.js';
import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const userId = generateUserId();
  const token = generateToken();
  const tokenHash = hashToken(token);

  if (isUsingMockDb) {
    const mockStore = getMockStore();
    mockStore.users.set(userId, {
      id: userId,
      token_hash: tokenHash,
      created_at: new Date().toISOString(),
      tz: 'Asia/Kolkata',
      prompt_time: '21:00',
      frequency: 'daily',
      hard_dates: [],
      day_scores: {},
      last_entry_at: null,
      last_playback_sent_at: null,
      last_checkin_sent_at: null,
      last_balu_invite_at: null,
      last_notification_date: null,
    });
    return res.status(200).json({ userId, token });
  }

  const sql = getDb();
  if (!sql) {
    return res.status(500).json({ error: 'Database unavailable' });
  }

  try {
    await sql`
      INSERT INTO users (id, token_hash)
      VALUES (${userId}, ${tokenHash})
    `;
    return res.status(200).json({ userId, token });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to create user' });
  }
}
