import React, { useState, useEffect, useRef } from 'react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * AuthScreen — Login screen with demo access and Google option.
 * Converted to use unified ScreenLayout:
 * - Pinned Continue button in footer slot outside the scroll area.
 * - Mobile keyboard adaptation using window.visualViewport.
 * - All timers cleaned up on unmount.
 * - Double-fire protection on all submit buttons.
 * - Images have fixed dimensions (no CLS).
 */
export default function AuthScreen({ onLogin }) {
  const [email, setEmail] = useState('judge@belief.demo');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [keyboardOffset, setKeyboardOffset] = useState(0);
  const inputRef = useRef(null);
  const timerRef = useRef(null);

  // Clean up any pending submit timers on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  // Visual Viewport tracking for mobile keyboard
  useEffect(() => {
    if (typeof window === 'undefined' || !window.visualViewport) return;
    const handleViewport = () => {
      const heightDiff = window.innerHeight - window.visualViewport.height;
      setKeyboardOffset(heightDiff > 60 ? heightDiff : 0);
    };

    window.visualViewport.addEventListener('resize', handleViewport);
    window.visualViewport.addEventListener('scroll', handleViewport);
    return () => {
      window.visualViewport.removeEventListener('resize', handleViewport);
      window.visualViewport.removeEventListener('scroll', handleViewport);
    };
  }, []);

  const isValidEmail = (val) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val.trim());
  };

  const handleEmailSubmit = (e) => {
    if (e && e.preventDefault) e.preventDefault();
    if (isSubmitting) return; // double-fire prevention

    const cleanEmail = email.trim();
    if (!isValidEmail(cleanEmail)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setIsSubmitting(true);

    timerRef.current = setTimeout(() => {
      onLogin({ email: cleanEmail, isDemo: true });
    }, 350);
  };

  const handleGoogleLogin = () => {
    if (isSubmitting) return; // double-fire prevention
    setIsSubmitting(true);

    timerRef.current = setTimeout(() => {
      onLogin({ email: 'judge@belief.demo', isDemo: true });
    }, 350);
  };

  const canSubmit = isValidEmail(email) && !isSubmitting;

  const headerContent = (
    <div className="auth-header-inner">
      <div className="auth-logo-wrap">
        <img
          src="/logo.jpg"
          alt="Belief logo"
          className="auth-logo"
          width="68"
          height="68"
        />
      </div>
    </div>
  );

  const footerContent = (
    <div
      className="auth-footer-inner"
      style={keyboardOffset > 0 ? { paddingBottom: `${keyboardOffset}px` } : undefined}
    >
      <button
        type="button"
        className="btn btn--primary btn--full auth-submit-btn"
        onClick={handleEmailSubmit}
        disabled={!canSubmit}
      >
        {isSubmitting ? 'Logging in...' : 'Continue'}
      </button>
      <p className="auth-terms">
        By continuing, you agree to our Terms &amp; Privacy Policy.
      </p>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      className="auth-screen-layout"
    >
      <div className="auth-content-box">
        <h1 className="auth-heading">
          Keep your<br />belief intact.
        </h1>
        <p className="auth-subheading">
          A daily record in your own words,<br />played back when you need it.
        </p>

        <div className="auth-form-card">
          <button
            type="button"
            className="btn btn--secondary btn--full auth-google-btn"
            onClick={handleGoogleLogin}
            disabled={isSubmitting}
          >
            <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span>Login with Gmail</span>
          </button>

          <div className="auth-divider">
            <div className="auth-line" />
            <span className="auth-or-text">or</span>
            <div className="auth-line" />
          </div>

          <form onSubmit={handleEmailSubmit} className="auth-email-form">
            <label htmlFor="login-email-input" className="sr-only">
              Email address
            </label>
            <input
              ref={inputRef}
              id="login-email-input"
              name="email"
              type="email"
              autoComplete="email"
              className="auth-input"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError('');
              }}
              onFocus={() => {
                if (inputRef.current) {
                  setTimeout(() => {
                    inputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }, 250);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleEmailSubmit(e);
                }
              }}
              onClick={(e) => e.stopPropagation()}
              disabled={isSubmitting}
              placeholder="judge@belief.demo"
            />

            {error && (
              <div className="auth-error-inline" role="alert">
                {error}
              </div>
            )}

            <p className="auth-demo-hint">
              Demo account. No password needed.
            </p>
          </form>
        </div>
      </div>

      <style>{`
        .auth-header-inner {
          width: 100%;
          display: flex;
          justify-content: center;
          padding-top: 12px;
          padding-bottom: 8px;
        }

        .auth-logo-wrap {
          width: 68px;
          height: 68px;
          border-radius: 18px;
          overflow: hidden;
          background: #FFFFFF;
          border: 1px solid var(--color-sand);
          flex-shrink: 0;
        }

        .auth-logo {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .auth-content-box {
          display: flex;
          flex-direction: column;
          width: 100%;
          max-width: 340px;
          margin: 0 auto;
        }

        .auth-heading {
          font-family: var(--font-serif);
          font-size: var(--text-headline);
          line-height: var(--lh-heading);
          color: var(--color-ink);
          margin: 0 0 8px 0;
          font-weight: 500;
        }

        .auth-subheading {
          font-family: var(--font-sans);
          font-size: var(--text-small);
          line-height: var(--lh-body);
          color: var(--color-stone);
          margin: 0 0 24px 0;
        }

        .auth-form-card {
          width: 100%;
          display: flex;
          flex-direction: column;
        }

        .auth-google-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          width: 100%;
          min-height: 52px;
          border-radius: var(--radius-pill);
          border: 1px solid var(--color-ink);
          background: transparent;
          color: var(--color-ink);
          font-family: var(--font-sans);
          font-size: var(--text-body);
          font-weight: 500;
          cursor: pointer;
          transition: opacity 0.2s ease;
        }
        .auth-google-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .auth-divider {
          display: flex;
          align-items: center;
          gap: 12px;
          margin: 16px 0;
        }

        .auth-line {
          flex: 1;
          height: 1px;
          background: var(--color-sand);
        }

        .auth-or-text {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }

        .auth-email-form {
          display: flex;
          flex-direction: column;
          gap: 8px;
          width: 100%;
        }

        .auth-input {
          width: 100%;
          box-sizing: border-box;
          min-height: 52px;
          padding: 12px 16px;
          font-family: var(--font-sans);
          font-size: var(--text-body);
          color: var(--color-ink);
          background: var(--color-beige);
          border: 2px solid var(--color-sand);
          border-radius: 12px;
          outline: none;
          transition: border-color 0.15s ease;
        }

        .auth-input:focus {
          border-color: var(--color-ink);
        }

        .auth-error-inline {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          margin-top: 2px;
        }

        .auth-demo-hint {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--color-stone);
          margin: 4px 0 12px 0;
          line-height: 1.4;
        }

        .auth-footer-inner {
          display: flex;
          flex-direction: column;
          gap: 12px;
          width: 100%;
          transition: padding-bottom 0.2s ease;
        }

        .auth-submit-btn {
          min-height: 52px;
          border-radius: var(--radius-pill);
          background: var(--color-marigold);
          color: var(--color-ink);
          font-family: var(--font-sans);
          font-weight: 600;
          font-size: var(--text-body);
          border: none;
          cursor: pointer;
          transition: opacity 0.2s ease;
        }

        .auth-submit-btn:disabled {
          opacity: 0.45;
          cursor: not-allowed;
        }

        .auth-terms {
          font-family: var(--font-sans);
          font-size: 13px;
          color: var(--color-stone);
          margin: 0;
          text-align: center;
          opacity: 0.7;
        }

        .sr-only {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          border: 0;
        }
      `}</style>
    </ScreenLayout>
  );
}
