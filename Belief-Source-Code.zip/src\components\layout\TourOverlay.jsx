import React from 'react';
import { Lock, ArrowLeft, ArrowRight } from 'lucide-react';

/**
 * TourOverlay — The demo layer for the judge path.
 * Renders the top bar with the stop label and the bottom bar with progress dots.
 */
export default function TourOverlay({
  currentStop,
  currentStopIndex,
  totalStops,
  isPeach,
  onPrev,
  onNext,
  onExit,
  isFirstStop,
  isLastStop
}) {
  if (!currentStop) return null;

  return (
    <>
      <div className={`tour-bar ${isPeach ? 'tour-bar--peach' : ''}`}>
        <div className="flex-row items-center gap-1">
          <span className="tour-label">{currentStop.label}</span>
        </div>
        <div className="flex-row items-center gap-1">
          <span className="tour-sample-tag">Sample</span>
          <Lock size={13} strokeWidth={2} aria-hidden="true" />
        </div>
      </div>

      <div className={`tour-nav ${isPeach ? 'tour-nav--peach' : ''}`}>
        <div className="progress-dots">
          {Array.from({ length: totalStops }).map((_, i) => (
            <div
              key={i}
              className={`progress-dot ${i === currentStopIndex ? 'progress-dot--active' : ''}`}
            />
          ))}
        </div>
        
        <div className="tour-nav__buttons">
          {!isFirstStop ? (
            <button className="tour-exit" onClick={onPrev} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <ArrowLeft size={14} />
              <span>Prev</span>
            </button>
          ) : (
            <div style={{ width: '40px' }} />
          )}
          
          <button className="tour-exit" onClick={onExit}>
            Exit tour
          </button>

          {!isLastStop ? (
            <button className="tour-exit" onClick={onNext} style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span>Next</span>
              <ArrowRight size={14} />
            </button>
          ) : (
            <div style={{ width: '40px' }} />
          )}
        </div>
      </div>
    </>
  );
}
