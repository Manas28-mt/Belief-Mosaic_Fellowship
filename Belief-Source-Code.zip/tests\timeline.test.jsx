import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, act, cleanup, waitFor } from '@testing-library/react';

// Components & DB
import WalkthroughEnd from '../src/components/timeline/WalkthroughEnd.jsx';
import TimelineBuilder from '../src/components/timeline/TimelineBuilder.jsx';
import TimelineView from '../src/components/timeline/TimelineView.jsx';
import RealHome from '../src/components/home/RealHome.jsx';
import {
  saveTimelineAnswer,
  getTimelineAnswers,
  clearTimelineAnswers
} from '../src/services/db.js';
import { TIMELINE_QUESTIONS } from '../src/data/timelineQuestions.js';

// Setup browser mocks for jsdom
beforeEach(async () => {
  cleanup();
  await clearTimelineAnswers();

  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: vi.fn().mockImplementation((query) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: vi.fn(),
      removeListener: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })),
  });

  window.visualViewport = {
    height: 800,
    width: 400,
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
  };
});

afterEach(() => {
  cleanup();
});

describe('Timeline feature tests', () => {
  // Test 1: the walkthrough end shows the two buttons
  it('the walkthrough end shows the two buttons', () => {
    const handleStart = vi.fn();
    const handleLater = vi.fn();

    render(<WalkthroughEnd onStartTimeline={handleStart} onLater={handleLater} />);

    // 1. Primary button: "Build your timeline"
    const startBtn = screen.getByRole('button', { name: /Build your timeline/i });
    expect(startBtn).toBeDefined();
    expect(startBtn.className).toContain('btn--primary');

    // 2. Outlined button: "Later"
    const laterBtn = screen.getByRole('button', { name: /Later/i });
    expect(laterBtn).toBeDefined();
    expect(laterBtn.className).toContain('btn--secondary');

    // Verify button clicks
    fireEvent.click(startBtn);
    expect(handleStart).toHaveBeenCalledTimes(1);

    fireEvent.click(laterBtn);
    expect(handleLater).toHaveBeenCalledTimes(1);

    // Verify Balu mascot is rendered with pose point
    const baluImg = screen.getByAltText(/Balu/i);
    expect(baluImg).toBeDefined();
    expect(baluImg.getAttribute('src')).toContain('point');
  });

  // Test 2: the home card shows the right state for not started, partly done and done
  it('the home card shows the right state for not started, partly done and done', async () => {
    // 2a. Not started
    const { unmount } = render(<RealHome isDemo={false} />);
    await waitFor(() => {
      expect(screen.getByText('Build your timeline')).toBeDefined();
    });
    // Gentle: no numbers, no percentages, no red
    expect(screen.queryByText(/%/)).toBeNull();
    expect(screen.queryByText(/1 of 2/)).toBeNull();
    unmount();

    // 2b. Partly done (save answer for question 1)
    await saveTimelineAnswer({
      id: TIMELINE_QUESTIONS[0].id,
      questionId: TIMELINE_QUESTIONS[0].id,
      text: 'Won school quiz',
      skipped: false
    });

    const { unmount: unmountPartly } = render(<RealHome isDemo={false} />);
    await waitFor(() => {
      expect(screen.getByText('Complete your timeline')).toBeDefined();
    });
    // Still gentle: no percentages, no numbers
    expect(screen.queryByText(/%/)).toBeNull();
    expect(screen.queryByText(/50%/)).toBeNull();
    unmountPartly();

    // 2c. Done (save answer or skip for question 2)
    await saveTimelineAnswer({
      id: TIMELINE_QUESTIONS[1].id,
      questionId: TIMELINE_QUESTIONS[1].id,
      text: 'Prepared alone during boards',
      skipped: false
    });

    render(<RealHome isDemo={false} />);
    await waitFor(() => {
      expect(screen.getByText('Your timeline')).toBeDefined();
    });
    expect(screen.queryByText(/%/)).toBeNull();
    expect(screen.queryByText(/100%/)).toBeNull();
  });

  // Test 3: resume opens the first unanswered question
  it('resume opens the first unanswered question', async () => {
    // Answer question 1 only
    await saveTimelineAnswer({
      id: TIMELINE_QUESTIONS[0].id,
      questionId: TIMELINE_QUESTIONS[0].id,
      text: 'Math olympiad',
      skipped: false
    });

    // When TimelineBuilder mounts with initialIndex undefined, it should detect q1 is answered and resume at q2
    render(<TimelineBuilder initialIndex={undefined} onComplete={vi.fn()} />);

    // Wait for questions to load and verify Question 2 is rendered
    await waitFor(() => {
      expect(screen.getByText(new RegExp(TIMELINE_QUESTIONS[1].question, 'i'))).toBeDefined();
    });
  });

  // Test 4: skipping works
  it('skipping works and records skipped status in IndexedDB', async () => {
    const handleComplete = vi.fn();
    render(<TimelineBuilder initialIndex={0} onComplete={handleComplete} />);

    // Click Skip on Q1
    const skipBtn = await screen.findByRole('button', { name: /^Skip$/i });
    fireEvent.click(skipBtn);

    // Verify Q1 is recorded in DB as skipped
    await waitFor(async () => {
      const stored = await getTimelineAnswers();
      const q1Record = stored.find((item) => item.id === TIMELINE_QUESTIONS[0].id);
      expect(q1Record).toBeDefined();
      expect(q1Record?.skipped).toBe(true);
    });

    // Should now be on Q2
    await waitFor(() => {
      expect(screen.getByText(new RegExp(TIMELINE_QUESTIONS[1].question, 'i'))).toBeDefined();
    });

    // Click Skip on Q2
    const skipBtn2 = screen.getByRole('button', { name: /^Skip$/i });
    fireEvent.click(skipBtn2);

    // Verify Q2 is recorded as skipped and onComplete was called
    await waitFor(async () => {
      const stored = await getTimelineAnswers();
      const q2Record = stored.find((item) => item.id === TIMELINE_QUESTIONS[1].id);
      expect(q2Record).toBeDefined();
      expect(q2Record?.skipped).toBe(true);
      expect(handleComplete).toHaveBeenCalledTimes(1);
    });
  });

  // Test 5: answers persist after remount
  it('answers persist after remount', async () => {
    // 5a. Mount TimelineBuilder, type an answer
    const { unmount } = render(<TimelineBuilder initialIndex={0} onComplete={vi.fn()} />);

    const textarea = await screen.findByRole('textbox', { name: /Your answer in your own words/i });
    fireEvent.change(textarea, { target: { value: 'Persisted memory in my own words' } });

    // Wait for save to complete
    await waitFor(async () => {
      const stored = await getTimelineAnswers();
      const q1Record = stored.find((item) => item.id === TIMELINE_QUESTIONS[0].id);
      expect(q1Record?.text).toBe('Persisted memory in my own words');
    });

    // 5b. Unmount
    unmount();

    // 5c. Remount TimelineBuilder and verify text is still there
    render(<TimelineBuilder initialIndex={0} onComplete={vi.fn()} />);

    await waitFor(() => {
      const remountedTextarea = screen.getByRole('textbox', { name: /Your answer in your own words/i });
      expect(remountedTextarea.value).toBe('Persisted memory in my own words');
    });

    cleanup();

    // 5d. Mount TimelineView and verify answer is displayed in timeline view
    render(<TimelineView onBack={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText(/"Persisted memory in my own words"/i)).toBeDefined();
    });
  });
});
