import { openDB } from 'idb';

const DB_NAME = 'belief_local_db';
const DB_VERSION = 2;

let inMemoryStore = {
  auth: new Map(),
  entries: new Map(),
  settings: new Map(),
  contacts: new Map(),
  timeline: new Map(),
};

export async function initDb() {
  if (typeof indexedDB === 'undefined') {
    return {
      get: async (store, key) => inMemoryStore[store]?.get(key),
      put: async (store, val) => {
        const id = val.key ?? val.id;
        inMemoryStore[store]?.set(id, val);
        return id;
      },
      getAll: async (store) => Array.from(inMemoryStore[store]?.values() || []),
      count: async (store) => inMemoryStore[store]?.size || 0,
      clear: async (store) => inMemoryStore[store]?.clear(),
    };
  }

  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('auth')) {
        db.createObjectStore('auth', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('entries')) {
        db.createObjectStore('entries', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('contacts')) {
        db.createObjectStore('contacts', { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains('timeline')) {
        db.createObjectStore('timeline', { keyPath: 'id' });
      }
    },
  });
}

// Auth helpers
export async function getStoredAuth() {
  const db = await initDb();
  return db.get('auth', 'credentials');
}

export async function setStoredAuth(credentials) {
  const db = await initDb();
  return db.put('auth', { key: 'credentials', ...credentials });
}

// Entries helpers
export async function saveEntry(entry) {
  const db = await initDb();
  return db.put('entries', entry);
}

export async function getAllEntries() {
  const db = await initDb();
  return db.getAll('entries');
}

export async function getEntriesCount() {
  const db = await initDb();
  return db.count('entries');
}

// Settings helpers
export async function getSetting(key) {
  const db = await initDb();
  const record = await db.get('settings', key);
  return record ? record.value : null;
}

export async function setSetting(key, value) {
  const db = await initDb();
  return db.put('settings', { key, value });
}

// Contacts helpers (stored locally only, never sent to server)
export async function getTrustedContact() {
  const db = await initDb();
  const record = await db.get('contacts', 'trusted_person');
  return record ? record.contact : null;
}

export async function saveTrustedContact(contact) {
  const db = await initDb();
  return db.put('contacts', { key: 'trusted_person', contact });
}

// Timeline helpers (stored locally only, never mixed with demo data)
export async function saveTimelineAnswer(answer) {
  const db = await initDb();
  // Ensure record has id
  const record = {
    id: answer.id || answer.questionId,
    questionId: answer.questionId || answer.id,
    questionText: answer.questionText || '',
    text: answer.text ?? '',
    answer: answer.text ?? answer.answer ?? '',
    skipped: Boolean(answer.skipped),
    updatedAt: answer.updatedAt || new Date().toISOString(),
    year: answer.year || 'Milestone',
    ...answer,
  };
  return db.put('timeline', record);
}

export async function getTimelineAnswers() {
  const db = await initDb();
  return db.getAll('timeline');
}

export async function getTimelineAnswer(id) {
  const db = await initDb();
  return db.get('timeline', id);
}

export async function clearTimelineAnswers() {
  const db = await initDb();
  if (typeof indexedDB === 'undefined') {
    inMemoryStore.timeline?.clear();
    return;
  }
  return db.clear('timeline');
}

