import { useState, useCallback, useEffect, lazy, Suspense } from 'react';
import Splash from './components/opening/Splash';
import AuthScreen from './components/auth/AuthScreen';
import VisualStory from './components/mascot/VisualStory';
import TimelineSetup from './components/auth/TimelineSetup';
import RealHome from './components/home/RealHome';

// Timeline feature components
import WalkthroughEnd from './components/timeline/WalkthroughEnd';
import TimelineBuilder from './components/timeline/TimelineBuilder';
import TimelineView from './components/timeline/TimelineView';

// Background routes and deep linking preserved underneath
import BadDayMode from './components/badday/BadDayMode';
import SilenceCheckin from './components/signals/SilenceCheckin';
import BaluScreen from './components/mascot/BaluScreen';
import CrisisScreen from './components/crisis/CrisisScreen';

// Dev routes completely excluded from production builds
const DevPanel = import.meta.env.DEV
  ? lazy(() => import('./components/dev/DevPanel'))
  : null;
const BaluPlayground = import.meta.env.DEV
  ? lazy(() => import('./components/balu/BaluPlayground'))
  : null;

const VALID_SCREENS = [
  'splash',
  'auth',
  'story',
  'walkthrough-end',
  'timeline-builder',
  'timeline-view',
  'setup',
  'home',
  'playback',
  'checkin',
  'balu',
  'crisis',
  ...(import.meta.env.DEV ? ['dev-balu'] : [])
];

export default function App() {
  const getInitialScreen = () => {
    if (typeof window !== 'undefined') {
      if (window.location.pathname === '/crisis') return 'crisis';
      if (import.meta.env.DEV && window.location.pathname === '/dev/balu') return 'dev-balu';
    }
    return 'splash';
  };

  const getInitialDemo = () => {
    if (typeof window !== 'undefined') {
      try {
        return window.sessionStorage?.getItem('belief_is_demo') === '1';
      } catch {
        return false;
      }
    }
    return false;
  };

  const [screen, setScreen] = useState(getInitialScreen);
  const [history, setHistory] = useState(() => [getInitialScreen()]);
  const [isDemo, setIsDemo] = useState(getInitialDemo);
  const [recordReady, setRecordReady] = useState(false);
  const [isBaluInvite, setIsBaluInvite] = useState(false);
  const [timelineResumeIndex, setTimelineResumeIndex] = useState(0);

  // Navigate forward with history stack
  const navigate = useCallback((nextScreen) => {
    setHistory((prev) => [...prev, nextScreen]);
    setScreen(nextScreen);
  }, []);

  // Back always goes to previous screen in history
  const handleBack = useCallback(() => {
    setHistory((prev) => {
      if (prev.length > 1) {
        const nextHist = prev.slice(0, -1);
        const prevScreen = nextHist[nextHist.length - 1];
        setScreen(prevScreen);
        return nextHist;
      } else {
        setScreen('home');
        return ['home'];
      }
    });
  }, []);

  // Handle URL query parameter (?open=)
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      const openParam = url.searchParams.get('open');
      if (openParam) {
        if (openParam === 'record') {
          navigate('home');
          setRecordReady(true);
        } else if (openParam === 'playback') {
          navigate('playback');
        } else if (openParam === 'checkin') {
          navigate('checkin');
        } else if (openParam === 'balu') {
          setIsBaluInvite(true);
          navigate('balu');
        } else if (openParam === 'crisis') {
          navigate('crisis');
        }
        url.searchParams.delete('open');
        window.history.replaceState({}, '', url.pathname + (url.search ? url.search : '') + url.hash);
      }
    } catch {
      // Ignore URL parsing errors
    }
  }, [navigate]);

  const handleSplashDone = useCallback(() => navigate('auth'), [navigate]);
  const handleLogin = useCallback((loginData) => {
    const isDemoAccount = Boolean(loginData?.isDemo);
    setIsDemo(isDemoAccount);
    try {
      window.sessionStorage?.setItem('belief_is_demo', isDemoAccount ? '1' : '0');
    } catch {
      // Ignore
    }
    navigate('story');
  }, [navigate]);

  // After the walkthrough ends: show walkthrough-end screen with Balu (point) and 2 buttons
  const handleStoryComplete = useCallback(() => navigate('walkthrough-end'), [navigate]);
  const handleSetupComplete = useCallback(() => navigate('home'), [navigate]);

  const renderScreen = () => {
    switch (screen) {
      case 'splash':
        return <Splash onDone={handleSplashDone} />;
      case 'auth':
        return <AuthScreen onLogin={handleLogin} />;
      case 'story':
        return <VisualStory onComplete={handleStoryComplete} />;
      case 'walkthrough-end':
        return (
          <WalkthroughEnd
            onStartTimeline={() => {
              setTimelineResumeIndex(0);
              navigate('timeline-builder');
            }}
            onLater={() => navigate('home')}
          />
        );
      case 'timeline-builder':
        return (
          <TimelineBuilder
            initialIndex={timelineResumeIndex}
            onComplete={() => navigate('timeline-view')}
            onSaveAndFinishLater={() => navigate('home')}
          />
        );
      case 'timeline-view':
        return (
          <TimelineView
            onBack={() => navigate('home')}
            onEditQuestion={(qIdx) => {
              setTimelineResumeIndex(qIdx);
              navigate('timeline-builder');
            }}
          />
        );
      case 'setup':
        return <TimelineSetup onComplete={handleSetupComplete} />;
      case 'home':
        return (
          <RealHome
            isFirstLogin={false}
            isDemo={isDemo}
            initialRecordReady={recordReady}
            onOpenCrisis={() => navigate('crisis')}
            onOpenTimeline={({ mode, resumeIndex }) => {
              if (mode === 'builder') {
                setTimelineResumeIndex(resumeIndex || 0);
                navigate('timeline-builder');
              } else if (mode === 'view') {
                navigate('timeline-view');
              }
            }}
          />
        );
      case 'playback':
        return (
          <BadDayMode
            isTour={isDemo}
            onBack={handleBack}
            onOpenBalu={() => {
              setIsBaluInvite(false);
              navigate('balu');
            }}
          />
        );
      case 'checkin':
        return (
          <SilenceCheckin
            isDemo={isDemo}
            onBack={handleBack}
            onRoughPatch={() => {
              setIsBaluInvite(false);
              navigate('balu');
            }}
          />
        );
      case 'balu':
        return (
          <BaluScreen
            onBack={handleBack}
            onOpenCrisis={() => navigate('crisis')}
            fromInvite={isBaluInvite}
          />
        );
      case 'crisis':
        return <CrisisScreen onBack={handleBack} />;
      case 'dev-balu':
        return import.meta.env.DEV && BaluPlayground ? (
          <Suspense fallback={null}>
            <BaluPlayground onBack={handleBack} />
          </Suspense>
        ) : (
          <Splash onDone={handleSplashDone} />
        );
      default:
        // No blank or unhandled routes: fallback to splash
        return <Splash onDone={handleSplashDone} />;
    }
  };

  return (
    <div className="page-shell">
      {isDemo && (
        <div className="demo-badge-indicator" aria-label="Sample mode">
          Sample
        </div>
      )}
      <div className="page-content screen-enter" key={screen}>
        {renderScreen()}
      </div>
      {import.meta.env.DEV && DevPanel && (
        <Suspense fallback={null}>
          <DevPanel />
        </Suspense>
      )}
    </div>
  );
}
