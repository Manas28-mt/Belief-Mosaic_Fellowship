import React, { useState, useEffect, useRef } from 'react';
import Balu from '../balu/Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';
import { TIMELINE_QUESTIONS } from '../../data/timelineQuestions.js';
import { saveTimelineAnswer, getTimelineAnswers } from '../../services/db.js';
import { useAudioRecorder } from '../../hooks/useAudioRecorder.js';
import { useTranscription } from '../../hooks/useTranscription.js';
import { transcribeAudio } from '../../services/api.js';

/**
 * TimelineBuilder — Question Flow
 * Requirements:
 * - One question per screen, using ScreenLayout, with Continue in the footer.
 * - Every question can be skipped and has an "in my own words" option (typed and spoken).
 * - Answers save to IndexedDB the moment they are given, so closing the app never loses progress.
 * - A visible "Save and finish later" on every question returns to home.
 * - After the last question, show the person's timeline right away.
 */
export default function TimelineBuilder({ initialIndex, onComplete, onSaveAndFinishLater }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex ?? 0);
  const [answersMap, setAnswersMap] = useState({});
  const [currentText, setCurrentText] = useState('');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const total = TIMELINE_QUESTIONS.length;
  const currentQ = TIMELINE_QUESTIONS[currentIndex] || TIMELINE_QUESTIONS[0];

  const {
    isRecording,
    duration,
    startRecording,
    stopRecording
  } = useAudioRecorder();

  const {
    transcript,
    isSupported,
    startListening,
    stopListening,
    updateTranscript
  } = useTranscription();

  // Load existing answers on mount
  useEffect(() => {
    async function loadAnswers() {
      try {
        const stored = await getTimelineAnswers();
        const map = {};
        stored.forEach((item) => {
          map[item.id] = item;
        });
        setAnswersMap(map);

        // If initialIndex wasn't explicitly passed, resume at first unanswered
        if (initialIndex === undefined || initialIndex === null) {
          const firstUnanswered = TIMELINE_QUESTIONS.findIndex(
            (q) => !map[q.id] || (!map[q.id].text && !map[q.id].skipped)
          );
          if (firstUnanswered !== -1) {
            setCurrentIndex(firstUnanswered);
          }
        }
      } catch {
        // Fallback to initialIndex
      }
    }
    loadAnswers();
  }, [initialIndex]);

  // Sync current text whenever currentIndex or answersMap changes
  useEffect(() => {
    const existing = answersMap[currentQ?.id];
    setCurrentText(existing?.text || '');
  }, [currentIndex, currentQ, answersMap]);

  // Sync real-time spoken transcript if speech recognition is active
  useEffect(() => {
    if (transcript && transcript.trim() && isRecording) {
      setCurrentText(transcript.trim());
    }
  }, [transcript, isRecording]);


  // Immediate save on typing
  const handleTextChange = async (e) => {
    const val = e.target.value;
    setCurrentText(val);

    const record = {
      id: currentQ.id,
      questionId: currentQ.id,
      questionText: currentQ.question,
      title: currentQ.title,
      year: currentQ.year,
      text: val,
      answer: val,
      skipped: false,
      updatedAt: new Date().toISOString(),
    };

    setAnswersMap((prev) => ({ ...prev, [currentQ.id]: record }));
    try {
      await saveTimelineAnswer(record);
    } catch {
      // Ignore DB error
    }
  };

  // Mic recording toggle
  const handleToggleRecord = async () => {
    if (!isRecording) {
      if (isSupported) startListening();
      await startRecording();
    } else {
      if (isSupported) stopListening();
      stopRecording(async (blob) => {
        // If live speech recognition was unsupported or produced nothing, try fallback
        if (blob && (!currentText || !currentText.trim())) {
          setIsTranscribing(true);
          const serverText = await transcribeAudio(blob);
          setIsTranscribing(false);
          if (serverText && serverText.trim()) {
            const val = serverText.trim();
            setCurrentText(val);
            const record = {
              id: currentQ.id,
              questionId: currentQ.id,
              questionText: currentQ.question,
              title: currentQ.title,
              year: currentQ.year,
              text: val,
              answer: val,
              skipped: false,
              updatedAt: new Date().toISOString(),
            };
            setAnswersMap((prev) => ({ ...prev, [currentQ.id]: record }));
            await saveTimelineAnswer(record);
          }
        } else if (currentText && currentText.trim()) {
          // Ensure live speech transcribed text is persisted to DB
          const val = currentText.trim();
          const record = {
            id: currentQ.id,
            questionId: currentQ.id,
            questionText: currentQ.question,
            title: currentQ.title,
            year: currentQ.year,
            text: val,
            answer: val,
            skipped: false,
            updatedAt: new Date().toISOString(),
          };
          setAnswersMap((prev) => ({ ...prev, [currentQ.id]: record }));
          await saveTimelineAnswer(record);
        }
      });
    }
  };

  // Skip this question
  const handleSkip = async () => {
    if (isRecording) {
      stopRecording();
      if (isSupported) stopListening();
    }

    const record = {
      id: currentQ.id,
      questionId: currentQ.id,
      questionText: currentQ.question,
      title: currentQ.title,
      year: currentQ.year,
      text: '',
      answer: '',
      skipped: true,
      updatedAt: new Date().toISOString(),
    };

    setAnswersMap((prev) => ({ ...prev, [currentQ.id]: record }));
    try {
      await saveTimelineAnswer(record);
    } catch {
      // Ignore
    }

    if (currentIndex < total - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      onComplete?.();
    }
  };

  // Continue to next question or complete
  const handleContinue = async () => {
    if (isRecording) {
      stopRecording();
      if (isSupported) stopListening();
    }

    // Save current answer state
    const record = {
      id: currentQ.id,
      questionId: currentQ.id,
      questionText: currentQ.question,
      title: currentQ.title,
      year: currentQ.year,
      text: currentText.trim(),
      answer: currentText.trim(),
      skipped: !currentText.trim(),
      updatedAt: new Date().toISOString(),
    };

    setAnswersMap((prev) => ({ ...prev, [currentQ.id]: record }));
    try {
      await saveTimelineAnswer(record);
    } catch {
      // Ignore
    }

    if (currentIndex < total - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // After last question, show timeline right away
      onComplete?.();
    }
  };

  const handleFinishLater = async () => {
    if (isRecording) {
      stopRecording();
      if (isSupported) stopListening();
    }
    // Save whatever is currently typed
    if (currentText.trim()) {
      const record = {
        id: currentQ.id,
        questionId: currentQ.id,
        questionText: currentQ.question,
        title: currentQ.title,
        year: currentQ.year,
        text: currentText.trim(),
        answer: currentText.trim(),
        skipped: false,
        updatedAt: new Date().toISOString(),
      };
      try {
        await saveTimelineAnswer(record);
      } catch {
        // Ignore
      }
    }
    onSaveAndFinishLater?.();
  };

  const headerContent = (
    <div className="builder-header">
      <div className="builder-top-row">
        <button
          type="button"
          className="btn btn--ghost finish-later-btn"
          onClick={handleFinishLater}
        >
          Save and finish later
        </button>
      </div>
      <div className="builder-progress-line">
        <div
          className="builder-progress-fill"
          style={{ width: `${((currentIndex + 1) / total) * 100}%` }}
        />
      </div>
    </div>
  );

  const footerContent = (
    <div className="builder-footer-actions">
      <button
        type="button"
        className="btn btn--secondary flex-1"
        onClick={handleSkip}
      >
        Skip
      </button>
      <button
        type="button"
        className="btn btn--primary flex-1"
        onClick={handleContinue}
      >
        Continue
      </button>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      scrollKey={currentIndex}
      className="timeline-builder-layout"
    >
      <div className="builder-content">
        <div className="builder-mascot mb-2">
          <Balu pose={currentIndex === 0 ? 'listen' : 'think'} size={72} entrance="none" />
        </div>

        <div className="builder-q-badge mb-1">
          <span className="text-caption" style={{ color: 'var(--color-stone)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            {currentQ.title}
          </span>
        </div>

        <h2 className="text-voice mb-4" style={{ fontSize: '20px', lineHeight: 1.5 }}>
          "{currentQ.question}"
        </h2>

        {/* In my own words textarea */}
        <div className="builder-input-wrap mb-3">
          <label className="text-caption mb-1" style={{ display: 'block', color: 'var(--color-stone)' }}>
            In your own words
          </label>
          <textarea
            className="builder-textarea"
            placeholder={currentQ.placeholder}
            value={currentText}
            onChange={handleTextChange}
            rows={4}
            aria-label="Your answer in your own words"
          />
        </div>

        {/* Voice recording shortcut */}
        <div className="builder-mic-row">
          <button
            type="button"
            className={`builder-mic-btn ${isRecording ? 'is-recording' : ''}`}
            onClick={handleToggleRecord}
            aria-label={isRecording ? 'Stop speaking' : 'Speak your answer'}
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18">
              <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
            </svg>
            <span>{isRecording ? `Recording... (${duration}s)` : isTranscribing ? 'Transcribing...' : 'Speak instead'}</span>
          </button>
        </div>
      </div>

      <style>{`
        .builder-header {
          display: flex;
          flex-direction: column;
          width: 100%;
          padding: 8px 0 4px;
        }
        .builder-top-row {
          display: flex;
          justify-content: flex-end;
          margin-bottom: 8px;
        }
        .finish-later-btn {
          font-size: var(--text-small);
          color: var(--color-stone);
          padding: 4px 8px;
        }
        .builder-progress-line {
          width: 100%;
          height: 3px;
          background: var(--color-sand);
          border-radius: 2px;
          overflow: hidden;
        }
        .builder-progress-fill {
          height: 100%;
          background: var(--color-marigold);
          transition: width 0.3s ease;
        }
        .builder-content {
          display: flex;
          flex-direction: column;
          width: 100%;
          max-width: 360px;
          margin: 0 auto;
        }
        .builder-mascot {
          display: flex;
          justify-content: center;
        }
        .builder-input-wrap {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .builder-textarea {
          width: 100%;
          padding: 14px;
          border-radius: var(--radius-card);
          border: 1px solid var(--color-sand);
          background: var(--color-beige);
          font-family: var(--font-serif);
          font-size: 17px;
          line-height: 1.5;
          color: var(--color-ink);
          resize: none;
          box-sizing: border-box;
          outline: none;
          min-height: 110px;
        }
        .builder-textarea:focus {
          border-color: var(--color-ink);
          background: var(--color-cream);
        }
        .builder-mic-row {
          display: flex;
          justify-content: flex-start;
          margin-top: 4px;
        }
        .builder-mic-btn {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 8px 14px;
          border-radius: var(--radius-pill);
          border: 1px solid var(--color-sand);
          background: var(--color-cream);
          color: var(--color-stone);
          font-family: var(--font-sans);
          font-size: var(--text-small);
          cursor: pointer;
        }
        .builder-mic-btn.is-recording {
          background: var(--color-peach);
          border-color: var(--color-marigold);
          color: var(--color-ink);
        }
        .builder-footer-actions {
          display: flex;
          gap: 12px;
          width: 100%;
        }
        .flex-1 {
          flex: 1;
        }
      `}</style>
    </ScreenLayout>
  );
}
