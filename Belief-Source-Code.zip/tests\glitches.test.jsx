import React from 'react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, fireEvent, act, cleanup } from '@testing-library/react';

// Components under test
import ScreenLayout from '../src/components/ScreenLayout.jsx';
import Splash from '../src/components/opening/Splash.jsx';
import AuthScreen from '../src/components/auth/AuthScreen.jsx';
import VisualStory from '../src/components/mascot/VisualStory.jsx';
import TimelineSetup from '../src/components/auth/TimelineSetup.jsx';
import BadDayMode from '../src/components/badday/BadDayMode.jsx';
import SilenceCheckin from '../src/components/signals/SilenceCheckin.jsx';
import CrisisScreen from '../src/components/crisis/CrisisScreen.jsx';
import Balu from '../src/components/balu/Balu.jsx';
import App from '../src/App.jsx';

// Setup browser API mocks for jsdom
beforeEach(() => {
  vi.useFakeTimers();

  // Mock window.matchMedia
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: vi.fn().mockImplementation((query) => ({
      matches: false,
      media: query,
      onchange: null,
      addListener: vi.fn(),
      removeListener: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    })),
  });

  // Mock window.visualViewport
  window.visualViewport = {
    height: 800,
    width: 400,
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
  };

  // Clear sessionStorage
  window.sessionStorage.clear();
});

afterEach(() => {
  cleanup();
  vi.clearAllTimers();
  vi.useRealTimers();
});

describe('1. ScreenLayout - Unified layout across all screens', () => {
  it('renders a body as the only scroll area and pins footer outside the scroll area', () => {
    const { getByTestId } = render(
      <ScreenLayout
        header={<div>Header Content</div>}
        footer={<button>Continue</button>}
      >
        <div>Body Content</div>
      </ScreenLayout>
    );

    const layout = getByTestId('screen-layout');
    const header = getByTestId('screen-layout-header');
    const body = getByTestId('screen-layout-body');
    const footer = getByTestId('screen-layout-footer');

    expect(layout).toBeDefined();
    expect(header).toBeDefined();
    expect(body).toBeDefined();
    expect(footer).toBeDefined();

    // Verify footer is a sibling of body (OUTSIDE the scroll area), not inside body
    expect(body.contains(footer)).toBe(false);
    expect(footer.querySelector('button')?.textContent).toBe('Continue');
  });

  it('opens scrolled to top and resets scrollTop when scrollKey changes', () => {
    const scrollRef = { current: { scrollTop: 150 } };
    const { rerender } = render(
      <ScreenLayout scrollKey={0} scrollRef={scrollRef}>
        <div>Content</div>
      </ScreenLayout>
    );

    expect(scrollRef.current.scrollTop).toBe(0);

    scrollRef.current.scrollTop = 200;
    rerender(
      <ScreenLayout scrollKey={1} scrollRef={scrollRef}>
        <div>Content 2</div>
      </ScreenLayout>
    );

    expect(scrollRef.current.scrollTop).toBe(0);
  });
});

describe('2. Screen-specific ScreenLayout and Footer placement', () => {
  it('AuthScreen: renders in ScreenLayout with Continue button pinned in footer', () => {
    const onLogin = vi.fn();
    const { getByTestId, getByRole } = render(<AuthScreen onLogin={onLogin} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();

    const continueBtn = getByRole('button', { name: /continue/i });
    expect(footer.contains(continueBtn)).toBe(true);
  });

  it('AuthScreen: prevents double-fire on rapid submit clicks', () => {
    const onLogin = vi.fn();
    render(<AuthScreen onLogin={onLogin} />);

    const continueBtn = screen.getByRole('button', { name: /continue/i });
    
    // Rapid clicks
    fireEvent.click(continueBtn);
    fireEvent.click(continueBtn);
    fireEvent.click(continueBtn);

    act(() => {
      vi.advanceTimersByTime(500);
    });

    // Must be called exactly once
    expect(onLogin).toHaveBeenCalledTimes(1);
  });

  it('VisualStory: renders in ScreenLayout with button strictly in footer slot', () => {
    const onComplete = vi.fn();
    const { getByTestId } = render(<VisualStory onComplete={onComplete} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();

    const actionBtn = footer.querySelector('button');
    expect(actionBtn).not.toBeNull();
  });

  it('VisualStory: prevents double-fire during transitions', () => {
    const onComplete = vi.fn();
    render(<VisualStory onComplete={onComplete} />);

    const footer = screen.getByTestId('screen-layout-footer');
    const nextBtn = footer.querySelector('button');

    // Rapidly click continue
    fireEvent.click(nextBtn);
    fireEvent.click(nextBtn);

    act(() => {
      vi.advanceTimersByTime(100);
    });

    // Should only advance by 1 scene
    expect(onComplete).not.toHaveBeenCalled();
  });

  it('TimelineSetup: renders in ScreenLayout with action buttons in footer', () => {
    const onComplete = vi.fn();
    const { getByTestId } = render(<TimelineSetup onComplete={onComplete} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();
    expect(footer.querySelector('button')?.textContent).toBe('Continue');
  });

  it('BadDayMode: renders in ScreenLayout with button in footer slot', () => {
    const onOpenBalu = vi.fn();
    const { getByTestId } = render(<BadDayMode onOpenBalu={onOpenBalu} isTour={false} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();
    expect(footer.querySelector('button')?.textContent).toContain('Want to add something');
  });

  it('SilenceCheckin: renders in ScreenLayout with buttons in footer slot', () => {
    const onRoughPatch = vi.fn();
    const { getByTestId } = render(<SilenceCheckin onRoughPatch={onRoughPatch} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();
    expect(footer.querySelectorAll('button').length).toBe(3);
  });

  it('CrisisScreen: renders in ScreenLayout with back button in footer slot', () => {
    const onBack = vi.fn();
    const { getByTestId } = render(<CrisisScreen onBack={onBack} />);

    expect(getByTestId('screen-layout')).toBeDefined();
    const footer = getByTestId('screen-layout-footer');
    expect(footer).toBeDefined();
    expect(footer.querySelector('button')?.textContent).toContain('Back to app');
  });
});

describe('3. Timer cleanup on unmount & strict lifecycle', () => {
  it('Splash: unmounting clears timer without firing onDone', () => {
    const onDone = vi.fn();
    const { unmount } = render(<Splash onDone={onDone} />);

    unmount();
    act(() => {
      vi.advanceTimersByTime(3000);
    });

    expect(onDone).not.toHaveBeenCalled();
  });

  it('VisualStory: line reveals reset and unmounting clears reveal timers', () => {
    const onComplete = vi.fn();
    const { unmount } = render(<VisualStory onComplete={onComplete} />);

    // Advancing 1300ms reveals first line
    act(() => {
      vi.advanceTimersByTime(1300);
    });

    unmount();
    // After unmount, remaining timers must not throw or cause setState warning
    act(() => {
      vi.advanceTimersByTime(3000);
    });
  });

  it('Balu: unmounting cancels idle blink timer without leaking recursive timer', () => {
    const { unmount } = render(<Balu expression="happy" size={64} />);

    unmount();
    act(() => {
      vi.advanceTimersByTime(10000);
    });
  });

  it('AuthScreen: unmounting cancels pending login timer', () => {
    const onLogin = vi.fn();
    const { unmount } = render(<AuthScreen onLogin={onLogin} />);

    const continueBtn = screen.getByRole('button', { name: /continue/i });
    fireEvent.click(continueBtn);

    unmount();
    act(() => {
      vi.advanceTimersByTime(1000);
    });

    expect(onLogin).not.toHaveBeenCalled();
  });
});

describe('4. Full Demo Flow Walkthrough via Continue', () => {
  it('walks smoothly through Splash -> Auth -> VisualStory (9 scenes) -> TimelineSetup -> Home without glitching', async () => {
    const { getByTestId } = render(<App />);

    // 1. Splash screen
    expect(getByTestId('screen-layout')).toBeDefined();
    act(() => {
      vi.advanceTimersByTime(3000); // Splash finishes
    });

    // 2. Auth screen
    const emailInput = screen.getByLabelText(/email/i);
    expect(emailInput).toBeDefined();
    const authContinueBtn = screen.getByRole('button', { name: /continue/i });
    fireEvent.click(authContinueBtn);

    act(() => {
      vi.advanceTimersByTime(400); // Login completes
    });

    // 3. VisualStory flow: walk through all 9 scenes using Continue in footer
    for (let sceneIdx = 0; sceneIdx < 9; sceneIdx++) {
      const footer = screen.getByTestId('screen-layout-footer');
      expect(footer).toBeDefined();
      const continueBtn = footer.querySelector('button');
      expect(continueBtn).not.toBeNull();

      fireEvent.click(continueBtn);
      act(() => {
        vi.advanceTimersByTime(300);
      });
    }

    // 4. WalkthroughEnd screen
    expect(screen.getByRole('button', { name: /build your timeline/i })).toBeDefined();
    const laterBtn = screen.getByRole('button', { name: /later/i });
    expect(laterBtn).toBeDefined();

    fireEvent.click(laterBtn);
    act(() => {
      vi.advanceTimersByTime(200);
    });

    // 5. Lands safely on RealHome
    expect(screen.getByText(/your journey/i)).toBeDefined();
  });
});
