import { authenticateRequest } from '../server/lib/auth.js';
import { checkRateLimit } from '../server/lib/rateLimit.js';

export const config = {
  api: {
    bodyParser: false, // For streaming multipart audio upload
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Rate-limit: 30 requests per hour per IP
  if (!checkRateLimit(req, res)) {
    return;
  }

  // Authenticate user
  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const sarvamKey = process.env.SARVAM_API_KEY;

  // Mock fallback if Sarvam key is not configured or in mock mode
  if (!sarvamKey || process.env.USE_MOCKS === 'true') {
    return res.status(200).json({ text: '' });
  }

  try {
    // Collect incoming audio chunks in memory (never written to disk)
    const chunks = [];
    for await (const chunk of req) {
      chunks.push(chunk);
    }
    const audioBuffer = Buffer.concat(chunks);

    if (audioBuffer.length === 0) {
      return res.status(400).json({ error: 'No audio data received' });
    }

    // Forward directly to Sarvam API
    const formData = new FormData();
    const blob = new Blob([audioBuffer], { type: req.headers['content-type'] || 'audio/webm' });
    formData.append('file', blob, 'audio.webm');
    formData.append('model', 'saaras:v2');

    const sarvamRes = await fetch('https://api.sarvam.ai/speech-to-text', {
      method: 'POST',
      headers: {
        'api-subscription-key': sarvamKey,
      },
      body: formData,
    });

    if (!sarvamRes.ok) {
      return res.status(502).json({ error: 'Transcription service error' });
    }

    const sarvamData = await sarvamRes.json();
    const text = sarvamData.transcript || '';

    // Rule: Never saves audio or text
    return res.status(200).json({ text });
  } catch (err) {
    return res.status(500).json({ error: 'Transcription failed' });
  }
}
