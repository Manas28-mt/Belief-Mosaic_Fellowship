import crypto from 'crypto';
import { authenticateRequest } from '../server/lib/auth.js';
import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';

export default async function handler(req, res) {
  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (req.method === 'POST') {
    const { subscription } = req.body || {};
    if (!subscription || !subscription.endpoint) {
      return res.status(400).json({ error: 'Invalid subscription' });
    }

    const endpoint = subscription.endpoint;
    const p256dh = subscription.keys ? subscription.keys.p256dh : null;
    const auth = subscription.keys ? subscription.keys.auth : null;
    const subId = crypto.randomUUID();

    if (isUsingMockDb) {
      const mockStore = getMockStore();
      // Remove any existing subscription with same endpoint
      for (const [id, s] of mockStore.subscriptions.entries()) {
        if (s.endpoint === endpoint) {
          mockStore.subscriptions.delete(id);
        }
      }
      mockStore.subscriptions.set(subId, {
        id: subId,
        user_id: user.id,
        endpoint,
        p256dh,
        auth,
        created_at: new Date().toISOString(),
      });
      return res.status(200).json({ success: true });
    }

    const sql = getDb();
    if (!sql) return res.status(500).json({ error: 'Database unavailable' });

    try {
      await sql`
        INSERT INTO push_subscriptions (id, user_id, endpoint, p256dh, auth)
        VALUES (${subId}, ${user.id}, ${endpoint}, ${p256dh}, ${auth})
        ON CONFLICT (endpoint) DO UPDATE
        SET user_id = EXCLUDED.user_id,
            p256dh = EXCLUDED.p256dh,
            auth = EXCLUDED.auth
      `;
      return res.status(200).json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to subscribe' });
    }
  }

  if (req.method === 'DELETE') {
    const { endpoint } = req.body || {};
    if (!endpoint) {
      return res.status(400).json({ error: 'Endpoint required' });
    }

    if (isUsingMockDb) {
      const mockStore = getMockStore();
      for (const [id, s] of mockStore.subscriptions.entries()) {
        if (s.endpoint === endpoint && s.user_id === user.id) {
          mockStore.subscriptions.delete(id);
        }
      }
      return res.status(200).json({ success: true });
    }

    const sql = getDb();
    if (!sql) return res.status(500).json({ error: 'Database unavailable' });

    try {
      await sql`
        DELETE FROM push_subscriptions
        WHERE endpoint = ${endpoint} AND user_id = ${user.id}
      `;
      return res.status(200).json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to unsubscribe' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
