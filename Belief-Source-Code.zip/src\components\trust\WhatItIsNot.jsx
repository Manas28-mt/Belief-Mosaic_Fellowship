import React from 'react';
import { ArrowRight } from 'lucide-react';
import { helpContacts } from '../../data/sampleStudent';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * What It Is Not — the final tour stop.
 * Clarifies boundaries and provides the crisis route.
 * Converted to unified ScreenLayout with pinned actions in footer.
 */
export default function WhatItIsNot({ onStartOwn, onRestartTour, onWhyExists }) {
  const footerContent = (
    <div className="end-tour-actions w-full">
      <div className="text-caption mb-3 text-center" style={{ textTransform: 'uppercase', letterSpacing: '0.05em' }}>
        ── End of tour ──
      </div>
      
      <button type="button" className="btn btn--secondary btn--full mb-2" onClick={onStartOwn}>
        Start my own
      </button>
      
      <button type="button" className="btn btn--ghost mb-1 w-full text-center" onClick={onRestartTour}>
        See the tour again
      </button>
      
      <button
        type="button"
        className="btn btn--ghost w-full text-center"
        onClick={onWhyExists}
        style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
      >
        <span>Why this exists</span>
        <ArrowRight size={16} strokeWidth={2} />
      </button>
    </div>
  );

  return (
    <ScreenLayout
      footer={footerContent}
      bg="cream"
      className="what-not-layout"
    >
      <div className="what-not-content animate-fade-in-slow">
        <div className="mb-6 text-left w-full" style={{ maxWidth: '320px' }}>
          <p className="text-headline mb-1">It is not therapy.</p>
          <p className="text-headline mb-1">It is not a chatbot.</p>
          <p className="text-headline mb-4">It is not a praise machine.</p>
          
          <p className="text-body mb-6">
            If things are really hard, these people can help.
          </p>
        </div>
        
        <div className="w-full" style={{ maxWidth: '320px' }}>
          <div className="contacts text-left mb-4">
            {helpContacts.map((contact, i) => (
              <div key={i} className="mb-3">
                <div className="text-body" style={{ fontWeight: 500 }}>
                  {contact.name}: <a href={`tel:${contact.number.replace(/-/g, '')}`}>{contact.number}</a>
                </div>
                <div className="text-caption">{contact.description}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .what-not-content {
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 100%;
        }
        .end-tour-actions {
          display: flex;
          flex-direction: column;
          align-items: center;
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
