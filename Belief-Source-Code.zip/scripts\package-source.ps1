$src = "c:\Users\HP\Desktop\Belief"
$zip = "c:\Users\HP\Desktop\Belief-Source-Code.zip"

if (Test-Path $zip) {
    Remove-Item $zip -Force
}

$tempDir = Join-Path $env:TEMP ("Belief-export-" + [System.Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempDir | Out-Null

$itemsToCopy = @(
    "api",
    "docs",
    "evals",
    "public",
    "scripts",
    "server",
    "src",
    "tests",
    ".env.example",
    ".gitignore",
    ".vercelignore",
    "index.html",
    "package.json",
    "package-lock.json",
    "README.md",
    "tsconfig.json",
    "vercel.json",
    "vite.config.js",
    "vitest.config.js"
)

foreach ($item in $itemsToCopy) {
    $fullPath = Join-Path $src $item
    if (Test-Path $fullPath) {
        Copy-Item -Path $fullPath -Destination $tempDir -Recurse -Force
    }
}

Compress-Archive -Path (Join-Path $tempDir "*") -DestinationPath $zip -CompressionLevel Optimal
Remove-Item -Path $tempDir -Recurse -Force

Get-Item $zip | Select-Object Name, Length, LastWriteTime
