import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft } from 'lucide-react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Entry Detail — expands a single entry to show transcript, tags, and friend credit.
 * Converted to use ScreenLayout with timer cleanup.
 */
export default function EntryDetail({ entry, isTour, onBack }) {
  const [showToast, setShowToast] = useState(false);
  const toastTimerRef = useRef(null);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    };
  }, []);

  if (!entry) return null;

  const handleSendFriend = () => {
    setShowToast(true);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setShowToast(false), 3000);
  };

  const hasFriendMention = entry.transcript?.includes('Riya') || entry.transcript?.includes('Arjun') || entry.transcript?.includes('Priya');
  const friendName = entry.transcript?.includes('Riya') ? 'Riya' : entry.transcript?.includes('Arjun') ? 'Arjun' : 'Priya';
  
  let friendSnippet = '';
  if (hasFriendMention && entry.transcript) {
    const sentences = entry.transcript.split('. ');
    const sentence = sentences.find((s) => s.includes(friendName));
    if (sentence) {
      friendSnippet = `"${sentence.trim()}${sentence.endsWith('.') ? '' : '.'}"`;
    }
  }

  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  );

  return (
    <ScreenLayout
      header={headerContent}
      bg="cream"
      className="entry-detail-layout"
    >
      <div className="entry-detail-content">
        <div className="text-caption mb-2">
          {new Date(entry.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
        </div>
        
        <div className="card mb-4">
          <p className="text-voice">"{entry.transcript}"</p>
        </div>
        
        {entry.tags && entry.tags.length > 0 && (
          <div className="tags-section mb-6">
            <h3 className="text-small mb-2" style={{ opacity: 0.7 }}>Small things</h3>
            <div className="tags">
              {entry.tags.map((tag, i) => (
                <div key={i} className="tag-item">
                  <div className="tag-item__dot"></div>
                  <span>{tag}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {hasFriendMention && (
          <div className="friend-credit card card--friend">
            <div className="text-small mb-2" style={{ fontWeight: 500, color: 'var(--color-leaf)' }}>
              Send to {friendName}?
            </div>
            <p className="text-voice mb-3" style={{ fontSize: '0.95rem' }}>
              {friendSnippet}
            </p>
            <button type="button" className="btn btn--leaf btn--small" onClick={handleSendFriend}>
              Send note
            </button>
            
            {showToast && (
              <div className="toast animate-slide-up">
                In the full app, {friendName} would get this note.
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        .entry-detail-content {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .toast {
          margin-top: var(--space-2);
          padding: var(--space-1) var(--space-2);
          background-color: var(--color-ink);
          color: var(--color-cream);
          font-family: var(--font-sans);
          font-size: var(--text-caption);
          border-radius: var(--radius-small);
          text-align: center;
        }
      `}</style>
    </ScreenLayout>
  );
}
