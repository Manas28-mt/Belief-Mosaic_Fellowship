import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Mic } from 'lucide-react';
import { getAllEntries, saveEntry, getSetting, setSetting } from '../../services/db.js';
import { interactWithBalu, transcribeAudio } from '../../services/api.js';
import { useAudioRecorder } from '../../hooks/useAudioRecorder.js';
import { useTranscription } from '../../hooks/useTranscription.js';
import { verifyQuoteSubstring } from '../../utils/quotes.js';
import ReachSomeone from '../trust/ReachSomeone.jsx';
import Balu from '../balu/Balu.jsx';
import ScreenLayout from '../ScreenLayout.jsx';

function formatDate(dateStr) {
  try {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } catch {
    return 'Recently';
  }
}

/**
 * BaluScreen — Empathetic check-in conversation with Balu.
 * Converted to use unified ScreenLayout:
 * - Pinned input and action buttons in footer slot.
 * - Double-fire protection.
 * - Single scrollable body with auto scroll to bottom on message add.
 */
export default function BaluScreen({ onBack, onOpenCrisis, fromInvite = false }) {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [turn, setTurn] = useState(1);
  const [isEnded, setIsEnded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [alreadyCompletedToday, setAlreadyCompletedToday] = useState(false);
  const [pastQuoteInfo, setPastQuoteInfo] = useState({ quote: '', date: '' });
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [hasNodded, setHasNodded] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(true);
  const speakTimerRef = useRef(null);
  const messagesEndRef = useRef(null);

  const localToday = new Date().toISOString().split('T')[0];

  const triggerSpeaking = () => {
    setIsSpeaking(true);
    if (speakTimerRef.current) clearTimeout(speakTimerRef.current);
    speakTimerRef.current = setTimeout(() => {
      setIsSpeaking(false);
    }, 1800);
  };

  useEffect(() => {
    return () => {
      if (speakTimerRef.current) clearTimeout(speakTimerRef.current);
    };
  }, []);

  const {
    isRecording,
    startRecording,
    stopRecording
  } = useAudioRecorder();

  const {
    transcript,
    isSupported,
    startListening,
    stopListening
  } = useTranscription();

  // Sync live spoken words to input
  useEffect(() => {
    if (transcript && transcript.trim() && isRecording) {
      setInputText(transcript.trim());
    }
  }, [transcript, isRecording]);

  // Scroll to latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, isEnded]);

  // Pick quote locally and initialize session
  useEffect(() => {
    let isMounted = true;

    async function initSession() {
      // Check 1 Balu session per local day
      const lastSessionDate = await getSetting('balu_last_session_date');
      if (lastSessionDate === localToday) {
        if (isMounted) setAlreadyCompletedToday(true);
        return;
      }

      const allEntries = await getAllEntries();
      let pickedQuote = '';
      let pickedDate = '';

      // Prefer a level 0 entry within 14 days after level >= 1
      if (allEntries && allEntries.length > 0) {
        const sorted = [...allEntries].sort((a, b) => new Date(a.date) - new Date(b.date));
        for (let i = 0; i < sorted.length; i++) {
          if (sorted[i].level >= 1) {
            const heavyTime = new Date(sorted[i].date).getTime();
            for (let j = i + 1; j < sorted.length; j++) {
              const diffDays = (new Date(sorted[j].date).getTime() - heavyTime) / (1000 * 60 * 60 * 24);
              if (diffDays <= 14 && sorted[j].level === 0 && sorted[j].text) {
                pickedQuote = sorted[j].text;
                pickedDate = formatDate(sorted[j].date);
                break;
              }
            }
          }
          if (pickedQuote) break;
        }

        // Fallback: most recent entry text
        if (!pickedQuote) {
          const latest = sorted[sorted.length - 1];
          if (latest && latest.text) {
            pickedQuote = latest.text;
            pickedDate = formatDate(latest.date);
          }
        }
      }

      // Default sample fallback if no entries yet
      if (!pickedQuote) {
        pickedQuote = "I stayed up rewriting the assignment because I knew it wasn't my best work.";
        pickedDate = "August 22";
      }

      // Verify exact substring
      const valid = verifyQuoteSubstring(pickedQuote, pickedQuote);
      if (!valid) {
        pickedQuote = "I showed up today.";
        pickedDate = "Earlier";
      }

      if (!isMounted) return;
      setPastQuoteInfo({ quote: pickedQuote, date: pickedDate });

      // Opening line is built in code, not by LLM
      const openingMessage = {
        role: 'assistant',
        content: `On ${pickedDate} you said: "${pickedQuote}". What happened today?`,
      };
      setMessages([openingMessage]);
      triggerSpeaking();
    }

    initSession();

    return () => {
      isMounted = false;
    };
  }, [localToday]);

  const handleSend = async (textToSend) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading || isEnded) return; // double-fire prevention

    setInputText('');
    const newMessages = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    setIsLoading(true);

    try {
      const response = await interactWithBalu({
        pastQuote: pastQuoteInfo.quote,
        pastDate: pastQuoteInfo.date,
        todayEntry: text,
        messages: newMessages,
        turn: turn,
      });

      setIsLoading(false);

      // Crisis check: immediate route to /crisis
      if (response.crisis) {
        if (onOpenCrisis) {
          onOpenCrisis();
        }
        return;
      }

      const baluReply = response.reply || 'Noted, in your words.';
      const nextMessages = [...newMessages, { role: 'assistant', content: baluReply }];
      setMessages(nextMessages);
      triggerSpeaking();

      if (response.end || turn >= 3) {
        setIsEnded(true);
        setHasNodded(true);
        await handleSaveSession(nextMessages);
      } else {
        setTurn((prev) => prev + 1);
      }
    } catch {
      setIsLoading(false);
      const fallbackReply = 'Noted, in your words.';
      const nextMessages = [...newMessages, { role: 'assistant', content: fallbackReply }];
      setMessages(nextMessages);
      triggerSpeaking();
      setIsEnded(true);
      setHasNodded(true);
      await handleSaveSession(nextMessages);
    }
  };

  const handleSaveSession = async (sessionMessages) => {
    const userLines = sessionMessages
      .filter((m) => m.role === 'user')
      .map((m) => m.content);

    const fullText = userLines.join('\n\n');

    const entry = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      prompt: `Balu follow-up: "${pastQuoteInfo.quote}"`,
      text: fullText,
      transcript: fullText,
      userLines: userLines,
      isBaluSession: true,
      level: 0,
      smallThings: ['shared words with Balu'],
    };

    await saveEntry(entry);
    await setSetting('balu_last_session_date', localToday);
  };

  const handleMicToggle = async () => {
    if (!isRecording) {
      if (isSupported) startListening();
      await startRecording();
    } else {
      if (isSupported) stopListening();
      stopRecording(async (blob) => {
        if (blob && (!inputText || !inputText.trim())) {
          setIsTranscribing(true);
          const text = await transcribeAudio(blob);
          setIsTranscribing(false);
          if (text && text.trim()) {
            setInputText(text.trim());
          }
        }
      });
    }
  };

  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  );

  if (alreadyCompletedToday) {
    return (
      <ScreenLayout
        header={headerContent}
        footer={
          <button type="button" className="btn btn--primary btn--full" onClick={onBack}>
            Back to diary
          </button>
        }
        bg="peach"
      >
        <div className="card p-4 text-center my-auto">
          <p className="text-body mb-2">You already added to your diary with Balu today.</p>
          <p className="text-small" style={{ color: 'var(--color-stone)' }}>
            One session a day keeps the effort small. Tomorrow is a new day.
          </p>
        </div>
      </ScreenLayout>
    );
  }

  const todayFormatted = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  const baluExpression = isEnded
    ? 'happy'
    : isLoading
    ? 'thinking'
    : inputText.trim()
    ? 'listening'
    : 'neutral';

  const footerContent = !isEnded ? (
    <div className="balu-footer-area">
      {isTranscribing && (
        <div className="text-caption mb-1 text-center" style={{ color: 'var(--color-stone)' }}>
          Transcribing audio...
        </div>
      )}
      <div className="balu-input-box">
        <textarea
          className="balu-textarea"
          rows={2}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Your answer..."
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
        />
        <button
          className={`balu-mic-btn ${isRecording ? 'is-recording' : ''}`}
          type="button"
          onClick={handleMicToggle}
          aria-label={isRecording ? 'Stop speaking' : 'Speak'}
        >
          <Mic size={18} strokeWidth={2} />
        </button>
      </div>
      <button
        type="button"
        className="btn btn--primary btn--full mt-2"
        onClick={() => handleSend()}
        disabled={!inputText.trim() || isLoading}
      >
        Reply
      </button>
      <div className="text-caption text-center mt-2" style={{ color: 'var(--color-stone)' }}>
        Balu is part of the app, not a person.
      </div>
    </div>
  ) : (
    <div className="balu-footer-area">
      <button type="button" className="btn btn--secondary btn--full mb-2" onClick={onBack}>
        Done
      </button>
      <div className="text-caption text-center" style={{ color: 'var(--color-stone)' }}>
        Balu is part of the app, not a person.
      </div>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="peach"
      className="balu-screen-layout"
    >
      <div className="balu-messages-list">
        {messages.map((m, idx) => {
          const isLatestAssistant = m.role === 'assistant' && idx === messages.length - 1;

          return (
            <div key={idx} className={`balu-msg-row ${m.role === 'user' ? 'user-row' : 'balu-row'}`}>
              {m.role === 'assistant' ? (
                <div className="balu-bubble-container">
                  {/* Single Balu perched on top edge of the latest speech bubble */}
                  {isLatestAssistant && !isLoading && (
                    <div className="balu-perch-top">
                      <Balu
                        pose={isEnded ? 'nod' : isSpeaking ? 'talk' : 'listen'}
                        talking={!isEnded && isSpeaking}
                        hop={isEnded}
                        entrance="none"
                        size={64}
                      />
                    </div>
                  )}
                  <div className="balu-bubble">
                    <p className="text-body" style={{ fontFamily: 'var(--font-sans)', margin: 0 }}>
                      {m.content}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="user-card">
                  <p className="text-voice" style={{ fontFamily: 'var(--font-serif)', margin: 0 }}>
                    "{m.content}"
                  </p>
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="balu-row">
            <div className="balu-bubble-container">
              <div className="balu-perch-top">
                <Balu
                  pose="think"
                  entrance="none"
                  size={64}
                />
              </div>
              <div className="balu-bubble" style={{ opacity: 0.8 }}>
                <p className="text-body" style={{ margin: 0 }}>Balu is noting...</p>
              </div>
            </div>
          </div>
        )}

        {isEnded && (
          <div className="saved-confirm-card mt-3">
            <div className="text-small" style={{ color: 'var(--color-leaf)', fontWeight: 600 }}>
              Saved to your diary. {todayFormatted}.
            </div>
            {fromInvite && (
              <ReachSomeone onOpenCrisis={onOpenCrisis} />
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <style>{`
        .balu-messages-list {
          display: flex;
          flex-direction: column;
          gap: 16px;
          width: 100%;
        }

        .balu-msg-row {
          display: flex;
          width: 100%;
        }
        .balu-row {
          justify-content: flex-start;
        }
        .user-row {
          justify-content: flex-end;
        }

        .balu-bubble-container {
          position: relative;
          max-width: 88%;
          padding-top: 24px;
        }
        .balu-perch-top {
          position: absolute;
          top: -16px;
          left: 12px;
          z-index: var(--z-mascot, 10);
        }

        .balu-bubble {
          background: var(--color-bubble);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px 20px;
          color: var(--color-ink);
          z-index: var(--z-bubble, 5);
        }
        .user-card {
          max-width: 88%;
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px 20px;
          color: var(--color-ink);
          z-index: var(--z-card, 2);
        }
        .saved-confirm-card {
          background: var(--color-cream);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px 20px;
          text-align: center;
        }
        .balu-footer-area {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .balu-input-box {
          display: flex;
          align-items: center;
          gap: 8px;
          background: var(--color-cream);
          border: 2px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 8px 12px;
          transition: border-color 0.15s ease;
        }
        .balu-input-box:focus-within {
          border-color: var(--color-ink);
        }
        .balu-textarea {
          flex: 1;
          border: none;
          background: transparent;
          font-family: var(--font-sans);
          font-size: var(--text-body);
          color: var(--color-ink);
          resize: none;
          outline: none;
        }
        .balu-mic-btn {
          width: 38px;
          height: 38px;
          border-radius: 999px;
          border: 1px solid var(--color-sand);
          background: var(--color-beige);
          color: var(--color-ink);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.2s ease;
        }
        .balu-mic-btn.is-recording {
          background: var(--color-marigold);
          border-color: var(--color-marigold);
        }
      `}</style>
    </ScreenLayout>
  );
}
