// Help contacts configuration. All contacts live only in this file.

export const HELP_CONTACTS = {
  teleManasPrimary: {
    number: '14416',
    tel: 'tel:14416',
    label: 'Tele-MANAS (Toll-Free, 24x7)',
  },
  teleManasSecondary: {
    number: '1-800-891-4416',
    tel: 'tel:18008914416',
    label: 'Tele-MANAS (Alternate)',
  },
  // FOUNDER MUST VERIFY BEFORE LAUNCH
  collegeCounsellingCell: {
    name: 'Delhi University Student Counselling Cell',
    location: 'North Campus & South Campus Support Centres',
    phone: '011-27666277',
    tel: 'tel:01127666277',
    note: 'Free psychological counselling for all enrolled DU students',
  },
};
