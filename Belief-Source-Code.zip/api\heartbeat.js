import { authenticateRequest } from '../server/lib/auth.js';
import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const user = await authenticateRequest(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const { date, score } = req.body || {};
  if (!date || typeof score !== 'number') {
    return res.status(400).json({ error: 'date and score required' });
  }

  const boundedScore = Math.min(3, Math.max(0, Math.round(score)));

  // Calculate 14-day cutoff
  const now = new Date();
  const cutoffDate = new Date(now.getTime() - 14 * 24 * 60 * 60 * 1000);
  const cutoffStr = cutoffDate.toISOString().split('T')[0];

  if (isUsingMockDb) {
    const mockStore = getMockStore();
    const storedUser = mockStore.users.get(user.id);
    if (!storedUser) return res.status(404).json({ error: 'User not found' });

    const currentScores = storedUser.day_scores || {};
    const existingScore = currentScores[date] !== undefined ? currentScores[date] : 0;
    currentScores[date] = Math.max(existingScore, boundedScore);

    // Drop keys older than 14 days
    for (const key of Object.keys(currentScores)) {
      if (key < cutoffStr) {
        delete currentScores[key];
      }
    }

    storedUser.last_entry_at = new Date().toISOString();
    storedUser.day_scores = currentScores;
    return res.status(200).json({ success: true });
  }

  const sql = getDb();
  if (!sql) return res.status(500).json({ error: 'Database unavailable' });

  try {
    const rows = await sql`
      SELECT day_scores FROM users WHERE id = ${user.id}
    `;
    const currentScores = (rows[0] && rows[0].day_scores) || {};
    const existingScore = currentScores[date] !== undefined ? currentScores[date] : 0;
    currentScores[date] = Math.max(existingScore, boundedScore);

    for (const key of Object.keys(currentScores)) {
      if (key < cutoffStr) {
        delete currentScores[key];
      }
    }

    await sql`
      UPDATE users
      SET last_entry_at = now(),
          day_scores = ${JSON.stringify(currentScores)}::jsonb
      WHERE id = ${user.id}
    `;
    return res.status(200).json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to update heartbeat' });
  }
}
