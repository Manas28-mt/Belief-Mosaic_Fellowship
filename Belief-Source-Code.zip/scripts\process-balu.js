import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const poses = [
  { name: 'wave', file: 'balu_pose_wave_1791808099149.jpg' },
  { name: 'peek', file: 'balu_pose_peek_1791808119471.jpg' },
  { name: 'point', file: 'balu_pose_point_1791808144972.jpg' },
  { name: 'listen', file: 'balu_pose_listen_1791808166923.jpg' },
  { name: 'think', file: 'balu_pose_think_1791808188581.jpg' },
  { name: 'talk', file: 'balu_pose_talk_1791808208204.jpg' },
  { name: 'soft', file: 'balu_pose_soft_1791808229785.jpg' },
  { name: 'nod', file: 'balu_pose_nod_1791808254881.jpg' },
  { name: 'fly', file: 'balu_pose_fly_1791808277258.jpg' },
  { name: 'surprised', file: 'balu_pose_surprised_1791808302609.jpg' },
];

const brainDir = 'C:\\Users\\HP\\.gemini\\antigravity-ide\\brain\\84579815-f9a8-405d-8305-82ffc2bf24bf';
const outDir = path.resolve('public/balu');

if (!fs.existsSync(outDir)) {
  fs.mkdirSync(outDir, { recursive: true });
}

async function processImage(inputPath, outputPath) {
  const { data, info } = await sharp(inputPath)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  const width = info.width;
  const height = info.height;
  const channels = info.channels; // 4 (RGBA)

  // Pixel buffer modification
  for (let i = 0; i < data.length; i += channels) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Distance to pure magenta (255, 0, 255)
    // In JPEG, magenta might compress to e.g. (250, 0, 250)
    const dr = r - 255;
    const dg = g - 0;
    const db = b - 255;
    const dist = Math.sqrt(dr * dr + dg * dg + db * db);

    // Chromakey thresholds:
    // Pure magenta background is dist < 65
    // Feathered edge is between 65 and 130
    if (dist < 70) {
      data[i + 3] = 0; // Completely transparent
    } else if (dist < 130) {
      const alphaFactor = (dist - 70) / 60; // 0 to 1
      data[i + 3] = Math.round(alphaFactor * 255);

      // Spill suppression: remove magenta/pink tint on edge pixels
      // By reducing red and blue excess relative to green/yellow
      if (b > g) {
        data[i + 2] = Math.round(g * (1 - alphaFactor) + b * alphaFactor);
      }
      if (r > 230 && g < 150) {
        data[i] = Math.round(r * alphaFactor + 200 * (1 - alphaFactor));
      }
    } else {
      // Opaque pixel
      // Check subtle magenta fringe spill where dist is slightly above 130
      if (dist < 160 && b > g + 40 && r > 200) {
        // Subtle spill suppression
        data[i + 2] = Math.min(b, Math.max(g, Math.round(b * 0.75)));
      }
    }
  }

  // Save as WebP with high quality, ensuring size < 150KB
  // 512x512 is sharp and compact for web mascots (or 600x600)
  await sharp(data, { raw: { width, height, channels } })
    .resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .webp({ quality: 88, alphaQuality: 95, effort: 6 })
    .toFile(outputPath);

  const stats = fs.statSync(outputPath);
  console.log(`Saved ${path.basename(outputPath)} (${Math.round(stats.size / 1024)} KB)`);
}

async function run() {
  for (const pose of poses) {
    const inputPath = path.join(brainDir, pose.file);
    const outputPath = path.join(outDir, `balu-${pose.name}.webp`);
    if (!fs.existsSync(inputPath)) {
      console.error(`Missing input file: ${inputPath}`);
      continue;
    }
    await processImage(inputPath, outputPath);
  }
  console.log('All poses processed successfully!');
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
