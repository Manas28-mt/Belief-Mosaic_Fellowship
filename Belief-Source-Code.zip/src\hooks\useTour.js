import { useState, useCallback, useRef } from 'react';

/**
 * Tour state machine hook.
 * Manages the 8-stop judge path through the app.
 */

export const TOUR_STOPS = [
  { id: 'opening', label: 'The problem', index: 0 },
  { id: 'objective', label: 'The objective', index: 1 },
  { id: 'home', label: 'Daily capture', index: 2 },
  { id: 'entry', label: 'An entry', index: 3 },
  { id: 'badday', label: 'Bad-day mode', index: 4 },
  { id: 'judge-turn', label: 'Your turn', index: 5 },
  { id: 'signals', label: 'How it knows', index: 6 },
  { id: 'whatitisnot', label: 'What it is not', index: 7 },
];

export function useTour() {
  const [isTourMode, setIsTourMode] = useState(false);
  const [currentStopIndex, setCurrentStopIndex] = useState(0);
  const [hasCompletedTour, setHasCompletedTour] = useState(false);

  const startTour = useCallback(() => {
    setIsTourMode(true);
    setCurrentStopIndex(0);
  }, []);

  const exitTour = useCallback(() => {
    setIsTourMode(false);
  }, []);

  const nextStop = useCallback(() => {
    setCurrentStopIndex((prev) => {
      const next = Math.min(prev + 1, TOUR_STOPS.length - 1);
      if (next === TOUR_STOPS.length - 1) {
        setHasCompletedTour(true);
      }
      return next;
    });
  }, []);

  const prevStop = useCallback(() => {
    setCurrentStopIndex((prev) => Math.max(prev - 1, 0));
  }, []);

  const goToStop = useCallback((index) => {
    if (index >= 0 && index < TOUR_STOPS.length) {
      setCurrentStopIndex(index);
    }
  }, []);

  const currentStop = TOUR_STOPS[currentStopIndex];
  const isFirstStop = currentStopIndex === 0;
  const isLastStop = currentStopIndex === TOUR_STOPS.length - 1;

  return {
    isTourMode,
    currentStop,
    currentStopIndex,
    isFirstStop,
    isLastStop,
    hasCompletedTour,
    startTour,
    exitTour,
    nextStop,
    prevStop,
    goToStop,
    totalStops: TOUR_STOPS.length,
  };
}
