import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { sampleEntries } from '../../data/sampleStudent';
import { useAudioRecorder } from '../../hooks/useAudioRecorder';
import { useTranscription } from '../../hooks/useTranscription';
import BearMascot from '../mascot/BearMascot';
import Balu from '../balu/Balu.jsx';
import WidgetPrompt from './WidgetPrompt.jsx';
import NotificationExplainer from '../notifications/NotificationExplainer';
import NotificationSettings from '../settings/NotificationSettings';
import { getAllEntries, getEntriesCount, saveEntry, getTimelineAnswers } from '../../services/db.js';
import { TIMELINE_QUESTIONS } from '../../data/timelineQuestions.js';
import { sendHeartbeat, transcribeAudio, analyzeEntry } from '../../services/api.js';
import { canShowNotificationExplainer } from '../../services/notifications.js';
import { verifyQuoteSubstring } from '../../utils/quotes.js';
import ScreenLayout from '../ScreenLayout.jsx';

const PROMPTS = [
  "What did you almost skip today but do anyway?",
  "What did you do today that nobody saw?",
  "What did you figure out today?",
  "What would Class 12 you have found scary about today?"
];

export default function RealHome({ isFirstLogin = false, isDemo = false, initialRecordReady = false, onOpenCrisis, onOpenTimeline }) {
  const [entries, setEntries] = useState([]);
  const [timelineAnswers, setTimelineAnswers] = useState([]);
  const [mode, setMode] = useState(initialRecordReady ? 'capture' : 'home');
  const [showBadDay, setShowBadDay] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showExplainer, setShowExplainer] = useState(false);
  const [promptIndex, setPromptIndex] = useState(0);
  const [moodTap, setMoodTap] = useState(null); // 'neutral' | 'low'
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const todaysPrompt = PROMPTS[promptIndex];

  useEffect(() => {
    async function load() {
      const stored = await getAllEntries();
      if (stored && stored.length > 0) {
        setEntries(stored.reverse()); // Latest first
      }
      try {
        const tAnswers = await getTimelineAnswers();
        if (tAnswers) {
          setTimelineAnswers(tAnswers);
        }
      } catch {
        // Ignore
      }
    }
    load();
  }, []);

  const {
    isRecording,
    duration,
    error: recorderError,
    startRecording,
    stopRecording
  } = useAudioRecorder();

  const {
    transcript,
    isSupported,
    startListening,
    stopListening,
    updateTranscript
  } = useTranscription();

  const handleNextPrompt = () => {
    setPromptIndex((prev) => (prev + 1) % PROMPTS.length);
  };

  const handleStartRecord = async () => {
    if (!isRecording) {
      setMode('capture');
      await startRecording();
      if (isSupported) startListening();
    } else {
      stopRecording(async (blob) => {
        if (blob && (!transcript || !transcript.trim())) {
          setIsTranscribing(true);
          const serverText = await transcribeAudio(blob);
          setIsTranscribing(false);
          if (serverText && serverText.trim()) {
            updateTranscript(serverText.trim());
          }
        }
      });
      if (isSupported) stopListening();
      setMode('transcript');
    }
  };

  const handleStopCapture = () => {
    stopRecording(async (blob) => {
      if (blob && (!transcript || !transcript.trim())) {
        setIsTranscribing(true);
        const serverText = await transcribeAudio(blob);
        setIsTranscribing(false);
        if (serverText && serverText.trim()) {
          updateTranscript(serverText.trim());
        }
      }
    });
    if (isSupported) stopListening();
    setMode('transcript');
  };

  const handleTypeInstead = () => {
    if (isRecording) {
      stopRecording();
      if (isSupported) stopListening();
    }
    setMode('typing');
    updateTranscript('');
  };

  const handleOneTap = () => {
    if (isRecording) {
      stopRecording();
      if (isSupported) stopListening();
    }
    updateTranscript('I showed up today.');
    setMode('transcript');
  };

  const handleSave = async () => {
    const textContent = transcript.trim();
    if (!textContent || isSaving) return; // double-fire prevention
    setIsSaving(true);

    try {
      const countBefore = await getEntriesCount();
      const newEntry = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        prompt: todaysPrompt,
        text: textContent,
        transcript: textContent,
        moodTap: moodTap || 'neutral',
        level: 0,
        evidence: [],
        smallThings: [],
      };

      // 1. Save entry to IndexedDB immediately
      await saveEntry(newEntry);

      // 2. Call /api/analyze and update entry with level, evidence, smallThings
      try {
        const analysis = await analyzeEntry(textContent, moodTap);
        newEntry.level = analysis.level ?? 0;
        newEntry.evidence = analysis.evidence || [];
        newEntry.smallThings = analysis.smallThings || [];
        await saveEntry(newEntry);

        // 3. Heartbeat with score only
        await sendHeartbeat(newEntry.date.split('T')[0], newEntry.level);

        // Crisis check: immediate route to /crisis
        if (analysis.crisis || analysis.level === 3) {
          setEntries((prev) => [newEntry, ...prev]);
          setMode('home');
          updateTranscript('');
          setMoodTap(null);
          setIsSaving(false);
          if (onOpenCrisis) {
            onOpenCrisis();
            return;
          }
        }
      } catch {
        // Offline fallback
        await sendHeartbeat(newEntry.date.split('T')[0], moodTap === 'low' ? 1 : 0);
      }

      setEntries((prev) => [newEntry, ...prev]);
      setMode('home');
      updateTranscript('');
      setMoodTap(null);

      // Trigger soft explainer only right after saving first real entry (never in demo)
      if (!isDemo && countBefore === 0) {
        const canShow = await canShowNotificationExplainer();
        if (canShow) {
          setShowExplainer(true);
        }
      }
    } finally {
      setIsSaving(false);
    }
  };

  /* ── BAD DAY MODE — Fact playback ── */
  if (showBadDay) {
    const sampleQuote = "I stayed up rewriting the entire assignment because I knew it wasn't my best work. Riya helped me debug the last part. That should count for something.";
    const hasValidQuote = verifyQuoteSubstring(sampleQuote, sampleEntries);

    const badDayHeader = (
      <button
        type="button"
        className="btn btn--ghost"
        onClick={() => setShowBadDay(false)}
        style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        <ArrowLeft size={16} strokeWidth={2} />
        <span>Back</span>
      </button>
    );

    const badDayFooter = (
      <button
        type="button"
        className="btn btn--primary btn--full"
        onClick={() => setShowBadDay(false)}
      >
        Close
      </button>
    );

    return (
      <ScreenLayout
        header={badDayHeader}
        footer={badDayFooter}
        bg="peach"
        className="badday-layout"
      >
        <div className="badday-mascot-area">
          <Balu pose="soft" size={72} noMotion={true} entrance="none" />
        </div>

        <div className="badday-conversation">
          <div className="badday-bubble">
            <p className="text-body" style={{ margin: 0 }}>
              Things have felt heavy. The app keeps facts, not verdicts.
            </p>
          </div>

          <div className="badday-bubble">
            <p className="text-body" style={{ margin: 0 }}>
              Here is what you said when you pushed through before:
            </p>
          </div>

          {hasValidQuote && (
            <div className="badday-quote-card">
              <div className="quote-tag">Your words, August 22nd</div>
              <p className="text-voice" style={{ margin: 0 }}>
                "{sampleQuote}"
              </p>
            </div>
          )}

          <div className="badday-bubble" style={{ borderLeft: '4px solid var(--color-leaf)' }}>
            <p className="text-body" style={{ color: 'var(--color-leaf)', margin: 0 }}>
              5 months, 3 setbacks, you got through all 3.
            </p>
          </div>
        </div>

        <style>{`
          .badday-mascot-area {
            display: flex;
            justify-content: center;
            margin: var(--space-2) 0 var(--space-4);
          }
          .badday-conversation {
            display: flex;
            flex-direction: column;
            gap: var(--space-3);
          }
          .badday-bubble {
            background: var(--color-cream);
            padding: var(--space-3);
            border-radius: var(--radius-card);
            border: 1px solid var(--color-sand);
          }
          .badday-quote-card {
            background: var(--color-ink);
            color: var(--color-cream);
            padding: var(--space-4);
            border-radius: var(--radius-card);
          }
          .quote-tag {
            font-size: var(--text-caption);
            color: var(--color-marigold);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
          }
        `}</style>
      </ScreenLayout>
    );
  }

  /* ── TRANSCRIPT / TYPING MODE ── */
  if (mode === 'transcript' || mode === 'typing') {
    const transcriptHeader = (
      <button
        type="button"
        className="btn btn--ghost"
        onClick={() => setMode('home')}
        style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        <ArrowLeft size={16} strokeWidth={2} />
        <span>Back</span>
      </button>
    );

    const transcriptFooter = (
      <button
        type="button"
        className="btn btn--primary btn--full"
        onClick={handleSave}
        disabled={!transcript.trim() || isSaving}
      >
        {isSaving ? 'Saving...' : 'Save to diary'}
      </button>
    );

    return (
      <ScreenLayout
        header={transcriptHeader}
        footer={transcriptFooter}
        bg="cream"
        className="transcript-layout"
      >
        <div className="transcript-content">
          <div className="transcript-top-info mb-3">
            <span className="text-caption" style={{ color: 'var(--color-stone)' }}>TODAY'S QUESTION</span>
            <h2 className="text-title mt-1" style={{ fontSize: '20px' }}>{todaysPrompt}</h2>
          </div>

          {isTranscribing && (
            <div className="mb-2 text-small" style={{ color: 'var(--color-stone)' }}>
              Transcribing audio...
            </div>
          )}

          <div className="transcript-card mb-4">
            <textarea
              className="transcript-textarea"
              value={transcript}
              onChange={(e) => updateTranscript(e.target.value)}
              placeholder={mode === 'typing' ? 'Write what happened today...' : 'Your words will appear here...'}
              autoFocus={mode === 'typing'}
            />
          </div>

          <div className="mood-tap-section mb-2">
            <span className="text-caption" style={{ color: 'var(--color-stone)', display: 'block', marginBottom: '8px' }}>
              HOW DID TODAY FEEL? (OPTIONAL)
            </span>
            <div className="mood-chips">
              <button
                type="button"
                className={`mood-chip ${moodTap === 'neutral' ? 'active' : ''}`}
                onClick={() => setMoodTap(moodTap === 'neutral' ? null : 'neutral')}
              >
                Ordinary
              </button>
              <button
                type="button"
                className={`mood-chip ${moodTap === 'low' ? 'active' : ''}`}
                onClick={() => setMoodTap(moodTap === 'low' ? null : 'low')}
              >
                Felt heavy
              </button>
            </div>
          </div>
        </div>

        <style>{`
          .transcript-content {
            display: flex;
            flex-direction: column;
            width: 100%;
          }
          .transcript-card {
            background: var(--color-beige);
            border: 1px solid var(--color-sand);
            border-radius: var(--radius-card);
            padding: var(--space-3);
            display: flex;
            flex-direction: column;
            min-height: 200px;
          }
          .transcript-textarea {
            width: 100%;
            height: 180px;
            background: transparent;
            border: none;
            resize: none;
            font-family: var(--font-serif);
            font-size: 18px;
            line-height: 1.6;
            color: var(--color-ink);
            outline: none;
          }
          .mood-chips {
            display: flex;
            gap: 8px;
          }
          .mood-chip {
            padding: 8px 16px;
            border-radius: var(--radius-pill);
            border: 1px solid var(--color-sand);
            background: var(--color-cream);
            color: var(--color-ink);
            font-family: var(--font-sans);
            font-size: var(--text-small);
            cursor: pointer;
          }
          .mood-chip.active {
            background: var(--color-beige);
            border-color: var(--color-ink);
            font-weight: 600;
          }
        `}</style>
      </ScreenLayout>
    );
  }

  /* ── CAPTURE MODE ── */
  if (mode === 'capture') {
    const captureHeader = (
      <button
        type="button"
        className="btn btn--ghost"
        onClick={() => setMode('home')}
        style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        <ArrowLeft size={16} strokeWidth={2} />
        <span>Back</span>
      </button>
    );

    const captureFooter = (
      <div className="capture-alternatives">
        <button type="button" className="alt-option" onClick={handleTypeInstead}>
          <span className="alt-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
          </span>
          <span>Type instead</span>
        </button>
        <button type="button" className="alt-option" onClick={handleOneTap}>
          <span className="alt-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22v-5"/><path d="M9 7V2"/><path d="M15 7V2"/><path d="M12 7V2"/><path d="M5 21a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2Z"/></svg>
          </span>
          <span>I showed up today</span>
        </button>
      </div>
    );

    return (
      <ScreenLayout
        header={captureHeader}
        footer={captureFooter}
        bg="cream"
        className="capture-layout"
      >
        <div className="capture-content">
          <div className="capture-top-info">
            <span className="text-caption" style={{ color: 'var(--color-stone)' }}>TODAY'S QUESTION</span>
            <h1 className="text-headline mt-2 text-center" style={{ fontSize: '24px' }}>{todaysPrompt}</h1>
          </div>

          <div className="capture-center my-auto py-6">
            <button
              type="button"
              className={`record-btn-large ${isRecording ? 'is-recording' : ''}`}
              onClick={isRecording ? handleStopCapture : handleStartRecord}
              aria-label={isRecording ? 'Stop recording' : 'Start recording'}
            >
              {isRecording ? (
                <div className="record-square" />
              ) : (
                <svg viewBox="0 0 24 24" fill="var(--color-ink)" width="36" height="36">
                  <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
                </svg>
              )}
            </button>

            <div className="text-caption mt-4" style={{ color: 'var(--color-stone)' }}>
              {isRecording ? 'Listening · 30 seconds is enough' : 'Tap to speak · 30 seconds is enough'}
            </div>

            {recorderError && (
              <div className="text-caption mt-2" style={{ color: 'var(--color-stone)' }}>
                Microphone unavailable. You can type or tap below.
              </div>
            )}
          </div>
        </div>

        <style>{`
          .capture-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            min-height: 100%;
          }
          .capture-top-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
          }
          .capture-center {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          }
          .record-btn-large {
            width: 96px;
            height: 96px;
            border-radius: 50%;
            background: var(--color-marigold);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: transform 0.15s ease;
          }
          .record-btn-large:active {
            transform: scale(0.95);
          }
          .record-btn-large.is-recording {
            animation: recordPulse 2s infinite ease-in-out;
          }
          @keyframes recordPulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.06); }
            100% { transform: scale(1); }
          }
          .record-square {
            width: 28px;
            height: 28px;
            background: var(--color-ink);
            border-radius: 4px;
          }
          .capture-alternatives {
            display: flex;
            gap: 12px;
            width: 100%;
          }
          .alt-option {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px;
            background: var(--color-beige);
            border: 1px solid var(--color-sand);
            border-radius: var(--radius-pill);
            color: var(--color-ink);
            font-family: var(--font-sans);
            font-size: var(--text-small);
            cursor: pointer;
          }
          .alt-icon {
            display: flex;
            align-items: center;
          }
        `}</style>
      </ScreenLayout>
    );
  }

  if (showSettings) {
    return <NotificationSettings onBack={() => setShowSettings(false)} />;
  }

  /* ── HOME MODE — Factual, quiet paper diary layout ── */
  const totalEntries = entries.length;
  const allEntries = entries.length > 0 ? entries : (isDemo ? sampleEntries.slice(0, 3) : []);

  // Timeline progress computation
  const totalTimelineQuestions = TIMELINE_QUESTIONS.length;
  const answeredQuestions = TIMELINE_QUESTIONS.filter((q) => {
    const a = timelineAnswers.find((item) => item.id === q.id);
    return a && (a.text?.trim() || a.skipped);
  });
  const answeredTimelineCount = answeredQuestions.length;

  let timelineCardTitle = 'Build your timeline';
  let timelineCardDesc = 'Add a few moments from your past in your own words.';
  let handleTimelineClick = () => onOpenTimeline?.({ mode: 'builder', resumeIndex: 0 });

  if (answeredTimelineCount > 0 && answeredTimelineCount < totalTimelineQuestions) {
    timelineCardTitle = 'Complete your timeline';
    timelineCardDesc = 'Pick up where you left off whenever you are ready.';
    const firstUnansweredIndex = TIMELINE_QUESTIONS.findIndex(
      (q) => !timelineAnswers.some((a) => a.id === q.id && (a.text?.trim() || a.skipped))
    );
    handleTimelineClick = () =>
      onOpenTimeline?.({
        mode: 'builder',
        resumeIndex: firstUnansweredIndex !== -1 ? firstUnansweredIndex : 0,
      });
  } else if (answeredTimelineCount >= totalTimelineQuestions) {
    timelineCardTitle = 'Your timeline';
    timelineCardDesc = 'Your foundation and moments of progress.';
    handleTimelineClick = () => onOpenTimeline?.({ mode: 'view' });
  }

  const homeHeader = (
    <div className="home-topbar">
      <div className="topbar-left">
        <img
          src="/logo.jpg"
          alt="Belief"
          className="topbar-logo"
          width="32"
          height="32"
        />
        <span className="topbar-brand">Belief</span>
      </div>
      <div className="topbar-right">
        <button
          type="button"
          className="topbar-icon-btn"
          title="Settings"
          onClick={() => setShowSettings(true)}
          aria-label="Settings"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        </button>
      </div>
    </div>
  );

  return (
    <ScreenLayout
      header={homeHeader}
      bg="cream"
      className="home-screen-layout"
    >
      {showExplainer && (
        <NotificationExplainer onDone={() => setShowExplainer(false)} />
      )}

      {/* Fact Line Card */}
      <div className="card mb-3 p-4">
        <p className="text-small" style={{ color: 'var(--color-stone)', margin: 0 }}>
          {totalEntries > 0
            ? `${totalEntries} recorded moments in your own words.`
            : 'One small question a day. Your words, saved for when you need them.'}
        </p>
      </div>

      {/* Gentle Timeline Card (always available, gentle, no badges, no percentages, no red) */}
      <button
        type="button"
        className="timeline-home-card card mb-3 text-left w-full"
        onClick={handleTimelineClick}
        aria-label={timelineCardTitle}
      >
        <div className="timeline-card-inner">
          <div className="timeline-card-content">
            <span className="timeline-card-title">{timelineCardTitle}</span>
            <span className="timeline-card-desc">{timelineCardDesc}</span>
          </div>
          <ArrowRight size={18} strokeWidth={2} className="timeline-card-arrow" />
        </div>
        {answeredTimelineCount > 0 && (
          <div className="timeline-card-track mt-2">
            <div
              className="timeline-card-progress"
              style={{ width: `${(answeredTimelineCount / totalTimelineQuestions) * 100}%` }}
            />
          </div>
        )}
      </button>

      {/* Today's Prompt Card */}
      <div className="prompt-card mb-3">
        <div className="prompt-label">
          <span className="text-caption">TODAY'S QUESTION</span>
          <button
            type="button"
            className="prompt-shuffle"
            onClick={handleNextPrompt}
            aria-label="Next prompt"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>
          </button>
        </div>
        <h2 className="text-title mt-2 mb-4">{todaysPrompt}</h2>
        <div className="prompt-actions">
          <button type="button" className="record-btn-mini" onClick={handleStartRecord}>
            <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
              <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
            </svg>
            <span>Record</span>
          </button>
          <button type="button" className="type-btn-mini" onClick={handleTypeInstead}>
            Type
          </button>
          <button type="button" className="tap-btn-mini" onClick={handleOneTap}>
            Tap
          </button>
        </div>
      </div>

      {/* Quick Stats Row */}
      <div className="quick-stats mb-3">
        <div className="qstat">
          <div className="qstat-value">{totalEntries}</div>
          <div className="qstat-label">Entries</div>
        </div>
        <div className="qstat-divider" />
        <div className="qstat">
          <div className="qstat-value">{totalEntries > 0 ? totalEntries : (isDemo ? 12 : 0)}</div>
          <div className="qstat-label">Small Wins</div>
        </div>
        <div className="qstat-divider" />
        <div className="qstat">
          <div className="qstat-value">{isDemo ? 4 : (totalEntries > 3 ? 1 : 0)}</div>
          <div className="qstat-label">Setbacks Faced</div>
        </div>
      </div>

      {/* Bad Day Button */}
      <button
        type="button"
        className="rough-day-btn mb-4"
        onClick={() => setShowBadDay(true)}
      >
        <div className="rough-day-icon">
          <Balu pose="soft" size={36} noMotion={true} entrance="none" />
        </div>
        <div className="rough-day-text">
          <span className="text-small" style={{ fontWeight: 600 }}>Having a rough day?</span>
          <span className="text-caption">Balu will remind you of what you've already done.</span>
        </div>
        <ArrowRight size={18} className="rough-day-arrow" />
      </button>

      {/* Add Widget / Keep Me Close Option */}
      <WidgetPrompt todaysPrompt={todaysPrompt} />

      {/* Past Entries */}
      <div className="entries-section pb-4">
        <h3 className="text-small mb-3" style={{ fontWeight: 600, opacity: 0.7 }}>Your Journey</h3>
        {allEntries.length === 0 ? (
          <div className="empty-entries">
            <Balu pose="surprised" entrance="pop" size={64} />
            <p className="text-small mt-3" style={{ color: 'var(--color-stone)' }}>
              No entries yet. Tap the record button above to start building your timeline.
            </p>
          </div>
        ) : (
          <div className="entry-list">
            {allEntries.map((entry) => (
              <div key={entry.id} className="entry-card-new">
                <div className="entry-meta">
                  <span className="entry-date">
                    {new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                  {entry.isSample && <span className="sample-badge">Sample</span>}
                </div>
                <p className="entry-snippet">"{entry.text || entry.transcript}"</p>
                {entry.smallThings && entry.smallThings.length > 0 && (
                  <div className="entry-tags">
                    {entry.smallThings.map((thing, i) => (
                      <span key={i} className="entry-tag">{thing}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <style>{`
        .home-topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
          padding: 8px 0;
        }
        .topbar-left {
          display: flex;
          align-items: center;
          gap: 10px;
        }
        .topbar-logo {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          object-fit: cover;
          display: block;
        }
        .topbar-brand {
          font-family: var(--font-serif);
          font-size: 1.2rem;
          font-weight: 500;
          letter-spacing: -0.02em;
        }
        .topbar-right {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .topbar-icon-btn {
          font-size: 1.1rem;
          opacity: 0.6;
          cursor: pointer;
          border: none;
          background: none;
          padding: 4px;
        }
        .prompt-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: var(--space-3);
        }
        .prompt-label {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .prompt-shuffle {
          width: 32px;
          height: 32px;
          border-radius: 50%;
          border: 1px solid var(--color-sand);
          background: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .prompt-actions {
          display: flex;
          gap: 8px;
        }
        .record-btn-mini {
          flex: 2;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          min-height: 48px;
          background: var(--color-marigold);
          color: var(--color-ink);
          border: none;
          border-radius: var(--radius-pill);
          font-family: var(--font-sans);
          font-size: var(--text-small);
          font-weight: 600;
          cursor: pointer;
        }
        .type-btn-mini, .tap-btn-mini {
          flex: 1;
          min-height: 48px;
          background: var(--color-cream);
          color: var(--color-ink);
          border: 1px solid var(--color-ink);
          border-radius: var(--radius-pill);
          font-family: var(--font-sans);
          font-size: var(--text-caption);
          font-weight: 600;
          cursor: pointer;
        }
        .quick-stats {
          display: flex;
          align-items: center;
          background: var(--color-beige);
          border-radius: var(--radius-card);
          padding: var(--space-3);
          border: 1px solid var(--color-sand);
        }
        .qstat {
          flex: 1;
          text-align: center;
        }
        .qstat-value {
          font-family: var(--font-serif);
          font-size: 1.4rem;
          font-weight: 600;
          color: var(--color-ink);
          line-height: 1;
        }
        .qstat-label {
          font-size: 11px;
          color: var(--color-stone);
          margin-top: 4px;
          font-weight: 500;
        }
        .qstat-divider {
          width: 1px;
          height: 32px;
          background: var(--color-sand);
        }
        .rough-day-btn {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          padding: var(--space-3);
          background: var(--color-peach);
          border-radius: var(--radius-card);
          border: 1px solid var(--color-sand);
          cursor: pointer;
          text-align: left;
          font-family: var(--font-sans);
          width: 100%;
        }
        .rough-day-text {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 2px;
        }
        .rough-day-arrow {
          font-size: 1.2rem;
          color: var(--color-stone);
        }
        .entry-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
        }
        .entry-card-new {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: var(--space-3);
        }
        .entry-meta {
          display: flex;
          align-items: center;
          gap: 8px;
          margin-bottom: 6px;
        }
        .entry-date {
          font-size: var(--text-caption);
          font-weight: 600;
          color: var(--color-stone);
          text-transform: uppercase;
          letter-spacing: 0.05em;
        }
        .sample-badge {
          font-size: 10px;
          padding: 2px 8px;
          background: var(--color-sand);
          border-radius: var(--radius-pill);
          color: var(--color-stone);
          font-weight: 600;
        }
        .entry-snippet {
          font-family: var(--font-serif);
          font-size: var(--text-small);
          line-height: 1.5;
          color: var(--color-ink);
        }
        .entry-tags {
          display: flex;
          gap: 6px;
          margin-top: 8px;
          flex-wrap: wrap;
        }
        .entry-tag {
          font-size: 11px;
          padding: 3px 10px;
          background: rgba(47,107,79,0.08);
          color: var(--color-leaf);
          border-radius: var(--radius-pill);
          font-weight: 500;
        }
        .empty-entries {
          display: flex;
          flex-direction: column;
          align-items: center;
          padding: var(--space-6) var(--space-4);
          text-align: center;
        }
        .timeline-home-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 16px;
          cursor: pointer;
          width: 100%;
          display: flex;
          flex-direction: column;
          text-align: left;
          box-sizing: border-box;
          transition: border-color 0.15s ease;
        }
        .timeline-home-card:hover {
          border-color: var(--color-ink);
        }
        .timeline-card-inner {
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
        }
        .timeline-card-content {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }
        .timeline-card-title {
          font-family: var(--font-sans);
          font-size: var(--text-body);
          font-weight: 600;
          color: var(--color-ink);
        }
        .timeline-card-desc {
          font-family: var(--font-sans);
          font-size: var(--text-small);
          color: var(--color-stone);
          line-height: 1.3;
        }
        .timeline-card-arrow {
          color: var(--color-stone);
          flex-shrink: 0;
          margin-left: 8px;
        }
        .timeline-card-track {
          width: 100%;
          height: 3px;
          background: var(--color-sand);
          border-radius: 2px;
          overflow: hidden;
        }
        .timeline-card-progress {
          height: 100%;
          background: var(--color-marigold);
          border-radius: 2px;
        }
      `}</style>
    </ScreenLayout>
  );
}
