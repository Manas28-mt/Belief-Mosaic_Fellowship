# Testing & QA Checklist

This document details the complete end-to-end testing and verification checklist for Belief.

---

## 1. Platform & Device Verification
- [ ] **Android Chrome**: App opens cleanly, audio recording functions, PWA install prompt works.
- [ ] **iPhone (iOS Safari)**:
  - Non-standalone mode presents the 3-step "Add to Home Screen" explainer.
  - Installed standalone PWA correctly opens and handles web push permissions.
- [ ] **Laptop Chrome**: Desktop responsive layout, audio capture via MediaRecorder, clean paper diary aesthetic.
- [ ] **Laptop Safari**: Audio recording and typography render accurately.

---

## 2. Notification Routing (Deep Linking)
Ensure that tapping a notification with the app fully closed launches and routes to the exact intended destination:
- [ ] `type="record"`: Opens `/?open=record` -> routes to Home screen with audio recorder ready. Query parameter is removed cleanly from URL.
- [ ] `type="playback"`: Opens `/?open=playback` -> routes directly to Bad-Day Mode.
- [ ] `type="checkin"`: Opens `/?open=checkin` -> routes directly to Silence Check-in screen.
- [ ] `type="balu"`: Opens `/?open=balu` -> routes directly to Balu screen with `<ReachSomeone />` on closing.

---

## 3. Graceful Fallbacks & Offline Operation
- [ ] **Microphone Permission Refused**:
  - Clear, empathetic message in Stone: "Microphone unavailable. You can type or tap below."
  - "Type instead" and "I showed up today" one-tap options remain 100% functional.
- [ ] **Offline Save**:
  - Entries saved to local IndexedDB.
  - Heartbeat and analysis are queued or run locally without crashes.

---

## 4. Pattern Ladder & Notification Triggers
Verify each pattern ladder branch fires correctly and strictly obeys cooldowns:
- [ ] **Hard Date**: Fires at or after 19:00 local time when date is in `hard_dates` and last playback cooldown > 7 days.
- [ ] **Silence Check-in (Ordinary)**: Fires after 3 silent days for regular users (>= 4 entries in past 14 days) if no check-in sent since last entry.
- [ ] **Silence Check-in (Post-Heavy)**: Fires after 2 silent days if any entry had score >= 1 in the 5 days prior to last entry.
- [ ] **Balu Invite**: Fires when 3 heavy days (score >= 1) or 2 concerning days (score >= 2) occur in 5-day window, and Balu invite cooldown > 3 days.
- [ ] **Heavy Day Playback**: Fires when yesterday had score >= 1 and playback cooldown > 7 days.
- [ ] **Nightly Prompt**: Rotates prompt by day-of-year at user's prompt time (default 21:00); respects reduced frequency on even days.
- [ ] **Max One Push Per Day**: If `last_notification_date == local today`, no push is sent under any circumstances.

---

## 5. Crisis Safety & Confidentiality
- [ ] **Crisis in Diary Entry**:
  - Any explicit suicide/self-harm phrase immediately sets `level=3` and `crisis=true`.
  - App navigates directly to `/crisis` immediately upon save.
  - Zero LLM text on `/crisis` (100% static, Tele-MANAS 14416 button, counselling cell).
- [ ] **Crisis in Balu Session**:
  - `checkCrisis` runs BEFORE any call to the LLM.
  - If triggered, server returns `{ crisis: true }` without invoking LLM. Server logs increment crisis count only.
  - Client navigates directly to `/crisis`.

---

## 6. Judge Walkthrough Path (Sub-2-Minute Requirement)
- [ ] Opening Screens -> Objective Screen ("See it with a sample student") -> Visual Story -> Bad-Day Mode.
- [ ] Completed in under 2 minutes.
- [ ] Zero sign-up, login, or notification permission popups before reaching bad-day mode.
- [ ] All sample student screens clearly display the "Sample" tag.

---

## 7. Automated Test Suites & Evaluations
- [ ] Unit tests pass:
  ```bash
  npm run test
  ```
- [ ] Safety evaluation harness passes 100% of explicit crisis cases:
  ```bash
  npm run eval
  ```
- [ ] Production build succeeds with zero errors:
  ```bash
  npm run build
  ```
