/**
 * Exact-substring quote verification per RULES.md:
 * "Any quote shown on screen must be an exact substring of a stored transcript.
 * Check in code before rendering. If the check fails, don't show it."
 */
export function verifyQuoteSubstring(quote, transcripts) {
  if (!quote || typeof quote !== 'string' || !quote.trim()) return false;
  if (!transcripts) return false;

  const target = quote.trim();
  const list = Array.isArray(transcripts) ? transcripts : [transcripts];

  for (const item of list) {
    if (!item) continue;
    const text = typeof item === 'string' ? item : (item.text || item.transcript || '');
    if (text.includes(target)) {
      return true;
    }
  }

  return false;
}
