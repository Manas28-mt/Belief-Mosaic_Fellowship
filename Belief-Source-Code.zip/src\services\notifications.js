import { getSetting, setSetting } from './db.js';
import { subscribePush, unsubscribePush } from './api.js';
import { NUMBERS } from '../config/numbers.js';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export async function canShowNotificationExplainer() {
  if (typeof window === 'undefined' || !('Notification' in window)) return false;
  if (Notification.permission === 'granted') return false;

  const dismissedAt = await getSetting('notificationExplainerDismissedAt');
  if (dismissedAt) {
    const elapsedDays = (Date.now() - new Date(dismissedAt).getTime()) / (1000 * 60 * 60 * 24);
    if (elapsedDays < NUMBERS.REASK_EXPLAINER_DAYS) {
      return false;
    }
  }

  return true;
}

export async function dismissNotificationExplainer() {
  await setSetting('notificationExplainerDismissedAt', new Date().toISOString());
}

export async function requestAndSubscribePush() {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return { success: false, reason: 'unsupported' };
  }

  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    await dismissNotificationExplainer();
    return { success: false, permission };
  }

  try {
    const registration = await navigator.serviceWorker.ready;
    const vapidKey = import.meta.env.VITE_VAPID_PUBLIC_KEY;

    let subscription;
    if (vapidKey) {
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidKey),
      });
    } else {
      // Mock subscription for local testing if VITE_VAPID_PUBLIC_KEY is not yet populated
      subscription = {
        endpoint: 'mock-endpoint-' + Math.random().toString(36).substring(2, 9),
        keys: { p256dh: 'mock-p256dh', auth: 'mock-auth' },
      };
    }

    await subscribePush(subscription);
    await setSetting('pushSubscribed', true);
    return { success: true, subscription };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

export async function disablePushNotifications() {
  try {
    if ('serviceWorker' in navigator) {
      const registration = await navigator.serviceWorker.ready;
      const sub = await registration.pushManager.getSubscription();
      if (sub) {
        await unsubscribePush(sub.endpoint);
        await sub.unsubscribe();
      }
    }
    await setSetting('pushSubscribed', false);
    return true;
  } catch {
    return false;
  }
}
