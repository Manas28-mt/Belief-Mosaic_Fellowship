import { useState, useCallback, useRef, useEffect } from 'react';

/**
 * Audio recorder hook.
 * Uses MediaRecorder API to capture voice.
 * Returns the audio blob when recording stops.
 */
export function useAudioRecorder() {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState(null);
  const [error, setError] = useState(null);
  const [duration, setDuration] = useState(0);
  const mediaRecorder = useRef(null);
  const chunks = useRef([]);
  const timerRef = useRef(null);
  const startTimeRef = useRef(null);

  const onStopCallbackRef = useRef(null);

  const startRecording = useCallback(async (onStopCallback) => {
    try {
      setError(null);
      setAudioBlob(null);
      setDuration(0);
      chunks.current = [];
      onStopCallbackRef.current = onStopCallback || null;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Pick a supported MIME type
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : 'audio/mp4';

      const recorder = new MediaRecorder(stream, { mimeType });
      mediaRecorder.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks.current, { type: mimeType });
        setAudioBlob(blob);
        // Stop all tracks to release the mic
        stream.getTracks().forEach((track) => track.stop());
        clearInterval(timerRef.current);
        if (onStopCallbackRef.current) {
          onStopCallbackRef.current(blob);
        }
      };

      recorder.onerror = () => {
        setError('Recording failed. Try typing instead.');
        stream.getTracks().forEach((track) => track.stop());
        clearInterval(timerRef.current);
      };

      recorder.start(1000); // collect data every 1s
      setIsRecording(true);
      startTimeRef.current = Date.now();

      // Duration counter
      timerRef.current = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setDuration(elapsed);
        // Soft stop near 90 seconds
        if (elapsed >= 90 && mediaRecorder.current && mediaRecorder.current.state === 'recording') {
          mediaRecorder.current.stop();
          setIsRecording(false);
        }
      }, 1000);
    } catch (err) {
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('microphone-denied');
      } else {
        setError('Could not access microphone. Try typing instead.');
      }
    }
  }, []);

  const stopRecording = useCallback((onStopCallback) => {
    if (onStopCallback) {
      onStopCallbackRef.current = onStopCallback;
    }
    if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
      mediaRecorder.current.stop();
      setIsRecording(false);
    }
  }, []);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (mediaRecorder.current && mediaRecorder.current.state !== 'inactive') {
        mediaRecorder.current.stop();
      }
      clearInterval(timerRef.current);
    };
  }, []);

  return {
    isRecording,
    audioBlob,
    duration,
    error,
    startRecording,
    stopRecording,
  };
}
