import React, { useState } from 'react';
import { Settings, X, Play } from 'lucide-react';
import { decide } from '../../../server/lib/scheduler.js';

export default function DevPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedPattern, setSelectedPattern] = useState('all_ordinary');
  const [mockUser, setMockUser] = useState(null);
  const [decisionResult, setDecisionResult] = useState(null);
  const [testPushStatus, setTestPushStatus] = useState('');

  if (!import.meta.env.DEV) {
    return null;
  }

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  const getPastDateStr = (daysAgo) => {
    const d = new Date(today.getTime() - daysAgo * 86400000);
    return d.toISOString().split('T')[0];
  };

  const patterns = {
    all_ordinary: {
      name: 'All Ordinary',
      desc: '14 days with score 0, regular user',
      createUser: () => {
        const scores = {};
        for (let i = 1; i <= 14; i++) scores[getPastDateStr(i)] = 0;
        return {
          id: 'dev_user',
          prompt_time: '21:00',
          last_entry_at: getPastDateStr(1) + 'T21:00:00Z',
          day_scores: scores,
          hard_dates: [],
        };
      },
    },
    one_heavy_yesterday: {
      name: 'One Heavy Yesterday',
      desc: 'Yesterday score 1, cooldown clear',
      createUser: () => {
        const scores = {};
        for (let i = 2; i <= 14; i++) scores[getPastDateStr(i)] = 0;
        scores[getPastDateStr(1)] = 1;
        return {
          id: 'dev_user',
          prompt_time: '21:00',
          last_entry_at: getPastDateStr(1) + 'T21:00:00Z',
          last_playback_sent_at: getPastDateStr(10) + 'T12:00:00Z',
          day_scores: scores,
          hard_dates: [],
        };
      },
    },
    three_heavy_in_five: {
      name: '3 Heavy in 5 Days',
      desc: 'Pattern ladder trigger: scores >= 1 on 3 of last 5 days',
      createUser: () => {
        const scores = {};
        scores[getPastDateStr(0)] = 1;
        scores[getPastDateStr(1)] = 1;
        scores[getPastDateStr(2)] = 1;
        return {
          id: 'dev_user',
          prompt_time: '21:00',
          last_entry_at: getPastDateStr(0) + 'T20:00:00Z',
          last_balu_invite_at: getPastDateStr(8) + 'T12:00:00Z',
          day_scores: scores,
          hard_dates: [],
        };
      },
    },
    heavy_then_two_silent: {
      name: 'Heavy Then 2 Days Silent',
      desc: 'Score 1 two days ago, no entries since (silence check-in)',
      createUser: () => {
        const scores = {};
        for (let i = 3; i <= 10; i++) scores[getPastDateStr(i)] = 0;
        scores[getPastDateStr(2)] = 1;
        return {
          id: 'dev_user',
          prompt_time: '21:00',
          last_entry_at: getPastDateStr(2) + 'T12:00:00Z',
          day_scores: scores,
          hard_dates: [],
        };
      },
    },
    hard_date_today: {
      name: 'Hard Date Today',
      desc: 'Today in hard_dates, hour >= 19',
      createUser: () => ({
        id: 'dev_user',
        prompt_time: '21:00',
        hard_dates: [todayStr],
        last_playback_sent_at: getPastDateStr(12) + 'T12:00:00Z',
        day_scores: {},
      }),
    },
  };

  const handleLoadPattern = (key) => {
    setSelectedPattern(key);
    const u = patterns[key].createUser();
    setMockUser(u);

    // Evaluate with decide() simulating evening time 21:30
    const evalTime = new Date();
    evalTime.setHours(21, 30, 0, 0);
    const result = decide(u, evalTime);
    setDecisionResult(result);
  };

  const handleSendTestPush = async () => {
    setTestPushStatus('Requesting...');
    if (!('Notification' in window)) {
      setTestPushStatus('Notifications not supported');
      return;
    }

    if (Notification.permission !== 'granted') {
      const res = await Notification.requestPermission();
      if (res !== 'granted') {
        setTestPushStatus('Permission denied');
        return;
      }
    }

    if (navigator.serviceWorker && navigator.serviceWorker.ready) {
      const reg = await navigator.serviceWorker.ready;
      reg.showNotification('Belief', {
        body: 'Something from your diary is waiting.',
        icon: '/icon-192.png',
        tag: 'test',
      });
      setTestPushStatus('Test notification sent!');
    } else {
      new Notification('Belief', {
        body: 'Something from your diary is waiting.',
        icon: '/icon-192.png',
      });
      setTestPushStatus('Test notification sent!');
    }
  };

  return (
    <>
      <button
        className="dev-panel-toggle"
        onClick={() => setIsOpen(!isOpen)}
        title="Developer Panel"
        style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
      >
        <Settings size={14} strokeWidth={2} />
        <span>Dev</span>
      </button>

      {isOpen && (
        <div className="dev-panel-modal">
          <div className="dev-panel-header">
            <span className="dev-panel-title">Developer Tools (DEV only)</span>
            <button className="dev-panel-close" onClick={() => setIsOpen(false)} aria-label="Close">
              <X size={16} strokeWidth={2} />
            </button>
          </div>

          <div className="dev-panel-section">
            <button
              className="btn btn--secondary btn--full mb-3"
              onClick={() => {
                window.location.pathname = '/dev/balu';
              }}
              style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', minHeight: '44px' }}
            >
              <Play size={14} />
              <span>Open Balu Playground (/dev/balu)</span>
            </button>
          </div>

          <div className="dev-panel-section">
            <span className="dev-section-label">14-Day Simulation Patterns</span>
            <div className="dev-pattern-grid">
              {Object.entries(patterns).map(([key, item]) => (
                <button
                  key={key}
                  className={`dev-pattern-btn ${selectedPattern === key ? 'active' : ''}`}
                  onClick={() => handleLoadPattern(key)}
                >
                  {item.name}
                </button>
              ))}
            </div>
          </div>

          {mockUser && (
            <div className="dev-panel-section">
              <span className="dev-section-label">Decide() Output (evaluated at 21:30)</span>
              <div className="dev-result-box">
                {decisionResult ? (
                  <>
                    <div className="dev-result-type">Type: <strong>{decisionResult.type}</strong></div>
                    <div className="dev-result-text">Text: "{decisionResult.text}"</div>
                  </>
                ) : (
                  <div className="dev-result-none">No notification fired (conditions not met or cooldown active).</div>
                )}
              </div>
            </div>
          )}

          <div className="dev-panel-section">
            <span className="dev-section-label">Push Notification Testing</span>
            <button className="btn btn--primary btn--full" onClick={handleSendTestPush}>
              Send test push to me
            </button>
            {testPushStatus && <div className="text-caption mt-1 text-center">{testPushStatus}</div>}
          </div>

          <style>{`
            .dev-panel-toggle {
              position: fixed;
              bottom: 12px;
              right: 12px;
              z-index: 999;
              padding: 6px 12px;
              background: var(--color-ink);
              color: var(--color-cream);
              border-radius: var(--radius-pill);
              border: none;
              font-size: 12px;
              font-family: var(--font-sans);
              cursor: pointer;
              opacity: 0.75;
            }
            .dev-panel-modal {
              position: fixed;
              bottom: 48px;
              right: 12px;
              width: 320px;
              max-height: 480px;
              background: var(--color-cream);
              border: 1px solid var(--color-sand);
              border-radius: var(--radius-card);
              padding: var(--space-3);
              z-index: 1000;
              overflow-y: auto;
              font-family: var(--font-sans);
              box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            }
            .dev-panel-header {
              display: flex;
              justify-content: space-between;
              align-items: center;
              margin-bottom: var(--space-3);
              border-bottom: 1px solid var(--color-sand);
              padding-bottom: 6px;
            }
            .dev-panel-title {
              font-size: 13px;
              font-weight: 700;
              color: var(--color-ink);
            }
            .dev-panel-close {
              background: none;
              border: none;
              cursor: pointer;
              font-size: 14px;
            }
            .dev-panel-section {
              margin-bottom: var(--space-3);
            }
            .dev-section-label {
              font-size: 11px;
              text-transform: uppercase;
              color: var(--color-stone);
              font-weight: 600;
              display: block;
              margin-bottom: 6px;
            }
            .dev-pattern-grid {
              display: flex;
              flex-direction: column;
              gap: 4px;
            }
            .dev-pattern-btn {
              padding: 6px 10px;
              font-size: 12px;
              background: var(--color-beige);
              border: 1px solid var(--color-sand);
              border-radius: 6px;
              cursor: pointer;
              text-align: left;
            }
            .dev-pattern-btn.active {
              border-color: var(--color-marigold);
              font-weight: 600;
            }
            .dev-result-box {
              background: var(--color-beige);
              border: 1px solid var(--color-sand);
              border-radius: 6px;
              padding: 8px;
              font-size: 12px;
            }
            .dev-result-type {
              margin-bottom: 4px;
            }
          `}</style>
        </div>
      )}
    </>
  );
}
