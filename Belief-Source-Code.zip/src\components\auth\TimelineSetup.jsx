import React, { useState } from 'react';
import Balu from '../balu/Balu.jsx';
import { saveTrustedContact } from '../../services/db.js';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Onboarding setup flow.
 * Per Phase 7: Includes optional, skippable card:
 * "Who's one person you'd call on a bad day?"
 * Stored in IndexedDB only and never sent to the server.
 * 
 * Uses unified ScreenLayout:
 * - Body is the scroll area.
 * - Action buttons live strictly in pinned footer slot.
 * - Double-fire protection on all buttons.
 */
export default function TimelineSetup({ onComplete }) {
  const [step, setStep] = useState(0); // 0: intro question, 1: trusted person card
  const [personName, setPersonName] = useState('');
  const [personNumber, setPersonNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSaveContact = async () => {
    if (isSubmitting) return; // double-fire prevention
    setIsSubmitting(true);

    try {
      if (personName.trim()) {
        await saveTrustedContact({
          name: personName.trim(),
          phone: personNumber.trim(),
        });
      }
    } catch {
      // Ignore DB errors
    }
    onComplete();
  };

  const handleSkipContact = () => {
    if (isSubmitting) return; // double-fire prevention
    setIsSubmitting(true);
    onComplete();
  };

  const headerContent = (
    <div className="setup-voice-top">
      <Balu pose="listen" entrance="pop" size={80} />
    </div>
  );

  const footerContent = step === 0 ? (
    <button
      type="button"
      className="btn btn--primary btn--full"
      onClick={() => setStep(1)}
      disabled={isSubmitting}
    >
      Continue
    </button>
  ) : (
    <div className="setup-actions">
      <button
        type="button"
        className="btn btn--secondary flex-1"
        onClick={handleSkipContact}
        disabled={isSubmitting}
      >
        Skip
      </button>
      <button
        type="button"
        className="btn btn--primary flex-1"
        onClick={handleSaveContact}
        disabled={isSubmitting}
      >
        {isSubmitting ? 'Saving...' : 'Save & enter'}
      </button>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      scrollKey={step}
      className="setup-screen-layout"
    >
      <div className="setup-content-wrap">
        {step === 0 ? (
          <div className="setup-card">
            <span className="text-caption" style={{ color: 'var(--color-stone)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              A PRIVATE DIARY
            </span>
            <h2 className="text-headline mt-2 mb-4" style={{ fontSize: '24px' }}>
              Your words are kept on your phone.
            </h2>
            <p className="text-body mb-2" style={{ color: 'var(--color-stone)' }}>
              Belief asks one small question each evening. When things get difficult, it plays back what you proved about yourself in your own exact words.
            </p>
          </div>
        ) : (
          /* Phase 7: Who's one person you'd call on a bad day? (Optional, skippable) */
          <div className="setup-card">
            <span className="text-caption" style={{ color: 'var(--color-stone)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              OPTIONAL
            </span>
            <h2 className="text-headline mt-2 mb-3" style={{ fontSize: '24px' }}>
              Who's one person you'd call on a bad day?
            </h2>
            <p className="text-small mb-4" style={{ color: 'var(--color-stone)' }}>
              Saved only on this device. If things get heavy, we will provide a private one-tap shortcut for you to message them. We never contact anyone.
            </p>

            <div className="form-group mb-3">
              <label className="text-caption mb-1" style={{ display: 'block', color: 'var(--color-ink)' }}>
                Their name
              </label>
              <input
                type="text"
                className="text-input"
                placeholder="e.g. Riya, Papa, Kabir"
                value={personName}
                onChange={(e) => setPersonName(e.target.value)}
              />
            </div>

            <div className="form-group mb-2">
              <label className="text-caption mb-1" style={{ display: 'block', color: 'var(--color-ink)' }}>
                WhatsApp number (optional)
              </label>
              <input
                type="tel"
                className="text-input"
                placeholder="+91 98765 43210"
                value={personNumber}
                onChange={(e) => setPersonNumber(e.target.value)}
              />
            </div>
          </div>
        )}
      </div>

      <style>{`
        .setup-voice-top {
          display: flex;
          justify-content: center;
          width: 100%;
          padding: 8px 0;
        }
        .setup-content-wrap {
          display: flex;
          flex-direction: column;
          width: 100%;
          max-width: 360px;
          margin: 0 auto;
        }
        .setup-card {
          background: var(--color-beige);
          border: 1px solid var(--color-sand);
          border-radius: var(--radius-card);
          padding: 24px;
          display: flex;
          flex-direction: column;
        }
        .text-input {
          width: 100%;
          padding: 12px 14px;
          border-radius: var(--radius-card);
          border: 1px solid var(--color-sand);
          background: var(--color-cream);
          font-family: var(--font-sans);
          font-size: var(--text-body);
          color: var(--color-ink);
          outline: none;
          box-sizing: border-box;
        }
        .text-input:focus {
          border-color: var(--color-ink);
        }
        .setup-actions {
          display: flex;
          gap: 12px;
          width: 100%;
        }
        .flex-1 {
          flex: 1;
        }
      `}</style>
    </ScreenLayout>
  );
}
