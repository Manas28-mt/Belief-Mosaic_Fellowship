-- Schema for Belief backend
-- Rule: No table may hold transcripts, audio, quotes or Balu messages.

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY,
  token_hash text NOT NULL,
  created_at timestamptz DEFAULT now(),
  tz text DEFAULT 'Asia/Kolkata',
  prompt_time time DEFAULT '21:00',
  frequency text DEFAULT 'daily',      -- 'daily' or 'reduced'
  last_entry_at timestamptz,
  hard_dates date[] DEFAULT '{}',      -- dates only, no labels
  day_scores jsonb DEFAULT '{}',       -- {"2026-10-12": 0..3}, keep 14 days
  last_playback_sent_at timestamptz,
  last_checkin_sent_at timestamptz,
  last_balu_invite_at timestamptz,
  last_notification_date date
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id uuid PRIMARY KEY,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  endpoint text UNIQUE NOT NULL,
  p256dh text,
  auth text,
  created_at timestamptz DEFAULT now()
);
