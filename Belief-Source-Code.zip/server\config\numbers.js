// Tunable numbers for the server. Every value commented as a first guess. Never hardcode elsewhere.

export const NUMBERS = {
  SILENCE_DAYS: 3, // Days of silence before check-in fires (first guess)
  SILENCE_DAYS_AFTER_HEAVY: 2, // Quicker check-in if user was heavy in last 5 days (first guess)
  REGULAR_MIN_DAYS: 4, // Minimum entries to consider user regular (first guess)
  REGULAR_WINDOW_DAYS: 14, // Window of days to evaluate regularity (first guess)
  PLAYBACK_COOLDOWN_DAYS: 7, // Minimum days between playback notifications (first guess)
  BALU_INVITE_COOLDOWN_DAYS: 3, // Minimum days between Balu session invites (first guess)
  LADDER_WINDOW_DAYS: 5, // Window for pattern ladder check (first guess)
  LADDER_HEAVY_COUNT: 3, // Heavy days count to trigger Balu invite (first guess)
  LADDER_CONCERNING_COUNT: 2, // Concerning days count to trigger Balu invite (first guess)
  HARD_DATE_HOUR: 19, // Local hour (7 PM) when hard-date notification fires (first guess)
  MAX_BALU_TURNS: 3, // Maximum user turns in a Balu follow-up session (first guess)
  BALU_MAX_WORDS: 35, // Maximum words in a Balu reply (first guess)
};
