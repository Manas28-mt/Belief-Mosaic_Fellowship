import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft } from 'lucide-react';
import { getSetting, setSetting } from '../../services/db.js';
import { updateServerSettings } from '../../services/api.js';
import { disablePushNotifications, requestAndSubscribePush } from '../../services/notifications.js';
import ScreenLayout from '../ScreenLayout.jsx';

export default function NotificationSettings({ onBack }) {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [promptTime, setPromptTime] = useState('21:00');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const msgTimerRef = useRef(null);

  useEffect(() => {
    return () => {
      if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
    };
  }, []);

  useEffect(() => {
    async function load() {
      const sub = await getSetting('pushSubscribed');
      const time = await getSetting('promptTime');
      setIsSubscribed(Boolean(sub));
      if (time) setPromptTime(time);
    }
    load();
  }, []);

  const showTempMessage = (text) => {
    setMessage(text);
    if (msgTimerRef.current) clearTimeout(msgTimerRef.current);
    msgTimerRef.current = setTimeout(() => setMessage(''), 3000);
  };

  const handleTimeChange = async (e) => {
    const newTime = e.target.value;
    setPromptTime(newTime);
    await setSetting('promptTime', newTime);
    await updateServerSettings({ promptTime: newTime });
    showTempMessage('Prompt time saved');
  };

  const handleToggleOff = async () => {
    setLoading(true);
    try {
      await disablePushNotifications();
      setIsSubscribed(false);
      showTempMessage('Notifications turned off');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleOn = async () => {
    setLoading(true);
    try {
      const res = await requestAndSubscribePush();
      if (res.success) {
        setIsSubscribed(true);
        showTempMessage('Notifications enabled');
      } else {
        showTempMessage('Permission not granted');
      }
    } finally {
      setLoading(false);
    }
  };

  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  );

  const footerContent = (
    <div className="text-center">
      <p className="text-caption" style={{ color: 'var(--color-stone)', margin: 0 }}>
        Your words never appear on your lock screen.
      </p>
    </div>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="cream"
      className="settings-layout"
    >
      <div className="settings-content animate-fade-in">
        <h2 className="text-headline mb-4">Notification Settings</h2>

        <div className="card mb-4 p-4">
          <div className="settings-row mb-4">
            <div>
              <div className="text-body font-bold">Status</div>
              <div className="text-caption" style={{ color: 'var(--color-stone)' }}>
                {isSubscribed ? 'Active on this device' : 'Off'}
              </div>
            </div>
            <div>
              {isSubscribed ? (
                <button
                  type="button"
                  className="btn btn--secondary"
                  onClick={handleToggleOff}
                  disabled={loading}
                >
                  Turn off
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={handleToggleOn}
                  disabled={loading}
                >
                  Turn on
                </button>
              )}
            </div>
          </div>

          {isSubscribed && (
            <div className="settings-row pt-4 border-top">
              <div>
                <div className="text-body font-bold">Evening Prompt Time</div>
                <div className="text-caption" style={{ color: 'var(--color-stone)' }}>
                  When today's question arrives
                </div>
              </div>
              <div>
                <input
                  type="time"
                  value={promptTime}
                  onChange={handleTimeChange}
                  className="time-picker-input"
                />
              </div>
            </div>
          )}
        </div>

        {message && (
          <div className="text-caption text-center" style={{ color: 'var(--color-leaf)' }}>
            {message}
          </div>
        )}
      </div>

      <style>{`
        .settings-content {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .settings-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .time-picker-input {
          font-family: var(--font-sans);
          font-size: var(--text-body);
          padding: 8px 12px;
          border-radius: var(--radius-small);
          border: 1px solid var(--color-sand);
          background-color: var(--color-cream);
          color: var(--color-ink);
        }
        .border-top {
          border-top: 1px solid var(--color-sand);
        }
      `}</style>
    </ScreenLayout>
  );
}
