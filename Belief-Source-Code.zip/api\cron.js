import { getDb, getMockStore, isUsingMockDb } from '../server/lib/db.js';
import { decide } from '../server/lib/scheduler.js';
import { sendPush } from '../server/lib/push.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const cronSecret = process.env.CRON_SECRET;
  const providedSecret = req.headers['x-cron-secret'] || req.headers['X-Cron-Secret'];

  // In test / development or when secret is set, verify
  if (cronSecret && providedSecret !== cronSecret) {
    return res.status(401).json({ error: 'Unauthorized: invalid or missing cron secret' });
  }

  let users = [];
  if (isUsingMockDb) {
    const mockStore = getMockStore();
    users = Array.from(mockStore.users.values());
  } else {
    const sql = getDb();
    if (sql) {
      try {
        // Only select users who have active push subscriptions
        users = await sql`
          SELECT u.*
          FROM users u
          WHERE EXISTS (
            SELECT 1 FROM push_subscriptions ps WHERE ps.user_id = u.id
          )
        `;
      } catch (err) {
        return res.status(500).json({ error: 'Database query failed' });
      }
    }
  }

  let sentCount = 0;

  for (const user of users) {
    // Determine user's local time based on their timezone
    const tz = user.tz || 'Asia/Kolkata';
    let localNow;
    try {
      const nowStr = new Date().toLocaleString('en-US', { timeZone: tz });
      localNow = new Date(nowStr);
    } catch {
      localNow = new Date();
    }

    const decision = decide(user, localNow);
    if (!decision) continue;

    // Send push notification
    const pushResult = await sendPush(user.id, decision);
    if (pushResult.sent > 0) {
      sentCount++;
      const nowIso = new Date().toISOString();
      const todayStr = localNow.toISOString().split('T')[0];

      // Update timestamps
      if (isUsingMockDb) {
        if (decision.type === 'playback') user.last_playback_sent_at = nowIso;
        if (decision.type === 'checkin') user.last_checkin_sent_at = nowIso;
        if (decision.type === 'balu') user.last_balu_invite_at = nowIso;
        user.last_notification_date = todayStr;
      } else {
        const sql = getDb();
        if (sql) {
          try {
            await sql`
              UPDATE users
              SET
                last_playback_sent_at = CASE WHEN ${decision.type === 'playback'} THEN NOW() ELSE last_playback_sent_at END,
                last_checkin_sent_at = CASE WHEN ${decision.type === 'checkin'} THEN NOW() ELSE last_checkin_sent_at END,
                last_balu_invite_at = CASE WHEN ${decision.type === 'balu'} THEN NOW() ELSE last_balu_invite_at END,
                last_notification_date = ${todayStr}::date
              WHERE id = ${user.id}
            `;
          } catch (updateErr) {
            // Log code only
            console.error('[CRON_UPDATE_ERROR]', updateErr.code || 'UNKNOWN');
          }
        }
      }
    }
  }

  // Log only count per RULES.md ("No content in logs. Logs may hold counts and error codes only.")
  console.log(`[CRON] Processed users: ${users.length}, Push notifications sent: ${sentCount}`);
  return res.status(200).json({ ok: true, processedUsers: users.length, sentCount });
}
