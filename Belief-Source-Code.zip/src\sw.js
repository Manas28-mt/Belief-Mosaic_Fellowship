/* eslint-disable no-undef */
// Service worker for Belief PWA (injectManifest strategy)

// Workbox injection point
const precacheManifest = self.__WB_MANIFEST || [];

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Push notification handling
self.addEventListener('push', (event) => {
  if (!event.data) return;
  try {
    const payload = event.data.json();
    const type = payload.type;
    const text = payload.text;

    event.waitUntil(
      self.registration.showNotification('Belief', {
        body: text,
        tag: type,
        icon: '/icon-192.png',
        badge: '/icon-192.png',
      })
    );
  } catch (err) {
    // If not valid JSON, ignore
  }
});

// Notification click handling
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const type = event.notification.tag;
  const allowed = ['record', 'playback', 'checkin', 'balu'];
  const targetUrl = allowed.includes(type) ? `/?open=${type}` : '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url && 'focus' in client) {
          if ('navigate' in client) {
            client.navigate(targetUrl);
          }
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(targetUrl);
      }
    })
  );
});
