import React from 'react';
import { getTodaysPrompt, sampleEntries } from '../../data/sampleStudent';

/**
 * The main Home Screen for the sample student tour.
 * Shows today's prompt, record button, rough day button, and past entries.
 */
export default function HomeScreen({ isTour, onSelectEntry, onRoughDay }) {
  const todaysPrompt = getTodaysPrompt();

  return (
    <div className="home-screen animate-fade-in">
      <div className="home-header">
        <h1 className="text-headline mb-4">{todaysPrompt}</h1>
        
        <div className="capture-area">
          <button className="record-btn mb-2" title="Record (demo)">
            <div className="record-btn__icon">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z" />
              </svg>
            </div>
          </button>
          
          <button className="btn btn--ghost" onClick={onRoughDay}>
            Rough day
          </button>
        </div>
      </div>
      
      <div className="entries-section mt-6">
        <h2 className="text-small mb-3" style={{ opacity: 0.7 }}>Past entries</h2>
        
        <div className="entry-list flex-col gap-2">
          {sampleEntries.slice().reverse().map(entry => (
            <div 
              key={entry.id} 
              className="entry-card"
              onClick={() => onSelectEntry(entry)}
            >
              <div className="entry-card__date">
                {new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </div>
              <div className="entry-card__snippet">
                "{entry.transcript}"
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="widget-mockup-section mt-6 mb-4 text-center">
        <div className="card" style={{ display: 'inline-block', padding: 'var(--space-2)' }}>
          <div className="text-caption mb-1">Widget Mockup</div>
          <div style={{ background: 'var(--color-cream)', padding: 'var(--space-2)', borderRadius: 'var(--radius-small)', border: '1px solid var(--color-sand)' }}>
            <div className="text-small" style={{ fontWeight: 500 }}>{todaysPrompt}</div>
            <div className="mt-1" style={{ width: '32px', height: '32px', background: 'var(--color-marigold)', borderRadius: '50%', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ width: '12px', height: '12px', background: 'var(--color-ink)', borderRadius: '50%' }}></div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .home-screen {
          display: flex;
          flex-direction: column;
        }
        .home-header {
          text-align: center;
          padding: var(--space-4) 0 var(--space-2);
        }
        .capture-area {
          display: flex;
          flex-direction: column;
          align-items: center;
        }
      `}</style>
    </div>
  );
}
