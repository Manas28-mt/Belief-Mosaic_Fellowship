import { test, describe, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { checkRateLimit, resetRateLimits } from '../server/lib/rateLimit.js';

describe('Rate Limiter Tests', () => {
  beforeEach(() => {
    resetRateLimits();
  });

  test('allows up to 30 requests per hour for a single IP', () => {
    const ip = '192.168.1.100';
    const req = { headers: { 'x-forwarded-for': ip } };
    const res = {
      statusCode: 200,
      headers: {},
      setHeader(k, v) { this.headers[k] = v; },
      status(code) { this.statusCode = code; return this; },
      json(body) { this.body = body; return this; },
    };

    for (let i = 0; i < 30; i++) {
      const allowed = checkRateLimit(req, res);
      assert.equal(allowed, true, `Request ${i + 1} should be allowed`);
    }

    // 31st request should be blocked with 429
    const blocked = checkRateLimit(req, res);
    assert.equal(blocked, false, 'Request 31 should be rejected');
    assert.equal(res.statusCode, 429);
    assert.equal(res.headers['Retry-After'], 3600);
    assert.match(res.body.error, /Rate limit exceeded/);
  });

  test('isolates limits between different IPs', () => {
    const ipA = '10.0.0.1';
    const ipB = '10.0.0.2';
    const mockRes = () => ({
      statusCode: 200,
      setHeader() {},
      status(code) { this.statusCode = code; return this; },
      json() {},
    });

    const reqA = { headers: { 'x-forwarded-for': ipA } };
    const reqB = { headers: { 'x-forwarded-for': ipB } };

    // Fill ipA to 30
    for (let i = 0; i < 30; i++) {
      checkRateLimit(reqA, mockRes());
    }

    // ipA is blocked
    assert.equal(checkRateLimit(reqA, mockRes()), false);

    // ipB is still allowed
    assert.equal(checkRateLimit(reqB, mockRes()), true);
  });
});
