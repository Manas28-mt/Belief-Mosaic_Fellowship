import React, { useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { sampleQuotePairs, sampleFactLine, sampleFriendNotes } from '../../data/sampleStudent';
import { getTimelineAnswers } from '../../services/db.js';
import ScreenLayout from '../ScreenLayout.jsx';
import Balu from '../balu/Balu.jsx';

/**
 * Bad Day Mode — the centre of the app.
 * Acknowledges the day, shows quotes, fact line, timeline sliver, and friend note.
 * Converted to use unified ScreenLayout.
 */
export default function BadDayMode({ isTour, onBack, onOpenBalu }) {
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [userMilestones, setUserMilestones] = useState([]);
  const pair = sampleQuotePairs[0];
  const friendNote = sampleFriendNotes[0];

  useEffect(() => {
    if (!isTour) {
      async function loadUserTimeline() {
        try {
          const stored = await getTimelineAnswers();
          if (stored) {
            setUserMilestones(stored.filter((item) => item.text && item.text.trim()));
          }
        } catch {
          // Ignore
        }
      }
      loadUserTimeline();
    }
  }, [isTour]);

  const handleOpenBaluSafe = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    if (onOpenBalu) onOpenBalu();
  };

  const handleBackSafe = () => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    if (onBack) onBack();
  };

  const headerContent = !isTour ? (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={handleBackSafe}
      disabled={isTransitioning}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  ) : null;

  const footerContent = onOpenBalu ? (
    <button
      type="button"
      className="btn btn--secondary btn--full"
      onClick={handleOpenBaluSafe}
      disabled={isTransitioning}
    >
      Want to add something about today?
    </button>
  ) : null;

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="peach"
      className="badday-layout"
    >
      <div className="badday-mode animate-fade-in-slow">
        <div className="badday-header mb-6 delay-1 animate-slide-up" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '16px' }}>
          <p className="text-headline" style={{ margin: 0 }}>
            Today is hard.<br />
            Here is what you<br />
            already know.
          </p>
          <Balu pose="soft" size={72} noMotion={true} entrance="none" />
        </div>
        
        <div className="quotes-section delay-2 animate-slide-up">
          {/* Low Quote */}
          <div className="card--quote mb-3">
            <p className="text-voice mb-2">"{pair.low.quote}"</p>
            <p className="text-caption">
              {new Date(pair.low.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
            </p>
          </div>
          
          {/* Recovery Quote */}
          <div className="card--quote mb-4">
            <p className="text-voice mb-2">"{pair.recovery.quote}"</p>
            <p className="text-caption">
              {new Date(pair.recovery.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
            </p>
          </div>
          
          {/* Fact Line */}
          <div className="fact-line mb-6">
            {sampleFactLine}
          </div>
        </div>
        
        {/* Timeline */}
        <div className="timeline-section delay-3 animate-slide-up mb-6">
          <div className="timeline">
            <div className="timeline__line">
              <div className="timeline__sliver" />
            </div>
            <div className="timeline__labels">
              <span className="timeline__label">2006</span>
              <div className="flex-col items-center">
                <span className="timeline__label timeline__label--now">this month</span>
              </div>
              <span className="timeline__label">2026</span>
            </div>
          </div>
          {!isTour && userMilestones.length > 0 && (
            <div className="user-timeline-snippets mt-3">
              {userMilestones.map((m) => (
                <div key={m.id} className="user-timeline-snippet card p-3 mb-2">
                  <span className="text-caption" style={{ color: 'var(--color-stone)', textTransform: 'uppercase' }}>
                    {m.title || 'Your proof'}
                  </span>
                  <p className="text-voice mt-1" style={{ fontSize: '15px', margin: 0 }}>
                    "{m.text}"
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Friend Note */}
        <div className="friend-section delay-4 animate-slide-up mb-4">
          <div className="text-small mb-2" style={{ color: 'var(--color-leaf)', fontWeight: 500 }}>
            From {friendNote.from}
          </div>
          <div className="card card--friend">
            <p className="text-voice mb-2" style={{ fontSize: '0.95rem' }}>
              "{friendNote.text}"
            </p>
            <p className="text-caption" style={{ color: 'var(--color-leaf)' }}>
              {new Date(friendNote.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
            </p>
          </div>
        </div>
      </div>

      <style>{`
        .badday-mode {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .badday-header .text-headline {
          color: var(--color-ink);
          font-weight: 400;
          line-height: 1.4;
        }
        
        .delay-1 { animation-delay: 200ms; }
        .delay-2 { animation-delay: 600ms; }
        .delay-3 { animation-delay: 1000ms; }
        .delay-4 { animation-delay: 1400ms; }
        
        .timeline__sliver {
          animation: expandSliver 1.5s ease-out 1000ms both;
        }
        
        @keyframes expandSliver {
          0% { right: 4%; width: 96%; background-color: var(--color-ink); }
          100% { right: 4%; width: 6px; background-color: var(--color-marigold); }
        }
      `}</style>
    </ScreenLayout>
  );
}
