import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Silence Check-in screen.
 * Opened when ?open=checkin or when the silence trigger fires.
 * Converted to use unified ScreenLayout with pinned actions in footer.
 */
export default function SilenceCheckin({ onBack, onRoughPatch, isDemo = false }) {
  const [replied, setReplied] = useState(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleReply = (type) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setReplied(type);
    if (type === 'rough' && onRoughPatch) {
      setTimeout(() => {
        onRoughPatch();
      }, 300);
    }
  };

  const headerContent = (
    <button
      type="button"
      className="btn btn--ghost"
      onClick={onBack}
      disabled={isTransitioning}
      style={{ paddingLeft: 0, display: 'flex', alignItems: 'center', gap: '6px' }}
    >
      <ArrowLeft size={16} strokeWidth={2} />
      <span>Back</span>
    </button>
  );

  const footerContent = !replied ? (
    <div className="checkin-actions">
      <button
        type="button"
        className="btn btn--secondary mb-2 w-full"
        onClick={() => handleReply('busy')}
        disabled={isTransitioning}
      >
        Just busy
      </button>
      <button
        type="button"
        className="btn btn--primary mb-2 w-full"
        onClick={() => handleReply('rough')}
        disabled={isTransitioning}
      >
        Rough patch
      </button>
      <button
        type="button"
        className="btn btn--secondary w-full"
        onClick={() => handleReply('bored')}
        disabled={isTransitioning}
      >
        Bored of this
      </button>
    </div>
  ) : (
    <button
      type="button"
      className="btn btn--secondary w-full"
      onClick={onBack}
    >
      Done
    </button>
  );

  return (
    <ScreenLayout
      header={headerContent}
      footer={footerContent}
      bg="peach"
      className="checkin-screen-layout"
    >
      <div className="checkin-content animate-fade-in">
        <div className="checkin-card card card--quote mb-4">
          <div className="text-caption mb-2" style={{ color: 'var(--color-stone)' }}>
            Something from your diary:
          </div>
          <p className="text-voice mb-2">
            "I finally understand how Keynes got it right about sticky wages."
          </p>
          <span className="text-caption" style={{ color: 'var(--color-stone)' }}>
            May 28th
          </span>
        </div>

        <div className="checkin-prompt mb-4 text-center">
          <p className="text-body" style={{ color: 'var(--color-ink)' }}>
            Things have been quiet for a few days.
          </p>
        </div>

        {replied && (
          <div className="checkin-done card text-center p-4">
            <p className="text-body" style={{ color: 'var(--color-leaf)' }}>
              {replied === 'busy' && 'Got it. We will leave you to it.'}
              {replied === 'bored' && 'Understood. We will check in much less often.'}
              {replied === 'rough' && 'Taking you to Balu.'}
            </p>
          </div>
        )}
      </div>

      <style>{`
        .checkin-content {
          display: flex;
          flex-direction: column;
          width: 100%;
          max-width: 360px;
          margin: 0 auto;
        }
        .checkin-actions {
          display: flex;
          flex-direction: column;
          width: 100%;
        }
        .w-full {
          width: 100%;
        }
      `}</style>
    </ScreenLayout>
  );
}
