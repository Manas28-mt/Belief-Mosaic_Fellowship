import React, { useEffect, useRef } from 'react';
import ScreenLayout from '../ScreenLayout.jsx';

/**
 * Splash Screen — Animated intro with the Belief logo.
 * Converted to use unified ScreenLayout:
 * - Fills the phone frame height.
 * - Timer cleanly unmounts with ref cleanup.
 * - Zero double-fires.
 * - Fixed image dimensions for zero CLS.
 */
export default function Splash({ onDone }) {
  const timerRef = useRef(null);
  const doneCalledRef = useRef(false);

  useEffect(() => {
    timerRef.current = setTimeout(() => {
      if (!doneCalledRef.current) {
        doneCalledRef.current = true;
        onDone();
      }
    }, 2800);

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [onDone]);

  const handleSkip = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    if (!doneCalledRef.current) {
      doneCalledRef.current = true;
      onDone();
    }
  };

  return (
    <ScreenLayout bg="yellow" className="splash-screen-layout">
      <div
        className="splash-screen-inner"
        onClick={handleSkip}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleSkip();
          }
        }}
        aria-label="Belief splash screen"
      >
        <div className="splash-logo-wrap">
          <img
            src="/logo.jpg"
            alt="Belief logo"
            className="splash-logo-img"
            width="88"
            height="88"
          />
        </div>

        <div className="splash-brand">
          <h1 className="splash-name">Belief</h1>
          <p className="splash-tagline">A system to keep your belief intact.</p>
        </div>
      </div>

      <style>{`
        .splash-screen-inner {
          flex: 1;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          width: 100%;
          min-height: 100%;
          cursor: pointer;
          user-select: none;
        }

        .splash-logo-wrap {
          width: 88px;
          height: 88px;
          border-radius: var(--radius-card);
          overflow: hidden;
          background: #FFFFFF;
          border: 2px solid rgba(42, 37, 32, 0.12);
          box-shadow: 0 4px 20px rgba(42, 37, 32, 0.08);
          animation: logoReveal 2.8s cubic-bezier(0.7, 0, 0.3, 1) forwards;
          z-index: 1;
          flex-shrink: 0;
        }

        .splash-logo-img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .splash-brand {
          z-index: 1;
          text-align: center;
          animation: brandReveal 2.8s cubic-bezier(0.7, 0, 0.3, 1) forwards;
        }

        .splash-name {
          font-family: var(--font-serif);
          font-size: var(--text-display);
          line-height: var(--lh-heading);
          font-weight: 500;
          color: var(--color-ink);
          margin-top: 16px;
          margin-bottom: 0;
        }

        .splash-tagline {
          font-family: var(--font-sans);
          font-size: var(--text-caption);
          color: rgba(42, 37, 32, 0.75);
          font-weight: 500;
          margin-top: 6px;
          margin-bottom: 0;
          max-width: 240px;
        }

        @keyframes logoReveal {
          0% { transform: scale(0); opacity: 0; }
          22% { transform: scale(1.08); opacity: 1; }
          35% { transform: scale(1); opacity: 1; }
          75% { transform: scale(1); opacity: 1; }
          100% { transform: scale(0.85); opacity: 0; }
        }

        @keyframes brandReveal {
          0%, 15% { opacity: 0; transform: translateY(12px); }
          30%, 75% { opacity: 1; transform: translateY(0); }
          100% { opacity: 0; transform: translateY(-8px); }
        }

        @media (prefers-reduced-motion: reduce) {
          .splash-logo-wrap,
          .splash-brand {
            animation: none !important;
          }
        }
      `}</style>
    </ScreenLayout>
  );
}
