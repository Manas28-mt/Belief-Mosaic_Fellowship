import React, { useState, useEffect } from 'react';
import { requestAndSubscribePush, dismissNotificationExplainer } from '../../services/notifications.js';

export default function NotificationExplainer({ onDone }) {
  const [isIosNonStandalone, setIsIosNonStandalone] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const isIos = /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
      setIsIosNonStandalone(isIos && !isStandalone);
    }
  }, []);

  const handleYes = async () => {
    setLoading(true);
    try {
      await requestAndSubscribePush();
    } finally {
      setLoading(false);
      onDone();
    }
  };

  const handleNotNow = async () => {
    await dismissNotificationExplainer();
    onDone();
  };

  if (isIosNonStandalone) {
    return (
      <div className="explainer-shell animate-fade-in">
        <div className="explainer-content card p-6">
          <h2 className="text-headline mb-3">Add Belief to your Home Screen</h2>
          <p className="text-body mb-4" style={{ color: 'var(--color-stone)' }}>
            To receive your evening question on iPhone, first add the app to your Home Screen:
          </p>
          <div className="ios-steps mb-6">
            <div className="ios-step-item mb-3">
              <span className="step-num">1</span>
              <span className="text-body">Tap the <strong>Share</strong> button at the bottom of Safari.</span>
            </div>
            <div className="ios-step-item mb-3">
              <span className="step-num">2</span>
              <span className="text-body">Scroll down and tap <strong>Add to Home Screen</strong>.</span>
            </div>
            <div className="ios-step-item">
              <span className="step-num">3</span>
              <span className="text-body">Open Belief from your Home Screen to enable notifications.</span>
            </div>
          </div>
          <button className="btn btn--primary btn--full" onClick={onDone}>
            Got it
          </button>
        </div>

        <style>{`
          .explainer-shell {
            position: fixed;
            inset: 0;
            background-color: rgba(42, 37, 32, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: var(--space-4);
            z-index: 150;
          }
          .explainer-content {
            background-color: var(--color-cream);
            width: 100%;
            max-width: 360px;
            border-radius: var(--radius-card);
            border: 1px solid var(--color-sand);
          }
          .ios-steps {
            display: flex;
            flex-direction: column;
          }
          .ios-step-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
          }
          .step-num {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background-color: var(--color-beige);
            color: var(--color-ink);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 700;
            flex-shrink: 0;
          }
        `}</style>
      </div>
    );
  }

  return (
    <div className="explainer-shell animate-fade-in">
      <div className="explainer-content card p-6">
        <h2 className="text-headline mb-3">Want today's question each evening?</h2>
        <p className="text-body mb-6" style={{ color: 'var(--color-stone)' }}>
          We'll also check in rarely. Your words never appear on your lock screen.
        </p>

        <div className="explainer-buttons">
          <button
            className="btn btn--primary btn--full mb-3"
            onClick={handleYes}
            disabled={loading}
          >
            {loading ? 'Setting up...' : 'Yes'}
          </button>
          <button
            className="btn btn--secondary btn--full"
            onClick={handleNotNow}
            disabled={loading}
          >
            Not now
          </button>
        </div>
      </div>

      <style>{`
        .explainer-shell {
          position: fixed;
          inset: 0;
          background-color: rgba(42, 37, 32, 0.4);
          display: flex;
          align-items: center;
          justify-content: center;
          padding: var(--space-4);
          z-index: 150;
        }
        .explainer-content {
          background-color: var(--color-cream);
          width: 100%;
          max-width: 360px;
          border-radius: var(--radius-card);
          border: 1px solid var(--color-sand);
        }
        .explainer-buttons {
          display: flex;
          flex-direction: column;
        }
      `}</style>
    </div>
  );
}
