# DESIGN PASS: PART 1 of 3

SCOPE. This authorises changes to these screens only: the logo screen, the logo zoom, the login screen, the Balu + Meera screens, and the Balu follow-up screens. The scope lock still applies to everything else.

PRESERVE
- Flow order stays exactly: logo -> zoom -> login -> Balu with Meera -> the rest.
- Keep all my wording exactly. Change layout, styling, components and Balu only.
- Do not touch backend, notifications or Balu logic files.
- Add "PHONE FRAME: do not change" to the PROTECTED SCREENS section of docs/RULES.md.

SCREENSHOTS: you cannot run a browser here. Do not try to install Playwright or any browser driver. Use the screenshots I attach in chat, plus code-level checks.

1. PHONE FRAME: DO NOT CHANGE
- The app is designed for a phone screen. On laptops it is intentionally shown as a phone-sized column centred on the screen. Keep the width, centring, side panels, borders and frame styling exactly as they are.
- Never make a screen wider, full-width or "responsive desktop".
- Only fix two things INSIDE the frame:
  a) Hide the inner scrollbar visually (scrollbar-width: none and ::-webkit-scrollbar { display: none }), but keep scrolling working.
  b) The bottom button must never be clipped. Sticky bottom area with padding-bottom: max(24px, env(safe-area-inset-bottom)) and a soft Cream fade above it. Fully visible at any phone height from 640px up.

2. DESIGN TOKENS
Create src/styles/tokens.css and use it on these screens. No hardcoded colours, sizes or radii.
- Colours: cream #FBF5E6, beige #F1E6CF, marigold #F6B92B, ink #2A2520, stone #6B6257, leaf #2F6B4F, peach #F8DCC8, sand #E4D6BA (borders only).
- Fraunces for Meera's or the student's own words and the big opening lines. Mukta for everything the app and Balu say.
- Type scale: 32, 26, 20, 18, 16, 14 px. Line-height 1.25 for headings, 1.5 for body.
- 8px spacing grid, 24px side margins inside the frame.
- Radii: 20px cards, 999px pills.
- No shadows except a very soft one under Balu.

3. COMPONENTS: one style each
- Card: Beige fill, 1px sand border, 20px radius, 20-24px padding. No white cards, no thick outlines.
- Balu speech bubble: #FFFDF7 fill, 1px sand border, a small tail toward Balu, Mukta 18px. Show multiple lines one at a time with a short reveal, never three identical boxes at once.
- Primary button: Marigold pill, min height 52px, Ink text in Mukta semibold 18px. Secondary button: outlined in Ink.
- Labels: sentence case, Stone, 14px, no letter-spacing, no awkward wrapping. For example, "Economics Honours, Hansraj College".
- Icons: lucide-react only, one stroke weight. Replace every text glyph used as an icon (checkmarks, arrows, bullets) with an SVG icon.
- NO EMOJIS ANYWHERE: copy, icons, code strings. Search all of src and remove them.

# DESIGN PASS: PART 2 of 3

4. SCREEN-SPECIFIC FIXES
- Opening lines screen:
  - Render "Your ability didn't change. Your baseline did." in Ink (the yellow text fails contrast).
  - Emphasise it with a Marigold highlight band behind the text, about 40% of line height. Never use Marigold as text colour.
  - Reveal the lines one at a time, about 1.2s apart, with a quiet "Tap to continue" in Stone at the bottom.
- Meera screen:
  - Replace the photo with Meera's initial "M" in Fraunces on a Peach circle with a thin Ink ring. No AI-looking photos anywhere.
  - "Previous achievements" as a simple list with a small SVG check icon per row and thin sand dividers.
  - A small "Sample" tag in Stone at top right.
- Balu screens: solid Peach or Cream background, no gradients. Remove the small coloured square overlapping Balu.

5. BALU: MAKE HIM ALIVE
Remove every circular Balu avatar and the 3D image from these screens.
Build src/components/balu/Balu.jsx: an original vector bee in inline SVG with named groups:
body, stripes, head, eyes, brows, mouth, antennae, leftWing, rightWing, arms, stinger.
- Rounded forms, minimal detail, flat colour, Marigold and Ink stripes, #FFFDF7 wings at 70% opacity, 2px Ink outline. Readable at 64px and 180px. Do not copy any existing bee mascot.

Props: <Balu expression pose entrance size />
- expression: neutral | happy | curious | listening | thinking | soft | sleepy | surprised
  Expressions change eyes, brows and mouth only, with 150-250ms transitions.
- pose: hover | wave | perch (on the top edge of a card) | peek (half hidden at the frame edge) | point (arm toward a card) | fly
- entrance: peekLeft | peekRight | flyInFromTop | riseFromBottom | none
  All movement stays inside the phone frame, clipped to it.
- Idle: blink every 3-6s at random, wing flutter loop, 4px hover bob over 2.4s, a small head tilt every 8-12s.
- Talking: the mouth alternates 2-3 shapes while a bubble is revealing.
- Use the "motion" package (formerly Framer Motion) for entrances and poses, CSS for idle loops.
- prefers-reduced-motion: no entrances, bob or flutter. Expression changes still work.

Where Balu appears:
- Intro "Hey, I'm Balu": flyInFromTop, then wave + happy, left of the bubble.
- Meera story: peekRight beside the story card, curious, switching to point as the card appears.
- Follow-up: perch on the latest bubble. Listening while waiting, thinking while loading, neutral while speaking.
- Bad-day contexts: 64px, soft, no entrance, no bob.
- Saved: one small nod, then settle.
- Never on the crisis screen. Never more than one Balu per screen.

Create src/components/balu/BaluPlayground.jsx at dev-only route /dev/balu, showing every expression and pose inside the phone frame.

# DESIGN PASS: PART 3 of 3

6. LOGIN SCREEN FIX
- First diagnose why the email field can't be typed in. Likely causes: a parent onClick that navigates, a readOnly or disabled input, or a value without onChange. Fix the actual cause.
- Keep "Login with Gmail" working as it does now.
- Email option:
  - Input prefilled with judge@belief.demo, editable, type="email", autoComplete="email".
  - Enter or Continue submits. Continue is enabled when the email is valid.
  - Any valid email logs straight into the demo account. No password, no real auth yet, but structure the code so real auth can be added later.
- Under the field, in Stone 14px: "Demo account. No password needed."
- 2px Ink focus ring on the input. Inline plain-word errors, never alerts.

7. QA WITHOUT A BROWSER: repeat until clean, max 3 passes
- Run npm run build. Fix all errors and warnings.
- Code-level checks:
  - Grep src for emojis and for text glyphs used as icons (✓ → • ★). There must be none.
  - Grep for any hex colour on these screens that isn't in tokens.css.
  - Grep for "gradient", "box-shadow" and border-radius 50% on Balu.
  - Write scripts/contrast.js that computes the WCAG contrast ratio of every text/background pair used on these screens. Every pair must reach 4.5:1, or 3:1 for text 28px and up. Report the results.
  - Confirm the phone frame CSS (width, centring, side panels, borders) is byte-for-byte unchanged versus the last commit before this pass (git diff on those files).
  - Confirm the login input has an onChange, isn't readOnly or disabled, and isn't inside a clickable parent that navigates.
- Checklist. Confirm each item in code and report:
  [ ] phone frame unchanged
  [ ] one scroll container per screen, inner scrollbar hidden
  [ ] bottom button can't be clipped at 640px height
  [ ] no emojis or glyph icons
  [ ] no Marigold text, no white text on Marigold
  [ ] contrast script passes
  [ ] only token colours, Fraunces and Mukta
  [ ] one card, bubble and button style
  [ ] no gradients, no heavy shadows, no circle-cropped Balu
  [ ] Balu uses 4+ expressions and 3+ entrances across the flow, always inside the frame
  [ ] reduced-motion handled
  [ ] login typing, Enter and the prefilled demo email all work
  [ ] my wording and flow order unchanged
- Commit as "Design polish + Balu rig + login fix".
- Then give me a numbered list of screens and what to look for on each, so I can check them in my own browser and send you screenshots. Stop and wait for my screenshots.
